import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';

const OnboardingProgramaMujer = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    grupo: null,
    objetivos: [],
    riskFactors: {},
    seguimiento: null,
    consent: {}
  });
  const [showRiskAssessment, setShowRiskAssessment] = useState(false);

  const grupos = [
    {
      id: 'grupo-a',
      emoji: '🌱',
      title: 'Grupo A: Construyendo Bases Sólidas',
      subtitle: 'Mujeres Jóvenes',
      description: 'Desarrollo Académico y Profesional',
      focus: 'Establecer hábitos saludables y prevención temprana',
      color: 'from-green-400 to-emerald-600',
      features: ['App de Tracking Nutricional', 'Wearables integrados', 'Dashboard Personal', 'Alertas preventivas']
    },
    {
      id: 'grupo-b',
      emoji: '🤰',
      title: 'Grupo B: Salud Cardiovascular y Fertilidad',
      subtitle: 'Mujeres Jóvenes',
      description: 'Programando Maternidad | Desarrollo Profesional',
      focus: 'Optimización metabólica y preparación para embarazo',
      color: 'from-pink-400 to-rose-600',
      features: ['Telemonitoreo', 'Perfil Metabólico Digital', 'Gestión de Suplementación', 'Teleconsulta Especializada']
    },
    {
      id: 'grupo-c',
      emoji: '🌸',
      title: 'Grupo C: Navegando la Transición Hormonal',
      subtitle: 'Mujeres Adultas',
      description: 'Menopausia | Madres de Hijos Adultos',
      focus: 'Monitoreo intensivo cardiovascular post-menopausia',
      color: 'from-purple-400 to-violet-600',
      features: ['Monitoreo Cardiovascular Domiciliario', 'App Manejo de Menopausia', 'Análisis Predictivo', 'Programas de Gestión de Estrés']
    },
    {
      id: 'grupo-d',
      emoji: '🌟',
      title: 'Grupo D: Longevidad Activa y Saludable',
      subtitle: 'Mujeres Adultas 3era y 4ta Edad',
      description: 'Abuelas | Emprendedoras | Viajeras',
      focus: 'Prevención secundaria y calidad de vida',
      color: 'from-amber-400 to-orange-600',
      features: ['Pastillero Inteligente', 'Sistema de Alerta Médica', 'Telemedicina Geriátrica', 'Círculo de Cuidado Digital']
    }
  ];

  const lifesEssential8 = [
    { id: 'nutricion', label: '🥗 Nutrición', category: 'habitos', icon: '🍎' },
    { id: 'actividad-fisica', label: '🏃‍♀️ Actividad Física', category: 'habitos', icon: '💪' },
    { id: 'sueno', label: '😴 Sueño', category: 'habitos', icon: '🌙' },
    { id: 'no-fumar', label: '🚭 Dejar de Fumar', category: 'habitos', icon: '🌬️' },
    { id: 'circunferencia', label: '📏 Circunferencia Abdominal', category: 'metricas', icon: '⚖️' },
    { id: 'presion', label: '💓 Presión Arterial', category: 'metricas', icon: '🩺' },
    { id: 'colesterol', label: '🧪 Colesterol', category: 'metricas', icon: '📊' },
    { id: 'glucosa', label: '🍬 Glucosa', category: 'metricas', icon: '🔬' }
  ];

  const handleGrupoSelect = (grupoId) => {
    setFormData({ ...formData, grupo: grupoId });
    setTimeout(() => setStep(2), 300);
  };

  const handleObjetivoToggle = (objId) => {
    if (objId === 'no-se') {
      setShowRiskAssessment(true);
      setFormData({ ...formData, objetivos: ['no-se'] });
    } else {
      const newObjetivos = formData.objetivos.includes(objId)
        ? formData.objetivos.filter(o => o !== objId && o !== 'no-se')
        : [...formData.objetivos.filter(o => o !== 'no-se'), objId];
      setFormData({ ...formData, objetivos: newObjetivos });
      setShowRiskAssessment(false);
    }
  };

  const calculateRiskScore = () => {
    let score = 0;
    if (formData.riskFactors.familyHistory) score += 2;
    if (formData.riskFactors.smoking) score += 3;
    if (!formData.riskFactors.physicalActivity) score += 2;
    if (formData.riskFactors.chronicConditions) score += 3;
    if (formData.riskFactors.sleepHours < 6 || formData.riskFactors.sleepHours > 9) score += 1;
    if (formData.riskFactors.stress === 'frecuente' || formData.riskFactors.stress === 'siempre') score += 2;
    return score;
  };

  const getSuggestedObjectives = () => {
    const risk = calculateRiskScore();
    const suggestions = [];
    
    if (formData.riskFactors.smoking) suggestions.push('no-fumar');
    if (!formData.riskFactors.physicalActivity) suggestions.push('actividad-fisica');
    if (formData.riskFactors.sleepHours < 6 || formData.riskFactors.sleepHours > 9) suggestions.push('sueno');
    if (formData.riskFactors.chronicConditions) {
      suggestions.push('presion', 'colesterol', 'glucosa');
    }
    if (risk >= 5) suggestions.push('nutricion', 'circunferencia');
    
    return [...new Set(suggestions)];
  };

  const renderWelcome = () => (
    <div className="space-y-8 text-center animate-fade-in">
      <div className="space-y-4">
        <h1 className="text-5xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
          Programa MUJER
        </h1>
        <p className="text-2xl text-gray-600">Tu Salud en Cada Etapa</p>
      </div>
      
      <div className="max-w-2xl mx-auto bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8">
        <div className="flex items-center justify-center gap-4 mb-4">
          <span className="text-4xl">❤️</span>
          <h2 className="text-2xl font-semibold text-gray-800">Life's Essential 8</h2>
          <span className="text-4xl">💪</span>
        </div>
        <p className="text-gray-600 leading-relaxed">
          La guía de la <strong>American Heart Association</strong> con 8 componentes clave 
          para mejorar y mantener tu salud cardiovascular. Nuestras soluciones tecnológicas 
          te acompañan con <strong>datos en tiempo real</strong> adaptados a tu momento actual.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
        {['✓ Seguridad', '✓ Escalabilidad', '✓ FHIR R4', '✓ Interoperabilidad'].map((feature, i) => (
          <div key={i} className="bg-white rounded-lg p-4 shadow-md text-gray-700 font-medium">
            {feature}
          </div>
        ))}
      </div>

      <button
        onClick={() => setStep(1)}
        className="mt-8 px-8 py-4 bg-gradient-to-r from-pink-500 to-purple-600 text-white text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
      >
        Comenzar mi Evaluación →
      </button>
    </div>
  );

  const renderGrupoSelection = () => (
    <div className="space-y-8 animate-fade-in">
      <div className="text-center space-y-3">
        <h2 className="text-3xl font-bold text-gray-800">
          ¿Con qué grupo te identificas?
        </h2>
        <p className="text-gray-600">Selecciona el que mejor describe tu momento actual</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {grupos.map((grupo, index) => (
          <Card
            key={grupo.id}
            className={`cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-2xl ${
              formData.grupo === grupo.id ? 'ring-4 ring-purple-500' : ''
            }`}
            style={{ animationDelay: `${index * 100}ms` }}
            onClick={() => handleGrupoSelect(grupo.id)}
          >
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <span className="text-5xl">{grupo.emoji}</span>
                  <div className={`h-3 w-3 rounded-full ${formData.grupo === grupo.id ? 'bg-purple-500' : 'bg-gray-300'}`} />
                </div>
                
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-1">{grupo.title}</h3>
                  <p className="text-sm font-semibold text-gray-600 mb-2">{grupo.subtitle}</p>
                  <p className="text-sm text-gray-500 mb-3">{grupo.description}</p>
                  
                  <div className={`bg-gradient-to-r ${grupo.color} text-white rounded-lg p-3 mb-3`}>
                    <p className="text-sm font-medium">🎯 Foco: {grupo.focus}</p>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-gray-600 uppercase">Herramientas Tech:</p>
                    <div className="grid grid-cols-2 gap-2">
                      {grupo.features.slice(0, 4).map((feature, i) => (
                        <div key={i} className="text-xs text-gray-600 flex items-center gap-1">
                          <span className="text-green-500">✓</span>
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderObjetivosSelection = () => (
    <div className="space-y-8 animate-fade-in">
      <div className="text-center space-y-3">
        <h2 className="text-3xl font-bold text-gray-800">
          Life's Essential 8
        </h2>
        <p className="text-gray-600">¿Qué aspectos te gustaría mejorar?</p>
        <p className="text-sm text-gray-500">Puedes seleccionar varios</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4 max-w-4xl mx-auto">
        {/* Hábitos de Vida */}
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
            <span>🌟</span> Hábitos de Vida
          </h3>
          {lifesEssential8.filter(obj => obj.category === 'habitos').map(objetivo => (
            <button
              key={objetivo.id}
              onClick={() => handleObjetivoToggle(objetivo.id)}
              className={`w-full p-4 rounded-xl text-left transition-all transform hover:scale-102 ${
                formData.objetivos.includes(objetivo.id)
                  ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 shadow-md hover:shadow-lg'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{objetivo.icon}</span>
                  <span className="font-medium">{objetivo.label}</span>
                </div>
                {formData.objetivos.includes(objetivo.id) && (
                  <span className="text-2xl">✓</span>
                )}
              </div>
            </button>
          ))}
        </div>

        {/* Métricas de Salud */}
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
            <span>📊</span> Métricas de Salud
          </h3>
          {lifesEssential8.filter(obj => obj.category === 'metricas').map(objetivo => (
            <button
              key={objetivo.id}
              onClick={() => handleObjetivoToggle(objetivo.id)}
              className={`w-full p-4 rounded-xl text-left transition-all transform hover:scale-102 ${
                formData.objetivos.includes(objetivo.id)
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 shadow-md hover:shadow-lg'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{objetivo.icon}</span>
                  <span className="font-medium">{objetivo.label}</span>
                </div>
                {formData.objetivos.includes(objetivo.id) && (
                  <span className="text-2xl">✓</span>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* No sé opción */}
      <div className="max-w-2xl mx-auto">
        <button
          onClick={() => handleObjetivoToggle('no-se')}
          className={`w-full p-5 rounded-xl transition-all ${
            formData.objetivos.includes('no-se')
              ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-lg'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <div className="flex items-center justify-center gap-3">
            <span className="text-2xl">🤔</span>
            <span className="font-semibold">No estoy segura / Necesito orientación</span>
          </div>
        </button>
      </div>

      {formData.objetivos.length > 0 && !formData.objetivos.includes('no-se') && (
        <div className="flex justify-center">
          <button
            onClick={() => setStep(4)}
            className="px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
          >
            Continuar con mis objetivos →
          </button>
        </div>
      )}
    </div>
  );

  const renderRiskAssessment = () => (
    <div className="space-y-8 animate-fade-in max-w-3xl mx-auto">
      <Alert className="bg-blue-50 border-blue-200">
        <AlertDescription className="text-blue-800">
          <strong>💡 Evaluación Rápida:</strong> Responde estas preguntas para que podamos 
          sugerirte los mejores objetivos personalizados.
        </AlertDescription>
      </Alert>

      <div className="space-y-6">
        {/* Antecedentes familiares */}
        <Card>
          <CardContent className="p-6">
            <label className="block text-lg font-medium text-gray-800 mb-4">
              ¿Tienes antecedentes familiares de enfermedad cardiovascular?
            </label>
            <div className="flex gap-4">
              <button
                onClick={() => setFormData({...formData, riskFactors: {...formData.riskFactors, familyHistory: true}})}
                className={`flex-1 p-4 rounded-lg font-medium transition-all ${
                  formData.riskFactors.familyHistory === true
                    ? 'bg-red-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Sí
              </button>
              <button
                onClick={() => setFormData({...formData, riskFactors: {...formData.riskFactors, familyHistory: false}})}
                className={`flex-1 p-4 rounded-lg font-medium transition-all ${
                  formData.riskFactors.familyHistory === false
                    ? 'bg-green-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                No
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Tabaquismo */}
        <Card>
          <CardContent className="p-6">
            <label className="block text-lg font-medium text-gray-800 mb-4">
              ¿Fumas actualmente o fumaste en el último año?
            </label>
            <div className="flex gap-4">
              <button
                onClick={() => setFormData({...formData, riskFactors: {...formData.riskFactors, smoking: true}})}
                className={`flex-1 p-4 rounded-lg font-medium transition-all ${
                  formData.riskFactors.smoking === true
                    ? 'bg-red-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Sí
              </button>
              <button
                onClick={() => setFormData({...formData, riskFactors: {...formData.riskFactors, smoking: false}})}
                className={`flex-1 p-4 rounded-lg font-medium transition-all ${
                  formData.riskFactors.smoking === false
                    ? 'bg-green-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                No
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Actividad física */}
        <Card>
          <CardContent className="p-6">
            <label className="block text-lg font-medium text-gray-800 mb-4">
              ¿Realizas actividad física regular? (al menos 150 min/semana)
            </label>
            <div className="flex gap-4">
              <button
                onClick={() => setFormData({...formData, riskFactors: {...formData.riskFactors, physicalActivity: true}})}
                className={`flex-1 p-4 rounded-lg font-medium transition-all ${
                  formData.riskFactors.physicalActivity === true
                    ? 'bg-green-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Sí
              </button>
              <button
                onClick={() => setFormData({...formData, riskFactors: {...formData.riskFactors, physicalActivity: false}})}
                className={`flex-1 p-4 rounded-lg font-medium transition-all ${
                  formData.riskFactors.physicalActivity === false
                    ? 'bg-red-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                No
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Condiciones crónicas */}
        <Card>
          <CardContent className="p-6">
            <label className="block text-lg font-medium text-gray-800 mb-4">
              ¿Te han diagnosticado hipertensión, diabetes o colesterol alto?
            </label>
            <div className="flex gap-4">
              <button
                onClick={() => setFormData({...formData, riskFactors: {...formData.riskFactors, chronicConditions: true}})}
                className={`flex-1 p-4 rounded-lg font-medium transition-all ${
                  formData.riskFactors.chronicConditions === true
                    ? 'bg-red-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Sí
              </button>
              <button
                onClick={() => setFormData({...formData, riskFactors: {...formData.riskFactors, chronicConditions: false}})}
                className={`flex-1 p-4 rounded-lg font-medium transition-all ${
                  formData.riskFactors.chronicConditions === false
                    ? 'bg-green-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                No
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Horas de sueño */}
        <Card>
          <CardContent className="p-6">
            <label className="block text-lg font-medium text-gray-800 mb-4">
              ¿Cuántas horas duermes habitualmente por noche?
            </label>
            <input
              type="number"
              min="0"
              max="12"
              value={formData.riskFactors.sleepHours || ''}
              onChange={(e) => setFormData({...formData, riskFactors: {...formData.riskFactors, sleepHours: parseInt(e.target.value)}})}
              className="w-full p-4 text-lg border-2 border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none"
              placeholder="Ej: 7"
            />
          </CardContent>
        </Card>

        {/* Estrés */}
        <Card>
          <CardContent className="p-6">
            <label className="block text-lg font-medium text-gray-800 mb-4">
              ¿Sientes estrés frecuente o ansiedad?
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {['nunca', 'a-veces', 'frecuente', 'siempre'].map((level) => (
                <button
                  key={level}
                  onClick={() => setFormData({...formData, riskFactors: {...formData.riskFactors, stress: level}})}
                  className={`p-4 rounded-lg font-medium transition-all ${
                    formData.riskFactors.stress === level
                      ? 'bg-purple-500 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {level.charAt(0).toUpperCase() + level.slice(1).replace('-', ' ')}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {Object.keys(formData.riskFactors).length >= 6 && (
        <button
          onClick={() => setStep(3.5)}
          className="w-full px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-600 text-white text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
        >
          Ver mis resultados →
        </button>
      )}
    </div>
  );

  const renderRiskResults = () => {
    const riskScore = calculateRiskScore();
    const suggestedObjectives = getSuggestedObjectives();
    
    return (
      <div className="space-y-8 animate-fade-in max-w-3xl mx-auto">
        <div className="text-center space-y-4">
          <div className={`inline-block px-8 py-4 rounded-2xl ${
            riskScore <= 3 ? 'bg-green-100' :
            riskScore <= 6 ? 'bg-yellow-100' :
            'bg-red-100'
          }`}>
            <h2 className="text-4xl font-bold">
              {riskScore <= 3 ? '✅ Riesgo Bajo' :
               riskScore <= 6 ? '⚠️ Riesgo Moderado' :
               '🚨 Riesgo Alto'}
            </h2>
            <p className="text-lg text-gray-600 mt-2">Puntuación: {riskScore}/13</p>
          </div>
        </div>

        <Alert className="bg-blue-50 border-blue-200">
          <AlertDescription>
            <strong>📋 Recomendación personalizada:</strong> Basándonos en tu evaluación, 
            te sugerimos enfocarte en los siguientes aspectos de Life's Essential 8:
          </AlertDescription>
        </Alert>

        <div className="grid md:grid-cols-2 gap-4">
          {suggestedObjectives.map(objId => {
            const objetivo = lifesEssential8.find(o => o.id === objId);
            return objetivo ? (
              <Card key={objId} className="bg-gradient-to-br from-purple-50 to-pink-50">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{objetivo.icon}</span>
                    <span className="font-semibold text-gray-800">{objetivo.label}</span>
                  </div>
                </CardContent>
              </Card>
            ) : null;
          })}
        </div>

        <div className="space-y-4">
          <h3 className="text-xl font-bold text-gray-800 text-center">
            ¿Cómo te gustaría continuar?
          </h3>
          <div className="grid md:grid-cols-2 gap-4">
            <button
              onClick={() => {
                setFormData({...formData, seguimiento: 'consulta', objetivos: suggestedObjectives});
                setStep(4);
              }}
              className="p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all text-left"
            >
              <div className="text-3xl mb-3">👨‍⚕️</div>
              <h4 className="font-bold text-lg text-gray-800 mb-2">
                Consulta de Atención Primaria
              </h4>
              <p className="text-sm text-gray-600">
                Agenda una evaluación completa con nuestro equipo médico
              </p>
            </button>

            <button
              onClick={() => {
                setFormData({...formData, seguimiento: 'programa', objetivos: suggestedObjectives});
                setStep(4);
              }}
              className="p-6 bg-gradient-to-br from-purple-500 to-pink-600 text-white rounded-xl shadow-lg hover:shadow-xl transition-all text-left"
            >
              <div className="text-3xl mb-3">🚀</div>
              <h4 className="font-bold text-lg mb-2">
                Comenzar Programa Personalizado
              </h4>
              <p className="text-sm opacity-90">
                Inicia tu plan basado en estas recomendaciones
              </p>
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderConsent = () => (
    <div className="space-y-8 animate-fade-in max-w-2xl mx-auto">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">
          ¡Casi listo! 🎉
        </h2>
        <p className="text-gray-600">
          Solo necesitamos tu consentimiento para comenzar
        </p>
      </div>

      <Card>
        <CardContent className="p-6 space-y-4">
          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.consent.terms || false}
              onChange={(e) => setFormData({...formData, consent: {...formData.consent, terms: e.target.checked}})}
              className="mt-1 w-5 h-5 text-purple-600 rounded"
            />
            <span className="text-gray-700">
              He leído y acepto los <strong>términos del programa</strong> y la política de privacidad
            </span>
          </label>

          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.consent.dataUsage || false}
              onChange={(e) => setFormData({...formData, consent: {...formData.consent, dataUsage: e.target.checked}})}
              className="mt-1 w-5 h-5 text-purple-600 rounded"
            />
            <span className="text-gray-700">
              Autorizo el uso de mis datos de salud para <strong>personalizar mi plan de cuidado</strong> según estándares FHIR R4
            </span>
          </label>

          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.consent.notifications || false}
              onChange={(e) => setFormData({...formData, consent: {...formData.consent, notifications: e.target.checked}})}
              className="mt-1 w-5 h-5 text-purple-600 rounded"
            />
            <span className="text-gray-700">
              Deseo recibir notificaciones y recordatorios sobre mi salud (opcional)
            </span>
          </label>
        </CardContent>
      </Card>

      {formData.consent.terms && formData.consent.dataUsage && (
        <button
          onClick={() => setStep(5)}
          className="w-full px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
        >
          Finalizar y crear mi plan →
        </button>
      )}
    </div>
  );

  const renderSuccess = () => {
    const selectedGrupo = grupos.find(g => g.id === formData.grupo);
    
    return (
      <div className="space-y-8 animate-fade-in text-center max-w-2xl mx-auto">
        <div className="text-6xl mb-4">🎉</div>
        <h2 className="text-4xl font-bold text-gray-800">
          ¡Bienvenida al Programa MUJER!
        </h2>
        
        <Card className="bg-gradient-to-br from-purple-50 to-pink-50">
          <CardContent className="p-8 space-y-6">
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">
                {selectedGrupo?.emoji} {selectedGrupo?.title}
              </h3>
              <p className="text-gray-600">{selectedGrupo?.description}</p>
            </div>

            <div className="border-t border-gray-200 pt-6">
              <h4 className="font-bold text-gray-800 mb-3">Tus objetivos seleccionados:</h4>
              <div className="flex flex-wrap gap-2 justify-center">
                {formData.objetivos.map(objId => {
                  const objetivo = lifesEssential8.find(o => o.id === objId);
                  return objetivo ? (
                    <span key={objId} className="px-4 py-2 bg-white rounded-full text-sm font-medium text-gray-700 shadow">
                      {objetivo.icon} {objetivo.label}
                    </span>
                  ) : null;
                })}
              </div>
            </div>

            {formData.seguimiento && (
              <div className="border-t border-gray-200 pt-6">
                <p className="text-gray-700">
                  <strong>Próximos pasos:</strong>{' '}
                  {formData.seguimiento === 'consulta' 
                    ? 'Te contactaremos para agendar tu consulta de atención primaria'
                    : 'Estamos generando tu plan personalizado basado en FHIR R4'}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <p className="text-gray-600">
            Revisa tu email para acceder a tu dashboard personalizado
          </p>
          <button
            onClick={() => window.location.href = 'https://mujer.epa-bienestar.com.ar/dashboard'}
            className="px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-600 text-white text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
          >
            Ir a mi Dashboard →
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Progress bar */}
        {step > 0 && step < 5 && (
          <div className="mb-8">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Paso {step} de 4</span>
              <span>{Math.round((step / 4) * 100)}%</span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-purple-500 to-pink-600 transition-all duration-500"
                style={{ width: `${(step / 4) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* Content */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12">
          {step === 0 && renderWelcome()}
          {step === 1 && renderGrupoSelection()}
          {step === 2 && renderObjetivosSelection()}
          {step === 3 && showRiskAssessment && renderRiskAssessment()}
          {step === 3.5 && renderRiskResults()}
          {step === 4 && renderConsent()}
          {step === 5 && renderSuccess()}
        </div>

        {/* Back button */}
        {step > 1 && step < 5 && (
          <button
            onClick={() => setStep(Math.max(0, step - 1))}
            className="mt-4 text-gray-600 hover:text-gray-800 font-medium"
          >
            ← Volver
          </button>
        )}
      </div>

      <style jsx>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in {
          animation: fade-in 0.5s ease-out;
        }
      `}</style>
    </div>
  );
};

export default OnboardingProgramaMujer;
