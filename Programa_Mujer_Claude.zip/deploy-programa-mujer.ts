#!/usr/bin/env ts-node

/**
 * Script de Despliegue - Programa MUJER
 * 
 * Despliega todos los recursos FHIR necesarios en el servidor Medplum:
 * - Questionnaire
 * - PlanDefinitions (4 grupos)
 * - Subscriptions
 * - Bots
 * - Practitioner y Organization
 * 
 * Uso:
 *   npm install @medplum/core @medplum/fhirtypes
 *   ts-node deploy-programa-mujer.ts
 */

import { MedplumClient } from '@medplum/core';
import { Bundle } from '@medplum/fhirtypes';
import * as fs from 'fs';
import * as path from 'path';

// Configuración
const MEDPLUM_CONFIG = {
  baseUrl: 'https://api.epa-bienestar.com.ar/fhir/r4',
  clientId: process.env.MEDPLUM_CLIENT_ID || '',
  clientSecret: process.env.MEDPLUM_CLIENT_SECRET || '',
  projectId: process.env.MEDPLUM_PROJECT_ID || '0196365c-1838-7299-92e2-3e2bce7a42fd'
};

async function main() {
  console.log('🚀 Iniciando despliegue del Programa MUJER\n');
  
  // Inicializar cliente Medplum
  const medplum = new MedplumClient({
    baseUrl: MEDPLUM_CONFIG.baseUrl,
    clientId: MEDPLUM_CONFIG.clientId,
    clientSecret: MEDPLUM_CONFIG.clientSecret
  });
  
  try {
    // Autenticar
    console.log('🔐 Autenticando...');
    await medplum.startClientLogin(
      MEDPLUM_CONFIG.clientId,
      MEDPLUM_CONFIG.clientSecret
    );
    console.log('✅ Autenticación exitosa\n');
    
    // 1. Desplegar Questionnaire
    console.log('📋 Desplegando Questionnaire...');
    const questionnaire = JSON.parse(
      fs.readFileSync(path.join(__dirname, 'questionnaire-onboarding-mujer.json'), 'utf8')
    );
    await medplum.createResourceIfNoneExist(questionnaire, 'url');
    console.log('✅ Questionnaire desplegado\n');
    
    // 2. Desplegar PlanDefinitions
    console.log('📚 Desplegando PlanDefinitions...');
    const planDefinitionsBundle: Bundle = JSON.parse(
      fs.readFileSync(path.join(__dirname, 'plan-definitions-programa-mujer.json'), 'utf8')
    );
    
    for (const entry of planDefinitionsBundle.entry || []) {
      if (entry.resource?.resourceType === 'PlanDefinition') {
        await medplum.createResourceIfNoneExist(entry.resource, 'url');
        console.log(`  ✅ ${entry.resource.title}`);
      }
    }
    console.log('');
    
    // 3. Desplegar Bot
    console.log('🤖 Desplegando Bot...');
    const botCode = fs.readFileSync(
      path.join(__dirname, 'medplum-bot-onboarding-processor.ts'),
      'utf8'
    );
    
    const bot = await medplum.createResource({
      resourceType: 'Bot',
      name: 'onboarding-programa-mujer-processor',
      description: 'Procesa QuestionnaireResponse y crea CarePlan automáticamente',
      runtimeVersion: 'vmcontext',
      code: botCode
    });
    console.log(`✅ Bot desplegado: ${bot.id}\n`);
    
    // 4. Desplegar Subscriptions y configuración
    console.log('🔔 Desplegando Subscriptions...');
    const configBundle: Bundle = JSON.parse(
      fs.readFileSync(path.join(__dirname, 'subscriptions-and-config.json'), 'utf8')
    );
    
    await medplum.executeBatch(configBundle);
    console.log('✅ Subscriptions y configuración desplegados\n');
    
    // 5. Verificar despliegue
    console.log('🔍 Verificando recursos...');
    const verification = await verifyDeployment(medplum);
    
    console.log('\n📊 Resumen de Despliegue:');
    console.log(`   Questionnaire: ${verification.questionnaire ? '✅' : '❌'}`);
    console.log(`   PlanDefinitions: ${verification.planDefinitions}/4`);
    console.log(`   Bot: ${verification.bot ? '✅' : '❌'}`);
    console.log(`   Subscriptions: ${verification.subscriptions}/2`);
    console.log(`   Organization: ${verification.organization ? '✅' : '❌'}`);
    console.log(`   Practitioner: ${verification.practitioner ? '✅' : '❌'}`);
    
    if (verification.allComplete) {
      console.log('\n🎉 ¡Despliegue completado exitosamente!');
      console.log('\n📝 Próximos pasos:');
      console.log('1. Integrar el componente React en https://mujer.epa-bienestar.com.ar');
      console.log('2. Configurar redirección después del registro');
      console.log('3. Probar el flujo completo con un paciente de prueba');
      console.log('4. Monitorear logs del bot en Medplum');
    } else {
      console.log('\n⚠️  Despliegue incompleto. Revisa los errores arriba.');
    }
    
  } catch (error) {
    console.error('❌ Error en el despliegue:', error);
    process.exit(1);
  }
}

async function verifyDeployment(medplum: MedplumClient): Promise<{
  questionnaire: boolean;
  planDefinitions: number;
  bot: boolean;
  subscriptions: number;
  organization: boolean;
  practitioner: boolean;
  allComplete: boolean;
}> {
  const result = {
    questionnaire: false,
    planDefinitions: 0,
    bot: false,
    subscriptions: 0,
    organization: false,
    practitioner: false,
    allComplete: false
  };
  
  try {
    // Verificar Questionnaire
    const questionnaires = await medplum.searchResources('Questionnaire', {
      url: 'https://api.epa-bienestar.com.ar/fhir/r4/Questionnaire/onboarding-programa-mujer'
    });
    result.questionnaire = questionnaires.length > 0;
    
    // Verificar PlanDefinitions
    const planDefs = await medplum.searchResources('PlanDefinition', {
      url: 'https://api.epa-bienestar.com.ar/fhir/r4/PlanDefinition/programa-mujer'
    });
    result.planDefinitions = planDefs.length;
    
    // Verificar Bot
    const bots = await medplum.searchResources('Bot', {
      name: 'onboarding-programa-mujer-processor'
    });
    result.bot = bots.length > 0;
    
    // Verificar Subscriptions
    const subscriptions = await medplum.searchResources('Subscription', {
      status: 'active'
    });
    result.subscriptions = subscriptions.filter(
      s => s.reason?.includes('Programa MUJER') || s.reason?.includes('goal-progress')
    ).length;
    
    // Verificar Organization
    const orgs = await medplum.searchResources('Organization', {
      _id: 'epa-bienestar'
    });
    result.organization = orgs.length > 0;
    
    // Verificar Practitioner
    const practitioners = await medplum.searchResources('Practitioner', {
      _id: 'programa-mujer-system'
    });
    result.practitioner = practitioners.length > 0;
    
    result.allComplete = 
      result.questionnaire &&
      result.planDefinitions === 4 &&
      result.bot &&
      result.subscriptions === 2 &&
      result.organization &&
      result.practitioner;
    
  } catch (error) {
    console.error('Error en verificación:', error);
  }
  
  return result;
}

// Ejecutar
main();

/**
 * INSTRUCCIONES DE USO:
 * 
 * 1. Configurar variables de entorno:
 *    export MEDPLUM_CLIENT_ID="tu-client-id"
 *    export MEDPLUM_CLIENT_SECRET="tu-client-secret"
 *    export MEDPLUM_PROJECT_ID="0196365c-1838-7299-92e2-3e2bce7a42fd"
 * 
 * 2. Instalar dependencias:
 *    npm install @medplum/core @medplum/fhirtypes
 * 
 * 3. Ejecutar:
 *    ts-node deploy-programa-mujer.ts
 * 
 * 4. Verificar en Medplum:
 *    - Questionnaires: https://api.epa-bienestar.com.ar/admin/Questionnaire
 *    - PlanDefinitions: https://api.epa-bienestar.com.ar/admin/PlanDefinition
 *    - Bots: https://api.epa-bienestar.com.ar/admin/Bot
 *    - Subscriptions: https://api.epa-bienestar.com.ar/admin/Subscription
 */
