# 🌸 Programa MUJER - Sistema de Onboarding FHIR R4

Sistema completo de onboarding para el Programa MUJER de EPA Bienestar, implementado con estándares FHIR R4 y automatización mediante Medplum.

## 📋 Descripción General

Este sistema permite:
- **Identificación de grupo** según etapa de vida de la paciente (A, B, C, D)
- **Selección de objetivos** basados en Life's Essential 8 de la AHA
- **Evaluación rápida de riesgo** cardiovascular
- **Generación automática de CarePlan** personalizado
- **Asignación de Goals SMART** con métricas medibles
- **Agendamiento de consultas** cuando corresponda
- **Notificaciones automáticas** y seguimiento continuo

## 🏗️ Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────────┐
│           Paciente en mujer.epa-bienestar.com.ar            │
│                    Completa onboarding                       │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              QuestionnaireResponse (FHIR R4)                 │
│  • Grupo seleccionado (A, B, C, D)                          │
│  • Objetivos Life's Essential 8                             │
│  • Evaluación de factores de riesgo                         │
│  • Preferencia de seguimiento                               │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼ Subscription trigger
┌─────────────────────────────────────────────────────────────┐
│         Bot: onboarding-programa-mujer-processor            │
│                                                             │
│  1. Calcula Risk Score                                     │
│  2. Crea Goals basados en objetivos                        │
│  3. Crea Condition si hay riesgo significativo             │
│  4. Aplica PlanDefinition según grupo                      │
│  5. Genera CarePlan personalizado                          │
│  6. Agenda ServiceRequest si corresponde                   │
│  7. Crea Observations iniciales                            │
│  8. Envía Communication de bienvenida                      │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                   Recursos FHIR Creados                     │
│                                                             │
│  • CarePlan (activo, con activities)                       │
│  • Goals (1-8 según objetivos seleccionados)               │
│  • Condition (si Risk Score >= 5)                          │
│  • ServiceRequest (si eligió consulta)                     │
│  • Task (agendamiento pendiente)                           │
│  • Observations (línea base)                               │
│  • Communication (bienvenida)                              │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│            Dashboard Paciente + Equipo Médico               │
│  • Vista del CarePlan activo                               │
│  • Progreso de Goals en tiempo real                        │
│  • Recordatorios y alertas                                 │
│  • Integración con wearables                               │
└─────────────────────────────────────────────────────────────┘
```

## 📦 Componentes del Sistema

### 1. Questionnaire FHIR
- **Archivo**: `questionnaire-onboarding-mujer.json`
- **URL**: `Questionnaire/onboarding-programa-mujer`
- **Secciones**:
  - Selección de grupo (4 opciones)
  - Life's Essential 8 (8 objetivos + "No sé")
  - Evaluación rápida de riesgo (6 preguntas)
  - Preferencia de seguimiento
  - Consentimientos

### 2. PlanDefinitions (4 grupos)
- **Archivo**: `plan-definitions-programa-mujer.json`
- **Grupos**:
  - **Grupo A**: Construyendo Bases Sólidas (18-35 años)
  - **Grupo B**: Salud Cardiovascular y Fertilidad (25-40 años)
  - **Grupo C**: Navegando la Transición Hormonal (45-60 años)
  - **Grupo D**: Longevidad Activa y Saludable (60+ años)

Cada PlanDefinition incluye:
- Goals específicos con targets medibles
- Actions (ActivityDefinitions) personalizadas
- UseContext (edad, género, foco)

### 3. Bot de Procesamiento
- **Archivo**: `medplum-bot-onboarding-processor.ts`
- **Funciones**:
  - Extrae respuestas del QuestionnaireResponse
  - Calcula Risk Score (0-13 puntos)
  - Crea Goals SMART para cada objetivo
  - Aplica PlanDefinition correspondiente
  - Genera CarePlan completo
  - Agenda ServiceRequest si necesario
  - Envía notificaciones

### 4. Interfaz React
- **Archivo**: `onboarding-programa-mujer.jsx`
- **Features**:
  - Wizard paso a paso
  - Progress bar visual
  - Selección de grupo con cards interactivas
  - Checkboxes para Life's Essential 8
  - Evaluación de riesgo dinámica
  - Cálculo de Risk Score en tiempo real
  - Sugerencias personalizadas
  - Diseño responsive y accesible

### 5. Subscriptions
- **Archivo**: `subscriptions-and-config.json`
- **Triggers**:
  - QuestionnaireResponse → Bot processor
  - Observation → Goal progress evaluator

## 🚀 Despliegue

### Requisitos Previos
```bash
npm install @medplum/core @medplum/fhirtypes typescript ts-node
```

### Variables de Entorno
```bash
export MEDPLUM_CLIENT_ID="tu-client-id"
export MEDPLUM_CLIENT_SECRET="tu-client-secret"
export MEDPLUM_PROJECT_ID="0196365c-1838-7299-92e2-3e2bce7a42fd"
```

### Ejecución
```bash
ts-node deploy-programa-mujer.ts
```

### Verificación Manual
1. **Questionnaire**: `GET /fhir/r4/Questionnaire/onboarding-programa-mujer`
2. **PlanDefinitions**: `GET /fhir/r4/PlanDefinition?url:contains=programa-mujer`
3. **Bot**: `GET /admin/Bot?name=onboarding-programa-mujer-processor`
4. **Subscriptions**: `GET /fhir/r4/Subscription?status=active`

## 🎯 Life's Essential 8 - Mapping

| Objetivo | FHIR Code | Goal Target | Métrica |
|----------|-----------|-------------|---------|
| Nutrición | SNOMED:226234005 | Mediterranean Diet Score ≥ 9 | LOINC:89574-8 |
| Actividad Física | SNOMED:68130003 | ≥ 150 min/week | LOINC:82290-8 |
| Sueño | SNOMED:258158006 | 7-9 horas/noche | LOINC:93832-4 |
| No Fumar | SNOMED:8517006 | ≥ 90 días sin fumar | - |
| Circunferencia | LOINC:8280-0 | < 88 cm | LOINC:8280-0 |
| Presión Arterial | LOINC:85354-9 | < 120/80 mmHg | LOINC:8480-6 |
| Colesterol | LOINC:2093-3 | LDL < 100 mg/dL | LOINC:18262-6 |
| Glucosa | LOINC:2339-0 | < 100 mg/dL | LOINC:2339-0 |

## 📊 Risk Score Calculation

```typescript
function calculateRiskScore(riskFactors): number {
  let score = 0;
  if (riskFactors.familyHistory) score += 2;      // Antecedentes familiares
  if (riskFactors.smoking) score += 3;            // Tabaquismo
  if (!riskFactors.physicalActivity) score += 2;  // Sedentarismo
  if (riskFactors.chronicConditions) score += 3;  // HTA/DM/Dislipidemia
  if (sleepHours < 6 || > 9) score += 1;         // Sueño inadecuado
  if (stress === 'frecuente|siempre') score += 2; // Estrés crónico
  return score; // 0-13
}
```

**Interpretación**:
- **0-3**: Riesgo Bajo ✅
- **4-6**: Riesgo Moderado ⚠️
- **7-13**: Riesgo Alto 🚨

## 🔄 Flujo de Integración en mujer.epa-bienestar.com.ar

### 1. Página de Registro
```jsx
// App.tsx
import OnboardingProgramaMujer from './components/OnboardingProgramaMujer';

function App() {
  return (
    <Routes>
      <Route path="/registro" element={<OnboardingProgramaMujer />} />
      {/* ... otras rutas */}
    </Routes>
  );
}
```

### 2. Envío del QuestionnaireResponse
```typescript
// En el componente React, después de completar el onboarding:
const submitOnboarding = async (formData) => {
  const questionnaireResponse = {
    resourceType: 'QuestionnaireResponse',
    questionnaire: 'Questionnaire/onboarding-programa-mujer',
    status: 'completed',
    authored: new Date().toISOString(),
    subject: {
      reference: `Patient/${patientId}`,
      display: patientName
    },
    item: [
      {
        linkId: '2',
        answer: [{
          valueCoding: {
            system: 'https://api.epa-bienestar.com.ar/fhir/CodeSystem/programa-mujer-grupos',
            code: formData.grupo
          }
        }]
      },
      {
        linkId: '3',
        answer: formData.objetivos.map(obj => ({
          valueCoding: { /* ... */ }
        }))
      }
      // ... más items
    ]
  };
  
  const response = await fetch(
    'https://api.epa-bienestar.com.ar/fhir/r4/QuestionnaireResponse',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/fhir+json',
        'Authorization': `Bearer ${accessToken}`
      },
      body: JSON.stringify(questionnaireResponse)
    }
  );
  
  if (response.ok) {
    // Redireccionar al dashboard
    window.location.href = '/dashboard';
  }
};
```

### 3. El Bot se ejecuta automáticamente
- La Subscription detecta el nuevo QuestionnaireResponse
- Invoca el Bot `onboarding-programa-mujer-processor`
- Crea todos los recursos (CarePlan, Goals, etc.)
- Envía notificaciones

### 4. Dashboard muestra el CarePlan
```typescript
// Dashboard.tsx
const Dashboard = () => {
  const [carePlan, setCarePlan] = useState(null);
  const [goals, setGoals] = useState([]);
  
  useEffect(() => {
    // Buscar CarePlan activo
    fetch(`https://api.epa-bienestar.com.ar/fhir/r4/CarePlan?patient=${patientId}&status=active`)
      .then(res => res.json())
      .then(data => {
        const plan = data.entry?.[0]?.resource;
        setCarePlan(plan);
        
        // Cargar Goals
        plan.goal.forEach(goalRef => {
          fetch(`https://api.epa-bienestar.com.ar/fhir/r4/${goalRef.reference}`)
            .then(res => res.json())
            .then(goal => setGoals(prev => [...prev, goal]));
        });
      });
  }, [patientId]);
  
  return (
    <div>
      <h1>{carePlan?.title}</h1>
      <GoalsList goals={goals} />
      {/* ... */}
    </div>
  );
};
```

## 🔔 Notificaciones y Alertas

### Tipos de Notificaciones
1. **Bienvenida**: Después de completar onboarding
2. **Recordatorios**: Goals próximos a vencer
3. **Alertas**: Observations fuera de rango
4. **Progreso**: Logros alcanzados

### Implementación con Subscription
```json
{
  "resourceType": "Subscription",
  "criteria": "Observation?category=vital-signs&_filter=value gt referenceRange.high",
  "channel": {
    "type": "rest-hook",
    "endpoint": "Bot/observation-alert-handler",
    "payload": "application/fhir+json"
  }
}
```

## 📈 Monitoreo y Analytics

### Métricas Clave
- **Tasa de completitud**: % de pacientes que completan el onboarding
- **Distribución de grupos**: A, B, C, D
- **Objetivos más seleccionados**: Top 3 de Life's Essential 8
- **Risk Score promedio**: Por grupo
- **Adherencia a Goals**: % de goals alcanzados

### Queries GraphQL
```graphql
query DashboardMetrics {
  QuestionnaireResponseList(
    questionnaire: "Questionnaire/onboarding-programa-mujer",
    _count: 1000
  ) {
    count
  }
  
  CarePlanList(status: "active", _count: 1000) {
    resourceType
    title
    subject { display }
    goal { reference }
    activity { detail { status } }
  }
}
```

## 🛠️ Mantenimiento y Actualizaciones

### Agregar Nuevo Objetivo
1. Actualizar `OBJETIVO_TO_GOAL` en el bot
2. Agregar opción en el Questionnaire
3. Actualizar PlanDefinitions relevantes
4. Redesplegar con `ts-node deploy-programa-mujer.ts`

### Modificar Risk Score
1. Editar `calculateRiskScore()` en el bot
2. Actualizar umbrales de clasificación
3. Redesplegar bot

### Nuevo Grupo
1. Crear PlanDefinition en `plan-definitions-programa-mujer.json`
2. Agregar mapping en `GRUPO_TO_PLAN`
3. Actualizar interfaz React con nueva card
4. Redesplegar

## 🔒 Seguridad y Compliance

### FHIR Security
- Autenticación OAuth2 con Medplum
- Compartmentalization por proyecto
- Patient consent tracking
- Audit logs automáticos

### HIPAA Compliance
- PHI en recursos FHIR protegidos
- Encriptación en tránsito (HTTPS)
- Encriptación en reposo (Medplum)
- Access controls granulares

### Privacidad
- Consent explícito antes de crear recursos
- Opt-in para notificaciones
- Derecho a eliminación (GDPR)

## 📞 Soporte y Contacto

**Desarrollador**: Alejandro S. D'Alessandro MD  
**Organización**: EPA Bienestar IA  
**FHIR Server**: https://api.epa-bienestar.com.ar/fhir/r4  
**Plataforma Web**: https://mujer.epa-bienestar.com.ar  

---

## 🎓 Referencias

- [FHIR R4 Specification](https://hl7.org/fhir/R4/)
- [Life's Essential 8 - AHA](https://www.heart.org/en/healthy-living/healthy-lifestyle/lifes-essential-8)
- [Medplum Documentation](https://www.medplum.com/docs)
- [SAC Consenso 2023 Prevención CV](https://www.sac.org.ar/consensos/)

---

**Versión**: 1.0  
**Última actualización**: 2025-12-19  
**Estado**: ✅ Producción
