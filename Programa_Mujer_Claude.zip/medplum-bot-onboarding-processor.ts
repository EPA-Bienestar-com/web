/**
 * Medplum Bot: onboarding-programa-mujer-processor
 * 
 * Procesa el QuestionnaireResponse del onboarding y automáticamente:
 * 1. Aplica el PlanDefinition correspondiente al grupo seleccionado
 * 2. Crea Goals basados en los objetivos de Life's Essential 8
 * 3. Genera el CarePlan personalizado
 * 4. Agenda Appointment si corresponde
 * 5. Crea Tasks de seguimiento
 * 
 * Trigger: Subscription en QuestionnaireResponse con criteria="Questionnaire/onboarding-programa-mujer"
 */

import { BotEvent, MedplumClient, Observation } from '@medplum/core';
import {
  CarePlan,
  Goal,
  Patient,
  QuestionnaireResponse,
  QuestionnaireResponseItem,
  Appointment,
  Task,
  ServiceRequest,
  Condition,
  CareTeam,
  Reference
} from '@medplum/fhirtypes';

// Mapeo de grupos a PlanDefinitions
const GRUPO_TO_PLAN: Record<string, string> = {
  'grupo-a': 'PlanDefinition/programa-mujer-grupo-a',
  'grupo-b': 'PlanDefinition/programa-mujer-grupo-b',
  'grupo-c': 'PlanDefinition/programa-mujer-grupo-c',
  'grupo-d': 'PlanDefinition/programa-mujer-grupo-d'
};

// Mapeo de objetivos a Goals SMART
const OBJETIVO_TO_GOAL: Record<string, {
  description: string;
  category: string;
  target: any;
  priority: string;
}> = {
  'nutricion': {
    description: 'Adoptar patrón alimentario mediterráneo',
    category: 'dietary',
    target: {
      measure: {
        coding: [{
          system: 'http://loinc.org',
          code: '89574-8',
          display: 'Mediterranean Diet Score'
        }]
      },
      detailQuantity: {
        value: 9,
        comparator: '>=',
        unit: '{score}'
      },
      dueDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] // 6 meses
    },
    priority: 'high-priority'
  },
  'actividad-fisica': {
    description: 'Lograr 150 minutos de actividad física moderada por semana',
    category: 'physiotherapy',
    target: {
      measure: {
        coding: [{
          system: 'http://loinc.org',
          code: '82290-8',
          display: 'Physical activity minutes per week'
        }]
      },
      detailQuantity: {
        value: 150,
        comparator: '>=',
        unit: 'min/week'
      },
      dueDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] // 3 meses
    },
    priority: 'high-priority'
  },
  'sueno': {
    description: 'Dormir 7-9 horas de calidad por noche',
    category: 'behavioral',
    target: {
      measure: {
        coding: [{
          system: 'http://loinc.org',
          code: '93832-4',
          display: 'Sleep duration'
        }]
      },
      detailRange: {
        low: { value: 7, unit: 'h' },
        high: { value: 9, unit: 'h' }
      },
      dueDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] // 2 meses
    },
    priority: 'medium-priority'
  },
  'no-fumar': {
    description: 'Cesación completa del tabaquismo',
    category: 'behavioral',
    target: {
      measure: {
        text: 'Días sin fumar'
      },
      detailQuantity: {
        value: 90,
        comparator: '>=',
        unit: 'd'
      },
      dueDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    },
    priority: 'high-priority'
  },
  'circunferencia': {
    description: 'Mantener circunferencia abdominal saludable',
    category: 'physiotherapy',
    target: {
      measure: {
        coding: [{
          system: 'http://loinc.org',
          code: '8280-0',
          display: 'Waist circumference'
        }]
      },
      detailQuantity: {
        value: 88,
        comparator: '<',
        unit: 'cm'
      },
      dueDate: new Date(Date.now() + 120 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    },
    priority: 'medium-priority'
  },
  'presion': {
    description: 'Control óptimo de presión arterial',
    category: 'physiotherapy',
    target: {
      measure: {
        coding: [{
          system: 'http://loinc.org',
          code: '8480-6',
          display: 'Systolic blood pressure'
        }]
      },
      detailQuantity: {
        value: 120,
        comparator: '<',
        unit: 'mm[Hg]'
      },
      dueDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    },
    priority: 'high-priority'
  },
  'colesterol': {
    description: 'Lograr niveles óptimos de colesterol LDL',
    category: 'physiotherapy',
    target: {
      measure: {
        coding: [{
          system: 'http://loinc.org',
          code: '18262-6',
          display: 'LDL Cholesterol'
        }]
      },
      detailQuantity: {
        value: 100,
        comparator: '<',
        unit: 'mg/dL'
      },
      dueDate: new Date(Date.now() + 120 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    },
    priority: 'high-priority'
  },
  'glucosa': {
    description: 'Mantener glucemia en rango normal',
    category: 'physiotherapy',
    target: {
      measure: {
        coding: [{
          system: 'http://loinc.org',
          code: '2339-0',
          display: 'Glucose'
        }]
      },
      detailQuantity: {
        value: 100,
        comparator: '<',
        unit: 'mg/dL'
      },
      dueDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    },
    priority: 'high-priority'
  }
};

export async function handler(medplum: MedplumClient, event: BotEvent): Promise<any> {
  const questionnaireResponse = event.input as QuestionnaireResponse;
  
  console.log('📋 Procesando QuestionnaireResponse:', questionnaireResponse.id);
  
  // Extraer datos del cuestionario
  const responses = extractResponses(questionnaireResponse);
  
  if (!responses.grupo) {
    throw new Error('No se seleccionó ningún grupo');
  }
  
  // Obtener o crear el paciente
  const patient = questionnaireResponse.subject as Reference<Patient>;
  
  // 1. Calcular risk score si completó la evaluación
  let riskScore = 0;
  if (responses.riskFactors) {
    riskScore = calculateRiskScore(responses.riskFactors);
    console.log('🔍 Risk Score calculado:', riskScore);
  }
  
  // 2. Crear Goals basados en objetivos seleccionados
  const goals: Reference<Goal>[] = [];
  for (const objetivo of responses.objetivos) {
    if (objetivo === 'no-se') continue;
    
    const goalConfig = OBJETIVO_TO_GOAL[objetivo];
    if (!goalConfig) continue;
    
    const goal = await medplum.createResource<Goal>({
      resourceType: 'Goal',
      lifecycleStatus: 'active',
      achievementStatus: {
        coding: [{
          system: 'http://terminology.hl7.org/CodeSystem/goal-achievement',
          code: 'in-progress'
        }]
      },
      category: [{
        coding: [{
          system: 'http://terminology.hl7.org/CodeSystem/goal-category',
          code: goalConfig.category
        }]
      }],
      priority: {
        coding: [{
          system: 'http://terminology.hl7.org/CodeSystem/goal-priority',
          code: goalConfig.priority
        }]
      },
      description: {
        text: goalConfig.description
      },
      subject: patient,
      startDate: new Date().toISOString().split('T')[0],
      target: [goalConfig.target],
      expressedBy: {
        reference: 'Practitioner/programa-mujer-system',
        display: 'Sistema Programa MUJER'
      }
    });
    
    goals.push({ reference: `Goal/${goal.id}` });
    console.log(`✅ Goal creado: ${goalConfig.description}`);
  }
  
  // 3. Crear Condition si hay factores de riesgo significativos
  const conditions: Reference<Condition>[] = [];
  if (riskScore >= 5) {
    const condition = await medplum.createResource<Condition>({
      resourceType: 'Condition',
      clinicalStatus: {
        coding: [{
          system: 'http://terminology.hl7.org/CodeSystem/condition-clinical',
          code: 'active'
        }]
      },
      verificationStatus: {
        coding: [{
          system: 'http://terminology.hl7.org/CodeSystem/condition-ver-status',
          code: 'confirmed'
        }]
      },
      category: [{
        coding: [{
          system: 'http://terminology.hl7.org/CodeSystem/condition-category',
          code: 'problem-list-item'
        }]
      }],
      severity: {
        coding: [{
          system: 'http://snomed.info/sct',
          code: riskScore >= 8 ? '24484000' : '6736007',
          display: riskScore >= 8 ? 'Severe' : 'Moderate'
        }]
      },
      code: {
        coding: [{
          system: 'http://snomed.info/sct',
          code: '398036000',
          display: 'At risk for cardiovascular disease'
        }]
      },
      subject: patient,
      onsetDateTime: new Date().toISOString(),
      recordedDate: new Date().toISOString()
    });
    
    conditions.push({ reference: `Condition/${condition.id}` });
    console.log(`⚠️ Condición de riesgo CV creada (Score: ${riskScore})`);
  }
  
  // 4. Aplicar PlanDefinition según el grupo
  const planDefinitionRef = GRUPO_TO_PLAN[responses.grupo];
  
  if (!planDefinitionRef) {
    throw new Error(`PlanDefinition no encontrado para grupo: ${responses.grupo}`);
  }
  
  // 5. Crear CarePlan
  const carePlan = await medplum.createResource<CarePlan>({
    resourceType: 'CarePlan',
    status: 'active',
    intent: 'plan',
    title: `Plan Programa MUJER - ${getGrupoDisplayName(responses.grupo)}`,
    description: `Plan de cuidado cardiovascular personalizado para ${patient.display}`,
    subject: patient,
    period: {
      start: new Date().toISOString().split('T')[0]
    },
    created: new Date().toISOString(),
    author: {
      reference: 'Practitioner/programa-mujer-system',
      display: 'Sistema Programa MUJER'
    },
    instantiatesCanonical: [planDefinitionRef],
    goal: goals,
    addresses: conditions,
    activity: []
  });
  
  console.log(`✅ CarePlan creado: ${carePlan.id}`);
  
  // 6. Crear ServiceRequest si eligió consulta
  if (responses.seguimiento === 'consulta') {
    const serviceRequest = await medplum.createResource<ServiceRequest>({
      resourceType: 'ServiceRequest',
      status: 'active',
      intent: 'order',
      priority: 'routine',
      code: {
        coding: [{
          system: 'http://snomed.info/sct',
          code: '386053000',
          display: 'Evaluation procedure'
        }],
        text: 'Consulta de Atención Primaria - Programa MUJER'
      },
      subject: patient,
      authoredOn: new Date().toISOString(),
      requester: {
        reference: 'Organization/epa-bienestar',
        display: 'EPA Bienestar IA'
      },
      reasonReference: conditions.length > 0 ? [conditions[0]] : undefined,
      note: [{
        text: `Paciente ingresó al Programa MUJER - ${getGrupoDisplayName(responses.grupo)}. Risk Score: ${riskScore}. Objetivos: ${responses.objetivos.join(', ')}`
      }]
    });
    
    // Crear Task para agendar el appointment
    await medplum.createResource<Task>({
      resourceType: 'Task',
      status: 'requested',
      intent: 'order',
      priority: 'routine',
      code: {
        coding: [{
          system: 'http://hl7.org/fhir/CodeSystem/task-code',
          code: 'fulfill'
        }]
      },
      description: 'Agendar consulta de atención primaria para nueva paciente Programa MUJER',
      for: patient,
      focus: { reference: `ServiceRequest/${serviceRequest.id}` },
      authoredOn: new Date().toISOString(),
      restriction: {
        period: {
          end: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 días
        }
      },
      owner: {
        reference: 'Organization/epa-bienestar',
        display: 'Equipo Administrativo EPA'
      }
    });
    
    console.log(`📞 ServiceRequest y Task de agendamiento creados`);
  }
  
  // 7. Crear Observations iniciales para tracking
  await createInitialObservations(medplum, patient, responses.riskFactors);
  
  // 8. Enviar notificación de bienvenida
  await medplum.createResource({
    resourceType: 'Communication',
    status: 'completed',
    category: [{
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/communication-category',
        code: 'notification'
      }]
    }],
    priority: 'routine',
    subject: patient,
    topic: {
      text: '🎉 ¡Bienvenida al Programa MUJER!'
    },
    sent: new Date().toISOString(),
    payload: [{
      contentString: `Hola ${patient.display},\n\nTu plan de cuidado cardiovascular ha sido creado exitosamente.\n\nGrupo: ${getGrupoDisplayName(responses.grupo)}\nObjetivos activos: ${goals.length}\n\nAccede a tu dashboard para ver tu plan completo: https://mujer.epa-bienestar.com.ar/dashboard\n\nEquipo EPA Bienestar`
    }],
    recipient: [patient]
  });
  
  console.log(`✅ Comunicación de bienvenida enviada`);
  
  return {
    success: true,
    carePlanId: carePlan.id,
    goals: goals.length,
    riskScore: riskScore,
    seguimiento: responses.seguimiento
  };
}

// Funciones auxiliares

function extractResponses(qr: QuestionnaireResponse): {
  grupo: string;
  objetivos: string[];
  riskFactors: any;
  seguimiento: string | null;
} {
  const findAnswer = (linkId: string): any => {
    const item = qr.item?.find(i => i.linkId === linkId);
    return item?.answer?.[0];
  };
  
  const grupo = findAnswer('2')?.valueCoding?.code;
  
  const objetivosItem = qr.item?.find(i => i.linkId === '3');
  const objetivos = objetivosItem?.answer?.map(a => {
    const code = a.valueCoding?.code;
    // Mapear SNOMED/LOINC a IDs internos
    const mapping: Record<string, string> = {
      '226234005': 'nutricion',
      '68130003': 'actividad-fisica',
      '258158006': 'sueno',
      '8517006': 'no-fumar',
      '8280-0': 'circunferencia',
      '85354-9': 'presion',
      '2093-3': 'colesterol',
      '2339-0': 'glucosa',
      'UNK': 'no-se'
    };
    return mapping[code || ''] || code;
  }) || [];
  
  const riskFactorsGroup = qr.item?.find(i => i.linkId === '4');
  const riskFactors = riskFactorsGroup ? {
    familyHistory: riskFactorsGroup.item?.find(i => i.linkId === '4.1')?.answer?.[0]?.valueBoolean,
    smoking: riskFactorsGroup.item?.find(i => i.linkId === '4.2')?.answer?.[0]?.valueBoolean,
    physicalActivity: riskFactorsGroup.item?.find(i => i.linkId === '4.3')?.answer?.[0]?.valueBoolean,
    chronicConditions: riskFactorsGroup.item?.find(i => i.linkId === '4.4')?.answer?.[0]?.valueBoolean,
    sleepHours: riskFactorsGroup.item?.find(i => i.linkId === '4.5')?.answer?.[0]?.valueInteger,
    stress: riskFactorsGroup.item?.find(i => i.linkId === '4.6')?.answer?.[0]?.valueCoding?.code
  } : null;
  
  const seguimientoCode = findAnswer('5')?.valueCoding?.code;
  const seguimiento = seguimientoCode === '386053000' ? 'consulta' : 
                      seguimientoCode === '11429006' ? 'programa' : null;
  
  return { grupo, objetivos, riskFactors, seguimiento };
}

function calculateRiskScore(riskFactors: any): number {
  let score = 0;
  if (riskFactors.familyHistory) score += 2;
  if (riskFactors.smoking) score += 3;
  if (!riskFactors.physicalActivity) score += 2;
  if (riskFactors.chronicConditions) score += 3;
  if (riskFactors.sleepHours < 6 || riskFactors.sleepHours > 9) score += 1;
  if (riskFactors.stress === 'LA13909-9' || riskFactors.stress === 'LA9933-8') score += 2;
  return score;
}

function getGrupoDisplayName(grupoCode: string): string {
  const names: Record<string, string> = {
    'grupo-a': 'Grupo A: Construyendo Bases Sólidas',
    'grupo-b': 'Grupo B: Salud Cardiovascular y Fertilidad',
    'grupo-c': 'Grupo C: Navegando la Transición Hormonal',
    'grupo-d': 'Grupo D: Longevidad Activa y Saludable'
  };
  return names[grupoCode] || grupoCode;
}

async function createInitialObservations(
  medplum: MedplumClient,
  patient: Reference<Patient>,
  riskFactors: any
): Promise<void> {
  if (!riskFactors) return;
  
  // Smoking status
  if (riskFactors.smoking !== undefined) {
    await medplum.createResource({
      resourceType: 'Observation',
      status: 'final',
      category: [{
        coding: [{
          system: 'http://terminology.hl7.org/CodeSystem/observation-category',
          code: 'social-history'
        }]
      }],
      code: {
        coding: [{
          system: 'http://loinc.org',
          code: '72166-2',
          display: 'Tobacco smoking status'
        }]
      },
      subject: patient,
      effectiveDateTime: new Date().toISOString(),
      valueCodeableConcept: {
        coding: [{
          system: 'http://snomed.info/sct',
          code: riskFactors.smoking ? '77176002' : '8517006',
          display: riskFactors.smoking ? 'Smoker' : 'Ex-smoker'
        }]
      }
    });
  }
  
  // Sleep hours
  if (riskFactors.sleepHours) {
    await medplum.createResource({
      resourceType: 'Observation',
      status: 'final',
      category: [{
        coding: [{
          system: 'http://terminology.hl7.org/CodeSystem/observation-category',
          code: 'vital-signs'
        }]
      }],
      code: {
        coding: [{
          system: 'http://loinc.org',
          code: '93832-4',
          display: 'Sleep duration'
        }]
      },
      subject: patient,
      effectiveDateTime: new Date().toISOString(),
      valueQuantity: {
        value: riskFactors.sleepHours,
        unit: 'h',
        system: 'http://unitsofmeasure.org',
        code: 'h'
      }
    });
  }
  
  console.log('📊 Observaciones iniciales creadas');
}
