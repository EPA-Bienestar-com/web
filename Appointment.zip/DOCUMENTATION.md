# Sistema de Gestión de Turnos FHIR R4 - EPA Bienestar

## 📋 Tabla de Contenidos

1. [Visión General](#visión-general)
2. [Arquitectura FHIR R4](#arquitectura-fhir-r4)
3. [Componentes del Sistema](#componentes-del-sistema)
4. [Flujos de Trabajo](#flujos-de-trabajo)
5. [Determinantes de Salud](#determinantes-de-salud)
6. [Segmentación por Grupos de Vida](#segmentación-por-grupos-de-vida)
7. [API y Recursos FHIR](#api-y-recursos-fhir)
8. [Instalación y Configuración](#instalación-y-configuración)
9. [Extensiones Futuras](#extensiones-futuras)

---

## 🎯 Visión General

El Sistema de Gestión de Turnos de EPA Bienestar es una solución FemTech completa, basada en estándares FHIR R4, diseñada específicamente para abordar las necesidades de salud cardiovascular femenina en Latinoamérica.

### Características Principales

- **Compliance FHIR R4**: Total adherencia a estándares HL7 FHIR para interoperabilidad
- **Segmentación por Etapas de Vida**: Grupos A, B, C, D con servicios personalizados
- **Integración con Determinantes de Salud**: Basado en el modelo de 5 determinantes principales
- **Multiplataforma**: Web, móvil y desktop
- **Notificaciones Inteligentes**: Email, SMS, WhatsApp
- **Gestión Completa**: Reserva, modificación, cancelación y seguimiento

### Stack Tecnológico

```
Frontend:
- React 18+ con TypeScript
- Medplum React Components
- TailwindCSS
- React Router

Backend/Infraestructura:
- Medplum FHIR Server (api.epa-bienestar.com.ar)
- AWS HealthLake
- NVIDIA Inception Program Support

Estándares:
- FHIR R4 (HL7)
- LOINC, SNOMED CT
- ICD-10
```

---

## 🏗️ Arquitectura FHIR R4

### Modelo de Recursos

```
┌─────────────────────────────────────────────────────────────┐
│                     APPOINTMENT BOOKING                      │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│   Schedule   │───▶│     Slot     │───▶│ Appointment  │
└──────────────┘    └──────────────┘    └──────────────┘
        │                   │                    │
        │                   │                    │
        ▼                   ▼                    ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│ Practitioner │    │HealthcareServ│    │   Patient    │
│              │    │              │    │              │
│ Organization │    │  ServiceType │    │ RelatedPerson│
└──────────────┘    └──────────────┘    └──────────────┘
```

### Recursos FHIR Utilizados

#### 1. Schedule
Representa la disponibilidad de un practitioner o servicio.

```typescript
{
  resourceType: "Schedule",
  active: true,
  serviceType: [{
    coding: [{
      system: "http://epa-bienestar.com.ar/fhir/ServiceType",
      code: "cardiology-prevention",
      display: "Prevención Cardiovascular"
    }]
  }],
  actor: [
    { reference: "Practitioner/123" },
    { reference: "HealthcareService/456" },
    { reference: "Organization/789" }
  ],
  planningHorizon: {
    start: "2026-01-01T00:00:00Z",
    end: "2026-12-31T23:59:59Z"
  }
}
```

#### 2. Slot
Representa un período de tiempo específico disponible para reservas.

```typescript
{
  resourceType: "Slot",
  schedule: { reference: "Schedule/123" },
  status: "free", // free | busy | busy-unavailable | busy-tentative
  start: "2026-01-15T10:00:00Z",
  end: "2026-01-15T10:30:00Z",
  serviceType: [{
    coding: [{
      system: "http://epa-bienestar.com.ar/fhir/ServiceType",
      code: "prenatal-cardiology",
      display: "Cardiología Prenatal"
    }]
  }],
  appointmentType: {
    coding: [{
      system: "http://terminology.hl7.org/CodeSystem/v2-0276",
      code: "ROUTINE",
      display: "Routine"
    }]
  }
}
```

#### 3. Appointment
Representa una cita reservada.

```typescript
{
  resourceType: "Appointment",
  status: "booked", // proposed | pending | booked | arrived | fulfilled | cancelled | noshow
  serviceType: [{
    coding: [{
      code: "menopause-cardiology",
      display: "Cardiología Menopausia"
    }]
  }],
  appointmentType: {
    coding: [{
      code: "ROUTINE"
    }]
  },
  description: "Consulta cardiovascular de rutina",
  start: "2026-01-15T10:00:00Z",
  end: "2026-01-15T10:30:00Z",
  comment: "Primera consulta, trae estudios previos",
  participant: [
    {
      actor: {
        reference: "Patient/abc123",
        display: "María García"
      },
      status: "accepted",
      required: "required"
    },
    {
      actor: {
        reference: "Practitioner/def456",
        display: "Dra. Ana Aquieri"
      },
      status: "accepted",
      required: "required"
    }
  ]
}
```

#### 4. Communication
Para notificaciones y recordatorios.

```typescript
{
  resourceType: "Communication",
  status: "completed",
  category: [{
    coding: [{
      system: "http://terminology.hl7.org/CodeSystem/communication-category",
      code: "notification"
    }]
  }],
  subject: { reference: "Patient/abc123" },
  about: [{ reference: "Appointment/xyz789" }],
  sent: "2026-01-14T10:00:00Z",
  payload: [{
    contentString: "Recordatorio: Tiene un turno mañana a las 10:00hs con Dra. Aquieri"
  }]
}
```

---

## 🧩 Componentes del Sistema

### 1. GetCareEnhanced (Componente Principal)

**Responsabilidad**: Orquestador principal del flujo de reserva de turnos.

**Estados**:
```typescript
interface GetCareState {
  selectedSchedule: Schedule | null;
  selectedSlot: Slot | null;
  selectedPractitioner: Practitioner | null;
  selectedService: HealthcareService | null;
  patient: Patient | null;
  confirmedAppointment: Appointment | null;
  step: 'selection' | 'booking' | 'confirmation';
  selectedGroup: LifeStageGroup;
}
```

**Flujo**:
1. Carga schedules, slots, practitioners, services
2. Permite filtrado por grupo de vida
3. Gestiona transición entre pasos
4. Coordina creación de Appointment y actualización de Slot

### 2. LifeStageFilter

**Responsabilidad**: Selector de grupo de vida adaptativo.

**Grupos**:
- **Grupo A** (18-30): Prevención, fitness, manejo de estrés
- **Grupo B** (28-40): PCOS, fertilidad, cardiología prenatal
- **Grupo C** (45-65): Menopausia, screening cardiovascular
- **Grupo D** (65+): Geriatría, soporte cuidador, movilidad

**Servicios Prioritarios por Grupo**:
```typescript
const GROUP_SERVICES = {
  A: ['cardiology-prevention', 'nutrition', 'stress-management', 'fitness-assessment'],
  B: ['prenatal-cardiology', 'pregnancy-nutrition', 'pcos-management', 'fertility-counseling'],
  C: ['menopause-cardiology', 'hormone-therapy', 'osteoporosis-screening', 'cardiovascular-risk'],
  D: ['geriatric-cardiology', 'caregiver-support', 'mobility-assessment', 'cognitive-health']
};
```

### 3. SlotSelector

**Responsabilidad**: Visualización y selección de slots disponibles.

**Características**:
- Vista de calendario y lista
- Filtros por practitioner, servicio, fecha
- Búsqueda de texto
- Ordenamiento por fecha/hora
- Agrupación por día

**Algoritmo de Filtrado**:
```typescript
filteredSlots = slots
  .filter(byPractitioner)
  .filter(byServiceType)
  .filter(bySearchTerm)
  .filter(byLifeStageGroup)
  .sort(byDateTime);
```

### 4. AppointmentBooking

**Responsabilidad**: Formulario de captura de información del turno.

**Campos**:
- Motivo de consulta (requerido)
- Notas adicionales (opcional)
- Preferencia de contacto (email, teléfono, SMS)
- Recordatorios (24h, 2h, 30min)
- Términos y condiciones

**Validación**:
```typescript
const validate = (data: AppointmentBookingData) => {
  const errors = {};
  
  if (!data.reason.trim()) {
    errors.reason = "Motivo requerido";
  }
  
  if (data.reason.length < 10) {
    errors.reason = "Motivo muy breve";
  }
  
  return errors;
};
```

### 5. AppointmentConfirmation

**Responsabilidad**: Confirmación y opciones post-reserva.

**Funcionalidades**:
- Generar archivo ICS para calendario
- Compartir por WhatsApp, Email
- Copiar al portapapeles
- Imprimir confirmación
- Navegación a "Mis Turnos"

**Generación de ICS**:
```typescript
const generateICS = (appointment: Appointment) => {
  return `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//EPA Bienestar//Appointment//ES
BEGIN:VEVENT
UID:${appointment.id}@epa-bienestar.com.ar
DTSTAMP:${formatICS(new Date())}
DTSTART:${formatICS(appointment.start)}
DTEND:${formatICS(appointment.end)}
SUMMARY:Turno ${service} - EPA Bienestar
...
END:VEVENT
END:VCALENDAR`;
};
```

### 6. MyAppointments

**Responsabilidad**: Dashboard de gestión de turnos del paciente.

**Filtros**:
- Próximos (upcoming)
- Pasados (past)
- Cancelados (cancelled)
- Todos (all)

**Reglas de Cancelación**:
```typescript
const canCancel = (appointment: Appointment) => {
  if (appointment.status === 'cancelled') return false;
  
  const hoursUntil = (new Date(appointment.start) - Date.now()) / (1000 * 60 * 60);
  return hoursUntil > 24; // Más de 24 horas de anticipación
};
```

---

## 🔄 Flujos de Trabajo

### Flujo 1: Reserva de Turno (Happy Path)

```
1. Usuario selecciona grupo de vida
   ↓
2. Sistema filtra slots según grupo
   ↓
3. Usuario selecciona fecha en calendario
   ↓
4. Sistema muestra horarios disponibles
   ↓
5. Usuario selecciona slot específico
   ↓
6. Sistema muestra formulario de reserva
   ↓
7. Usuario completa motivo y preferencias
   ↓
8. Usuario confirma términos
   ↓
9. Sistema crea Appointment (status: booked)
   ↓
10. Sistema actualiza Slot (status: busy)
   ↓
11. Sistema crea Communication (notificación)
   ↓
12. Sistema muestra confirmación
   ↓
13. Usuario descarga ICS o comparte
```

### Flujo 2: Cancelación de Turno

```
1. Usuario accede a "Mis Turnos"
   ↓
2. Sistema muestra appointments activos
   ↓
3. Usuario selecciona turno a cancelar
   ↓
4. Sistema verifica si cumple política (>24hs)
   ↓
5. Usuario confirma cancelación
   ↓
6. Sistema actualiza Appointment (status: cancelled)
   ↓
7. Sistema actualiza Slot (status: free)
   ↓
8. Sistema crea Communication (cancelación)
   ↓
9. Sistema muestra confirmación
```

### Flujo 3: Recordatorios Automáticos

```
Sistema (Cron Job):
1. Busca Appointments próximos
   ↓
2. Filtra según preferencias de recordatorio
   ↓
3. Para cada appointment:
   a. Calcula tiempo hasta cita
   b. Si coincide con preferencia (24h/2h/30min)
   c. Crea Communication resource
   d. Envía notificación (email/SMS/WhatsApp)
   ↓
4. Registra envío en Communication.sent
```

---

## 📊 Determinantes de Salud

El sistema integra el modelo de 5 determinantes principales de salud:

### Distribución de Impacto

```
Comportamiento:  38.43%  ████████████████████████████████████████
Social:          22.81%  ███████████████████████████
Genética:        20.74%  █████████████████████████
Atención Médica: 11.06%  ███████████████
Ambiente:         7.00%  █████████
```

### Implementación en Turnos

#### 1. Comportamiento (38%)
**Servicios relacionados**:
- Fitness assessment
- Nutrition counseling
- Stress management
- Smoking cessation

**Integración**:
```typescript
const behavioralServices = [
  {
    code: 'fitness-assessment',
    determinant: 'behavioral',
    impact: 0.38,
    lifestages: ['A', 'B', 'C', 'D'],
    priority: 'high'
  },
  {
    code: 'nutrition',
    determinant: 'behavioral',
    impact: 0.38,
    lifestages: ['A', 'B', 'C', 'D'],
    priority: 'high'
  }
];
```

#### 2. Social (23%)
**Servicios relacionados**:
- Caregiver support (CuidarTE)
- Group therapy
- Community programs

**Integración**:
```typescript
const socialServices = [
  {
    code: 'caregiver-support',
    determinant: 'social',
    impact: 0.23,
    lifestages: ['C', 'D'],
    priority: 'critical'
  }
];
```

#### 3. Genética (21%)
**Servicios relacionados**:
- Family history assessment
- Genetic counseling
- Risk stratification

#### 4. Atención Médica (11%)
**Servicios relacionados**:
- Cardiology consultations
- Preventive screenings
- Follow-up appointments

#### 5. Ambiente (7%)
**Servicios relacionados**:
- Environmental risk assessment
- Occupational health

### CodeSystem de Determinantes

```json
{
  "resourceType": "CodeSystem",
  "url": "http://epa-bienestar.com.ar/fhir/CodeSystem/health-determinants",
  "name": "HealthDeterminants",
  "status": "active",
  "concept": [
    {
      "code": "behavioral",
      "display": "Determinantes de Comportamiento",
      "definition": "Factores relacionados con estilos de vida y comportamientos individuales",
      "property": [
        { "code": "impact", "valueDecimal": 0.3843 }
      ]
    },
    {
      "code": "social",
      "display": "Determinantes Sociales",
      "definition": "Condiciones sociales y económicas que afectan la salud",
      "property": [
        { "code": "impact", "valueDecimal": 0.2281 }
      ]
    },
    {
      "code": "genetic",
      "display": "Determinantes Genéticos",
      "definition": "Factores heredados y predisposiciones genéticas",
      "property": [
        { "code": "impact", "valueDecimal": 0.2074 }
      ]
    },
    {
      "code": "medical-care",
      "display": "Atención Médica",
      "definition": "Acceso y calidad de servicios de salud",
      "property": [
        { "code": "impact", "valueDecimal": 0.1106 }
      ]
    },
    {
      "code": "environmental",
      "display": "Determinantes Ambientales",
      "definition": "Factores físicos y ambientales",
      "property": [
        { "code": "impact", "valueDecimal": 0.07 }
      ]
    }
  ]
}
```

---

## 👥 Segmentación por Grupos de Vida

### Configuración de Grupos

```typescript
interface LifeStageConfig {
  id: 'A' | 'B' | 'C' | 'D';
  ageRange: [number, number];
  characteristics: string[];
  healthPriorities: string[];
  riskFactors: string[];
  recommendedServices: ServiceType[];
  appointmentFrequency: {
    preventive: number; // meses
    followup: number;   // meses
  };
}

const LIFE_STAGE_CONFIGS: LifeStageConfig[] = [
  {
    id: 'A',
    ageRange: [18, 30],
    characteristics: [
      'Jóvenes profesionales',
      'Estudiantes universitarias',
      'Inicio carrera profesional'
    ],
    healthPriorities: [
      'Prevención cardiovascular',
      'Manejo de estrés',
      'Nutrición balanceada',
      'Actividad física regular'
    ],
    riskFactors: [
      'Sedentarismo',
      'Estrés académico/laboral',
      'Mala alimentación',
      'Tabaquismo'
    ],
    recommendedServices: [
      'cardiology-prevention',
      'nutrition',
      'stress-management',
      'fitness-assessment'
    ],
    appointmentFrequency: {
      preventive: 12,
      followup: 6
    }
  },
  {
    id: 'B',
    ageRange: [28, 40],
    characteristics: [
      'Planificación familiar',
      'Embarazo o considerándolo',
      'Balance trabajo-familia'
    ],
    healthPriorities: [
      'Salud cardiovascular prenatal',
      'Manejo PCOS',
      'Nutrición prenatal',
      'Prevención diabetes gestacional'
    ],
    riskFactors: [
      'PCOS',
      'Sobrepeso/obesidad',
      'Historia familiar cardiovascular',
      'Diabetes gestacional'
    ],
    recommendedServices: [
      'prenatal-cardiology',
      'pregnancy-nutrition',
      'pcos-management',
      'fertility-counseling'
    ],
    appointmentFrequency: {
      preventive: 6,
      followup: 3
    }
  },
  {
    id: 'C',
    ageRange: [45, 65],
    characteristics: [
      'Transición menopáusica',
      'Madres de hijos adultos',
      'Continuación desarrollo profesional'
    ],
    healthPriorities: [
      'Manejo menopausia',
      'Prevención osteoporosis',
      'Screening cardiovascular',
      'Terapia hormonal'
    ],
    riskFactors: [
      'Cambios hormonales',
      'Aumento riesgo cardiovascular',
      'Osteoporosis',
      'Síntomas vasomotores'
    ],
    recommendedServices: [
      'menopause-cardiology',
      'hormone-therapy',
      'osteoporosis-screening',
      'cardiovascular-risk'
    ],
    appointmentFrequency: {
      preventive: 6,
      followup: 3
    }
  },
  {
    id: 'D',
    ageRange: [65, 120],
    characteristics: [
      'Abuelas',
      'Emprendedoras',
      'Viajeras activas'
    ],
    healthPriorities: [
      'Salud cardiovascular geriátrica',
      'Soporte cuidador',
      'Movilidad funcional',
      'Salud cognitiva'
    ],
    riskFactors: [
      'Carga de cuidador',
      'Múltiples comorbilidades',
      'Polifarmacia',
      'Deterioro funcional'
    ],
    recommendedServices: [
      'geriatric-cardiology',
      'caregiver-support',
      'mobility-assessment',
      'cognitive-health'
    ],
    appointmentFrequency: {
      preventive: 4,
      followup: 2
    }
  }
];
```

### Algoritmo de Recomendación

```typescript
const recommendServices = (patient: Patient): ServiceRecommendation[] => {
  // 1. Determinar grupo de vida por edad
  const age = calculateAge(patient.birthDate);
  const group = LIFE_STAGE_CONFIGS.find(g => 
    age >= g.ageRange[0] && age <= g.ageRange[1]
  );
  
  if (!group) return [];
  
  // 2. Obtener condiciones existentes
  const conditions = await medplum.searchResources('Condition', {
    patient: `Patient/${patient.id}`,
    'clinical-status': 'active'
  });
  
  // 3. Evaluar factores de riesgo
  const riskFactors = evaluateRiskFactors(patient, conditions);
  
  // 4. Generar recomendaciones priorizadas
  const recommendations = group.recommendedServices.map(serviceCode => {
    const relevance = calculateRelevance(serviceCode, riskFactors, conditions);
    const urgency = calculateUrgency(serviceCode, riskFactors);
    
    return {
      serviceCode,
      group: group.id,
      relevance,
      urgency,
      priority: urgency > 0.7 ? 'high' : urgency > 0.4 ? 'medium' : 'low'
    };
  });
  
  return recommendations.sort((a, b) => b.relevance - a.relevance);
};
```

---

## 🔌 API y Recursos FHIR

### Endpoints Principales

#### Búsqueda de Slots Disponibles

```http
GET /fhir/r4/Slot?status=free&start=ge2026-01-15&_count=100
```

Parámetros opcionales:
- `schedule`: Filtrar por schedule específico
- `service-type`: Filtrar por tipo de servicio
- `start`: Fecha inicio (ge/le)
- `_sort`: Ordenamiento

Respuesta:
```json
{
  "resourceType": "Bundle",
  "type": "searchset",
  "total": 45,
  "entry": [
    {
      "resource": {
        "resourceType": "Slot",
        "id": "slot-123",
        "schedule": { "reference": "Schedule/456" },
        "status": "free",
        "start": "2026-01-15T10:00:00Z",
        "end": "2026-01-15T10:30:00Z"
      }
    }
  ]
}
```

#### Crear Appointment

```http
POST /fhir/r4/Appointment
Content-Type: application/fhir+json

{
  "resourceType": "Appointment",
  "status": "booked",
  "start": "2026-01-15T10:00:00Z",
  "end": "2026-01-15T10:30:00Z",
  "participant": [...]
}
```

#### Actualizar Slot

```http
PUT /fhir/r4/Slot/slot-123
Content-Type: application/fhir+json

{
  "resourceType": "Slot",
  "id": "slot-123",
  "status": "busy",
  "appointment": { "reference": "Appointment/789" }
}
```

#### Buscar Appointments del Paciente

```http
GET /fhir/r4/Appointment?patient=Patient/abc123&_sort=-date
```

### Operaciones Personalizadas

#### $find-available-slots

Operación avanzada para búsqueda inteligente de slots.

```http
POST /fhir/r4/Schedule/$find-available-slots
Content-Type: application/fhir+json

{
  "resourceType": "Parameters",
  "parameter": [
    {
      "name": "start",
      "valueDateTime": "2026-01-15T00:00:00Z"
    },
    {
      "name": "end",
      "valueDateTime": "2026-01-22T23:59:59Z"
    },
    {
      "name": "serviceType",
      "valueCodeableConcept": {
        "coding": [{
          "code": "prenatal-cardiology"
        }]
      }
    },
    {
      "name": "lifeStageGroup",
      "valueString": "B"
    }
  ]
}
```

---

## ⚙️ Instalación y Configuración

### Requisitos Previos

- Node.js 18+
- npm o yarn
- Cuenta Medplum configurada
- API Key de Medplum

### Instalación

```bash
# Clonar repositorio
git clone https://github.com/epa-bienestar/appointment-system.git
cd appointment-system

# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
```

### Configuración de Medplum

```env
MEDPLUM_BASE_URL=https://api.epa-bienestar.com.ar
MEDPLUM_CLIENT_ID=your-client-id
MEDPLUM_CLIENT_SECRET=your-client-secret
MEDPLUM_PROJECT_ID=your-project-id
```

### Crear Recursos Base

```bash
# Script para crear schedules, practitioners, services iniciales
npm run setup:initial-data
```

### Ejecutar en Desarrollo

```bash
npm run dev
```

### Build para Producción

```bash
npm run build
npm run start
```

---

## 🚀 Extensiones Futuras

### 1. Sistema de Waitlist

Cuando no hay slots disponibles, permitir inscripción en lista de espera.

```typescript
{
  resourceType: "List",
  status: "current",
  mode: "working",
  code: {
    coding: [{
      system: "http://epa-bienestar.com.ar/fhir/list-type",
      code: "waitlist"
    }]
  },
  subject: { reference: "HealthcareService/cardiology" },
  entry: [
    {
      item: { reference: "Patient/abc123" },
      date: "2026-01-15T09:00:00Z"
    }
  ]
}
```

### 2. Telemedicina

Integración con videoconsultas.

```typescript
{
  resourceType: "Appointment",
  appointmentType: {
    coding: [{
      system: "http://terminology.hl7.org/CodeSystem/v2-0276",
      code: "VIRTUAL",
      display: "Virtual"
    }]
  },
  extension: [{
    url: "http://epa-bienestar.com.ar/fhir/StructureDefinition/video-link",
    valueUrl: "https://meet.epa-bienestar.com.ar/room/abc123"
  }]
}
```

### 3. Machine Learning para Predicción de No-Shows

```typescript
interface NoShowPrediction {
  appointmentId: string;
  riskScore: number; // 0-1
  factors: {
    previousNoShows: number;
    cancellationHistory: number;
    advanceBookingDays: number;
    weekday: string;
    timeOfDay: string;
  };
  recommendation: 'send-reminder' | 'call-confirm' | 'overbook';
}
```

### 4. Integración con CarePlan

Generar automáticamente CarePlans basados en appointments.

```typescript
{
  resourceType: "CarePlan",
  status: "active",
  intent: "plan",
  subject: { reference: "Patient/abc123" },
  period: {
    start: "2026-01-15",
    end: "2026-07-15"
  },
  activity: [
    {
      reference: { reference: "Appointment/789" }
    },
    {
      detail: {
        code: {
          coding: [{
            code: "exercise-program"
          }]
        },
        status: "in-progress",
        scheduledPeriod: {
          start: "2026-01-15",
          end: "2026-07-15"
        }
      }
    }
  ]
}
```

### 5. Analytics Dashboard

Dashboard con métricas clave:
- Tasa de ocupación de slots
- Tiempo promedio entre reserva y cita
- Tasa de no-shows por grupo
- Servicios más demandados
- Distribución por horarios

```typescript
interface AppointmentMetrics {
  period: { start: string; end: string };
  totalAppointments: number;
  byLifeStage: {
    A: number;
    B: number;
    C: number;
    D: number;
  };
  byStatus: {
    booked: number;
    fulfilled: number;
    cancelled: number;
    noshow: number;
  };
  slotUtilization: number; // 0-1
  averageBookingAdvance: number; // days
  peakHours: string[];
}
```

---

## 📚 Referencias

- [FHIR R4 Specification](http://hl7.org/fhir/R4/)
- [Medplum Documentation](https://www.medplum.com/docs)
- [American Heart Association - Life's Essential 8](https://www.heart.org/en/healthy-living/lifes-essential-8)
- [Health Determinants Model](https://www.healthypeople.gov/)

---

## 📄 Licencia

Copyright © 2026 EPA Bienestar IA. Todos los derechos reservados.

---

**Contacto**: 
- Email: tech@epa-bienestar.com.ar
- Web: https://epa-bienestar.com.ar
