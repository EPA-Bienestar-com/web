# 🏥 EPA Bienestar - Sistema de Gestión de Turnos FHIR R4

<div align="center">

![EPA Bienestar](https://via.placeholder.com/800x200/4ECDC4/FFFFFF?text=EPA+Bienestar+%7C+Salud+Cardiovascular+Femenina)

[![FHIR R4](https://img.shields.io/badge/FHIR-R4-blue)](http://hl7.org/fhir/R4/)
[![React](https://img.shields.io/badge/React-18+-61DAFB)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6)](https://www.typescriptlang.org/)
[![Medplum](https://img.shields.io/badge/Medplum-Powered-FF6B9D)](https://www.medplum.com/)
[![AWS](https://img.shields.io/badge/AWS-HealthLake-FF9900)](https://aws.amazon.com/healthlake/)

Sistema completo de gestión de turnos médicos basado en estándares FHIR R4, diseñado específicamente para salud cardiovascular femenina en Latinoamérica.

[🚀 Demo](https://plataforma.epa-bienestar.com.ar) • [📖 Documentación](./DOCUMENTATION.md) • [🐛 Issues](https://github.com/epa-bienestar/issues)

</div>

---

## ✨ Características Principales

### 🎯 Enfoque FemTech

- **Segmentación por Etapas de Vida**: 4 grupos (A, B, C, D) con servicios personalizados
- **Prevención Cardiovascular**: Abordaje específico de riesgo cardiovascular femenino
- **Modelo de Determinantes**: Basado en 5 determinantes principales de salud
- **Servicios Especializados**: PCOS, menopausia, embarazo, cuidador

### 🏗️ Arquitectura FHIR R4

- ✅ **100% Compliance FHIR R4**: Interoperabilidad total con sistemas de salud
- ✅ **Recursos Estándar**: Schedule, Slot, Appointment, Patient, Practitioner
- ✅ **CodeSystems Propios**: Servicios y determinantes personalizados
- ✅ **Medplum Backend**: FHIR Server escalable en AWS

### 💡 Experiencia de Usuario

- 📅 **Selección Inteligente**: Calendario visual con disponibilidad en tiempo real
- 🔍 **Filtros Avanzados**: Por profesional, servicio, fecha, grupo de vida
- 🔔 **Notificaciones Múltiples**: Email, SMS, WhatsApp
- 📱 **Multiplataforma**: Web, móvil, desktop
- 💾 **Integración Calendario**: Exportación a formato ICS

### 📊 Dashboard y Gestión

- 📈 **Analytics en Tiempo Real**: Métricas de ocupación y uso
- ⏰ **Recordatorios Automáticos**: 24h, 2h, 30min antes
- 🚫 **Política de Cancelación**: Gestión inteligente con restricciones
- 📋 **Historial Completo**: Turnos pasados, próximos, cancelados

---

## 🚀 Inicio Rápido

### Prerrequisitos

```bash
Node.js >= 18.0.0
npm >= 9.0.0
Cuenta Medplum activa
```

### Instalación

```bash
# 1. Clonar repositorio
git clone https://github.com/epa-bienestar/appointment-system.git
cd appointment-system

# 2. Instalar dependencias
npm install

# 3. Configurar variables de entorno
cp .env.example .env

# 4. Editar .env con tus credenciales de Medplum
nano .env

# 5. Iniciar en modo desarrollo
npm run dev
```

La aplicación estará disponible en `http://localhost:3000`

### Variables de Entorno

```env
# Medplum Configuration
MEDPLUM_BASE_URL=https://api.epa-bienestar.com.ar
MEDPLUM_CLIENT_ID=your-client-id
MEDPLUM_CLIENT_SECRET=your-client-secret
MEDPLUM_PROJECT_ID=your-project-id

# Application
REACT_APP_NAME=EPA Bienestar
REACT_APP_VERSION=1.0.0
```

---

## 📂 Estructura del Proyecto

```
epa-bienestar-appointments/
├── src/
│   ├── components/
│   │   └── appointments/
│   │       ├── LifeStageFilter.tsx       # Selector de grupos de vida
│   │       ├── SlotSelector.tsx          # Vista de slots disponibles
│   │       ├── AppointmentBooking.tsx    # Formulario de reserva
│   │       ├── AppointmentConfirmation.tsx # Confirmación y opciones
│   │       └── MyAppointments.tsx        # Dashboard de turnos
│   ├── pages/
│   │   └── get-care/
│   │       ├── GetCare.tsx              # Componente legacy
│   │       └── GetCareEnhanced.tsx      # Componente principal mejorado
│   ├── utils/
│   │   ├── fhir-helpers.ts              # Utilidades FHIR
│   │   └── date-utils.ts                # Formateo de fechas
│   └── types/
│       └── appointments.ts              # TypeScript types
├── docs/
│   └── DOCUMENTATION.md                 # Documentación técnica completa
├── public/
├── .env.example
├── package.json
└── README.md
```

---

## 🎯 Grupos de Vida

El sistema segmenta usuarios en 4 grupos con necesidades específicas:

### 👩 Grupo A (18-30 años)
**Jóvenes Profesionales y Académicas**

- 🎓 Estudiantes y profesionales en desarrollo
- ⚡ Prevención cardiovascular temprana
- 🏃 Fitness y manejo de estrés
- 📱 Nativos digitales

**Servicios Prioritarios**:
- Prevención cardiovascular
- Nutrición
- Manejo de estrés
- Evaluación fitness

---

### 🤰 Grupo B (28-40 años)
**Planificación Maternidad**

- 👶 Embarazo o planificándolo
- 💼 Balance trabajo-familia
- 🔬 Manejo PCOS
- ❤️ Salud cardiovascular prenatal

**Servicios Prioritarios**:
- Cardiología prenatal
- Nutrición embarazo
- Manejo PCOS
- Asesoramiento fertilidad

---

### 🌟 Grupo C (45-65 años)
**Transición Menopáusica**

- 🌡️ Menopausia y cambios hormonales
- 👩‍👧‍👦 Madres de hijos adultos
- 💼 Desarrollo profesional continuo
- 🦴 Prevención osteoporosis

**Servicios Prioritarios**:
- Cardiología menopausia
- Terapia hormonal
- Screening osteoporosis
- Evaluación riesgo cardiovascular

---

### 👵 Grupo D (65+ años)
**Abuelas Activas**

- 🧳 Viajeras y emprendedoras
- 👶 Abuelas
- ❤️ Carga de cuidador
- 🏃‍♀️ Movilidad y funcionalidad

**Servicios Prioritarios**:
- Cardiología geriátrica
- Soporte cuidador (CuidarTE)
- Evaluación movilidad
- Salud cognitiva

---

## 📊 Modelo de Determinantes de Salud

Basado en investigación multi-institucional (NCHHSTP, WHO, Healthy People):

```
┌──────────────────────────────────────────────────┐
│ DETERMINANTES DE SALUD                           │
├──────────────────────────────────────────────────┤
│ 1. COMPORTAMIENTO         38.43%  █████████████ │
│    - Actividad física                            │
│    - Nutrición                                   │
│    - Tabaquismo                                  │
│    - Adherencia tratamiento                      │
├──────────────────────────────────────────────────┤
│ 2. SOCIAL                 22.81%  ████████      │
│    - Carga de cuidador                           │
│    - Soporte social                              │
│    - Nivel socioeconómico                        │
│    - Educación                                   │
├──────────────────────────────────────────────────┤
│ 3. GENÉTICA               20.74%  ███████       │
│    - Historia familiar                           │
│    - Predisposiciones                            │
│    - Marcadores genéticos                        │
├──────────────────────────────────────────────────┤
│ 4. ATENCIÓN MÉDICA        11.06%  ████          │
│    - Acceso a servicios                          │
│    - Calidad atención                            │
│    - Prevención                                  │
├──────────────────────────────────────────────────┤
│ 5. AMBIENTE                7.00%  ███           │
│    - Calidad aire                                │
│    - Exposiciones ocupacionales                  │
│    - Acceso a espacios verdes                    │
└──────────────────────────────────────────────────┘
```

---

## 🔧 Uso del Sistema

### 1. Reservar un Turno

```typescript
// El usuario sigue este flujo:
1. Seleccionar grupo de vida (A, B, C, o D)
2. Filtrar por profesional/servicio (opcional)
3. Seleccionar fecha en calendario
4. Elegir horario disponible
5. Completar formulario con:
   - Motivo de consulta
   - Notas adicionales
   - Preferencias de contacto
   - Opciones de recordatorio
6. Aceptar términos y confirmar
7. Recibir confirmación con:
   - Número de turno
   - Detalles completos
   - Opciones de descarga (ICS)
   - Compartir (WhatsApp, Email)
```

### 2. Gestionar Turnos Existentes

```typescript
// Acceder a "Mis Turnos"
- Ver todos los turnos (próximos, pasados, cancelados)
- Filtrar por estado
- Cancelar turno (si >24hs antes)
- Ver detalles completos
- Recibir recordatorios automáticos
```

### 3. Integración con Calendario

```typescript
// El sistema genera archivo ICS compatible con:
- Google Calendar
- Apple Calendar
- Outlook
- Yahoo Calendar
- Cualquier cliente RFC 5545
```

---

## 🔌 API FHIR R4

### Endpoints Principales

#### Buscar Slots Disponibles

```http
GET /fhir/r4/Slot?status=free&start=ge2026-01-15&_count=100
Accept: application/fhir+json
```

#### Crear Appointment

```http
POST /fhir/r4/Appointment
Content-Type: application/fhir+json

{
  "resourceType": "Appointment",
  "status": "booked",
  "start": "2026-01-15T10:00:00Z",
  "end": "2026-01-15T10:30:00Z",
  "participant": [
    {
      "actor": { "reference": "Patient/123" },
      "status": "accepted"
    }
  ]
}
```

#### Cancelar Appointment

```http
PUT /fhir/r4/Appointment/789
Content-Type: application/fhir+json

{
  "resourceType": "Appointment",
  "id": "789",
  "status": "cancelled"
}
```

Ver [DOCUMENTATION.md](./DOCUMENTATION.md) para API completa.

---

## 🧪 Testing

```bash
# Ejecutar tests unitarios
npm run test

# Coverage
npm run test:coverage

# E2E tests
npm run test:e2e
```

---

## 🚢 Deployment

### Producción

```bash
# Build
npm run build

# Deploy a AWS
npm run deploy:aws

# O usar Docker
docker build -t epa-appointments .
docker run -p 3000:3000 epa-appointments
```

### CI/CD

El proyecto incluye configuración para:
- GitHub Actions
- AWS CodePipeline
- CircleCI

---

## 🤝 Contribuir

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea tu feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push al branch (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

Ver [CONTRIBUTING.md](./CONTRIBUTING.md) para más detalles.

---

## 📜 Licencia

Copyright © 2026 EPA Bienestar IA. Todos los derechos reservados.

Este proyecto está licenciado bajo términos propietarios. Ver [LICENSE](./LICENSE) para más información.

---

## 🙏 Agradecimientos

### Equipo Médico

- **Dra. Analía Aquieri** - Cardióloga, SAC
- **Dra. Verónica Crosa** - Cardióloga, SAC
- **Dra. Marisa Pages** - Cardióloga, SAC
- **Dra. Viviana Cavenago** - Cardióloga, SAC
- **Mg. Giovanna Sanguinetti** - Program Manager

### Tecnología

- **Medplum** - FHIR R4 Server Platform
- **AWS** - Cloud Infrastructure (HealthLake)
- **NVIDIA Inception** - Program Support
- **React Team** - UI Framework

### Referencias Científicas

- **American Heart Association** - Life's Essential 8
- **HL7 FHIR** - Healthcare Interoperability Standards
- **NCHHSTP, WHO, Healthy People** - Health Determinants Research

---

## 📞 Contacto

**EPA Bienestar IA**

- 🌐 Website: [https://epa-bienestar.com.ar](https://epa-bienestar.com.ar)
- 📧 Email: tech@epa-bienestar.com.ar
- 🐦 Twitter: [@EPABienestar](https://twitter.com/EPABienestar)
- 💼 LinkedIn: [EPA Bienestar](https://linkedin.com/company/epa-bienestar)

**Product Leader**

- 👤 Alejandro - Product Lead
- 📧 alejandro@epa-bienestar.com.ar

---

## 🗺️ Roadmap

### Q1 2026
- [x] Sistema base de turnos FHIR R4
- [x] Segmentación por grupos de vida
- [x] Integración calendario
- [ ] Analytics dashboard
- [ ] Testing automatizado

### Q2 2026
- [ ] Sistema de waitlist
- [ ] Telemedicina integrada
- [ ] ML para predicción no-shows
- [ ] Expansión a otros países LATAM

### Q3 2026
- [ ] Integración CarePlan automático
- [ ] Digital Twin cardiovascular
- [ ] App móvil nativa
- [ ] Wearables integration

### Q4 2026
- [ ] Validación clínica
- [ ] Certificación médica
- [ ] Partnerships pharma
- [ ] Scale-up regional

---

<div align="center">

**Construido con ❤️ por EPA Bienestar para la salud cardiovascular femenina**

[⬆️ Volver arriba](#-epa-bienestar---sistema-de-gestión-de-turnos-fhir-r4)

</div>
