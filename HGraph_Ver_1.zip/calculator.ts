/**
 * EPA Bienestar IA - HGraph Score Calculator
 * Lógica de cálculo del score cardiovascular femenino
 */

import {
  HGraphScore,
  GroupScore,
  RiskInterpretation,
  PatientHealthData,
  GroupWeights,
  DEFAULT_GROUP_WEIGHTS,
  MetricRange
} from './types';

// ============================================
// RANGOS DE REFERENCIA POR MÉTRICA
// ============================================

export const METRIC_RANGES: Record<string, MetricRange> = {
  // Grupo A: Tradicionales
  bloodPressureSystolic: {
    healthyMin: 90,
    healthyMax: 120,
    absoluteMin: 70,
    absoluteMax: 200,
    weight: 1.5 // Mayor peso
  },
  bloodPressureDiastolic: {
    healthyMin: 60,
    healthyMax: 80,
    absoluteMin: 40,
    absoluteMax: 130,
    weight: 1.2
  },
  ldlCholesterol: {
    healthyMin: 0,
    healthyMax: 100,
    absoluteMin: 0,
    absoluteMax: 250,
    weight: 1.5
  },
  hdlCholesterol: {
    healthyMin: 50, // Mayor en mujeres
    healthyMax: 90,
    absoluteMin: 20,
    absoluteMax: 100,
    weight: 1.0
  },
  triglycerides: {
    healthyMin: 0,
    healthyMax: 150,
    absoluteMin: 0,
    absoluteMax: 500,
    weight: 1.0
  },
  glucose: {
    healthyMin: 70,
    healthyMax: 100,
    absoluteMin: 40,
    absoluteMax: 300,
    weight: 1.5
  },
  hba1c: {
    healthyMin: 0,
    healthyMax: 5.6,
    absoluteMin: 0,
    absoluteMax: 15,
    weight: 1.5
  },
  bmi: {
    healthyMin: 18.5,
    healthyMax: 24.9,
    absoluteMin: 15,
    absoluteMax: 50,
    weight: 1.2
  },
  waistCircumference: {
    healthyMin: 0,
    healthyMax: 88, // Específico para mujeres
    absoluteMin: 50,
    absoluteMax: 150,
    weight: 1.2
  },
  smokingPackYears: {
    healthyMin: 0,
    healthyMax: 0,
    absoluteMin: 0,
    absoluteMax: 100,
    weight: 2.0 // Muy alto peso
  },
  
  // Grupo B: Femeninos
  ageAtMenarche: {
    healthyMin: 11,
    healthyMax: 15,
    absoluteMin: 8,
    absoluteMax: 18,
    weight: 0.8
  },
  parity: {
    healthyMin: 0,
    healthyMax: 4,
    absoluteMin: 0,
    absoluteMax: 10,
    weight: 0.6
  },
  ageAtFirstPregnancy: {
    healthyMin: 20,
    healthyMax: 35,
    absoluteMin: 12,
    absoluteMax: 50,
    weight: 0.7
  },
  preeclampsiaHistory: {
    healthyMin: 0,
    healthyMax: 0,
    absoluteMin: 0,
    absoluteMax: 1,
    weight: 2.0 // Alto riesgo
  },
  gestationalDiabetesHistory: {
    healthyMin: 0,
    healthyMax: 0,
    absoluteMin: 0,
    absoluteMax: 1,
    weight: 2.0
  },
  ageAtMenopause: {
    healthyMin: 45,
    healthyMax: 55,
    absoluteMin: 30,
    absoluteMax: 65,
    weight: 1.0
  },
  hormonalTherapyDuration: {
    healthyMin: 0,
    healthyMax: 5,
    absoluteMin: 0,
    absoluteMax: 30,
    weight: 0.8
  },
  pcos: {
    healthyMin: 0,
    healthyMax: 0,
    absoluteMin: 0,
    absoluteMax: 1,
    weight: 1.5
  },
  
  // Grupo C: Biomarcadores
  crpUltrasensitive: {
    healthyMin: 0,
    healthyMax: 3.0,
    absoluteMin: 0,
    absoluteMax: 20,
    weight: 1.5
  },
  lipoproteinA: {
    healthyMin: 0,
    healthyMax: 30,
    absoluteMin: 0,
    absoluteMax: 150,
    weight: 1.5
  },
  homocysteine: {
    healthyMin: 5,
    healthyMax: 15,
    absoluteMin: 0,
    absoluteMax: 100,
    weight: 1.0
  },
  bnp: {
    healthyMin: 0,
    healthyMax: 100,
    absoluteMin: 0,
    absoluteMax: 2000,
    weight: 1.2
  },
  ntProBnp: {
    healthyMin: 0,
    healthyMax: 125,
    absoluteMin: 0,
    absoluteMax: 5000,
    weight: 1.2
  },
  troponinUltrasensitive: {
    healthyMin: 0,
    healthyMax: 14, // ng/L para mujeres
    absoluteMin: 0,
    absoluteMax: 100,
    weight: 1.5
  },
  
  // Grupo D: Estilo de Vida
  dietScore: {
    healthyMin: 70,
    healthyMax: 100,
    absoluteMin: 0,
    absoluteMax: 100,
    weight: 1.2
  },
  physicalActivityMinutes: {
    healthyMin: 150,
    healthyMax: 300,
    absoluteMin: 0,
    absoluteMax: 1000,
    weight: 1.5
  },
  sleepHours: {
    healthyMin: 7,
    healthyMax: 9,
    absoluteMin: 3,
    absoluteMax: 14,
    weight: 1.2
  },
  sleepQuality: {
    healthyMin: 7,
    healthyMax: 10,
    absoluteMin: 0,
    absoluteMax: 10,
    weight: 1.0
  },
  stressLevel: {
    healthyMin: 0,
    healthyMax: 4,
    absoluteMin: 0,
    absoluteMax: 10,
    weight: 1.3
  },
  medicationAdherence: {
    healthyMin: 80,
    healthyMax: 100,
    absoluteMin: 0,
    absoluteMax: 100,
    weight: 1.2
  }
};

// ============================================
// FUNCIONES DE NORMALIZACIÓN
// ============================================

/**
 * Normaliza un valor a escala 0-1 según rangos saludables
 * 1.0 = óptimo (dentro del rango saludable)
 * 0.0 = peor caso (extremos absolutos)
 */
export function normalizeMetricValue(
  value: number | undefined,
  range: MetricRange
): number {
  if (value === undefined || value === null) {
    return 0.5; // Valor neutral si no hay dato
  }

  const { healthyMin, healthyMax, absoluteMin, absoluteMax } = range;

  // Si está dentro del rango saludable, score = 1.0
  if (value >= healthyMin && value <= healthyMax) {
    return 1.0;
  }

  // Si está por debajo del mínimo saludable
  if (value < healthyMin) {
    const range = healthyMin - absoluteMin;
    const distance = healthyMin - value;
    return Math.max(0, 1 - (distance / range));
  }

  // Si está por encima del máximo saludable
  if (value > healthyMax) {
    const range = absoluteMax - healthyMax;
    const distance = value - healthyMax;
    return Math.max(0, 1 - (distance / range));
  }

  return 0.5; // Fallback
}

/**
 * Calcula score ponderado para un grupo de métricas
 */
export function calculateGroupScore(
  metrics: Record<string, number | undefined | boolean>,
  metricKeys: string[]
): number {
  let totalWeight = 0;
  let weightedSum = 0;

  metricKeys.forEach(key => {
    const value = metrics[key];
    const range = METRIC_RANGES[key];
    
    if (!range) return;

    // Convertir booleanos a números (true = 1, false = 0)
    const numericValue = typeof value === 'boolean' ? (value ? 1 : 0) : value;

    const normalizedScore = normalizeMetricValue(numericValue, range);
    const weight = range.weight || 1.0;

    weightedSum += normalizedScore * weight;
    totalWeight += weight;
  });

  return totalWeight > 0 ? weightedSum / totalWeight : 0.5;
}

// ============================================
// CÁLCULO PRINCIPAL DEL HSCORE
// ============================================

export function calculateHGraphScore(
  data: PatientHealthData,
  weights: GroupWeights = DEFAULT_GROUP_WEIGHTS
): HGraphScore {
  
  // ========================================
  // GRUPO A: FACTORES TRADICIONALES
  // ========================================
  const grupoAMetrics = {
    bloodPressureSystolic: data.bloodPressureSystolic,
    bloodPressureDiastolic: data.bloodPressureDiastolic,
    ldlCholesterol: data.ldlCholesterol,
    hdlCholesterol: data.hdlCholesterol,
    triglycerides: data.triglycerides,
    glucose: data.glucose,
    hba1c: data.hba1c,
    bmi: data.bmi,
    waistCircumference: data.waistCircumference,
    smokingPackYears: data.smokingPackYears
  };
  
  const grupoA = calculateGroupScore(
    grupoAMetrics,
    Object.keys(grupoAMetrics)
  );

  // ========================================
  // GRUPO B: FACTORES FEMENINOS
  // ========================================
  const grupoBMetrics = {
    ageAtMenarche: data.ageAtMenarche,
    parity: data.parity,
    ageAtFirstPregnancy: data.ageAtFirstPregnancy,
    preeclampsiaHistory: data.preeclampsiaHistory,
    gestationalDiabetesHistory: data.gestationalDiabetesHistory,
    ageAtMenopause: data.ageAtMenopause,
    hormonalTherapyDuration: data.hormonalTherapyDuration,
    pcos: data.pcos
  };
  
  const grupoB = calculateGroupScore(
    grupoBMetrics,
    Object.keys(grupoBMetrics)
  );

  // ========================================
  // GRUPO C: BIOMARCADORES
  // ========================================
  const grupoCMetrics = {
    crpUltrasensitive: data.crpUltrasensitive,
    lipoproteinA: data.lipoproteinA,
    homocysteine: data.homocysteine,
    bnp: data.bnp,
    ntProBnp: data.ntProBnp,
    troponinUltrasensitive: data.troponinUltrasensitive
  };
  
  const grupoC = calculateGroupScore(
    grupoCMetrics,
    Object.keys(grupoCMetrics)
  );

  // ========================================
  // GRUPO D: ESTILO DE VIDA
  // ========================================
  const grupoDMetrics = {
    dietScore: data.dietScore,
    physicalActivityMinutes: data.physicalActivityMinutes,
    sleepHours: data.sleepHours,
    sleepQuality: data.sleepQuality,
    stressLevel: data.stressLevel,
    medicationAdherence: data.medicationAdherence
  };
  
  const grupoD = calculateGroupScore(
    grupoDMetrics,
    Object.keys(grupoDMetrics)
  );

  // ========================================
  // SCORE COMPUESTO
  // ========================================
  const compositeScore = (
    (grupoA * weights.grupoA) +
    (grupoB * weights.grupoB) +
    (grupoC * weights.grupoC) +
    (grupoD * weights.grupoD)
  );

  // Convertir a escala 0-100 (hScore)
  const hScore = Math.round(compositeScore * 100);

  // ========================================
  // INTERPRETACIÓN DE RIESGO
  // ========================================
  const interpretation = interpretRisk({
    grupoA,
    grupoB,
    grupoC,
    grupoD
  }, hScore);

  return {
    composite: hScore,
    dimensions: {
      grupoA,
      grupoB,
      grupoC,
      grupoD
    },
    raw: {
      grupoA,
      grupoB,
      grupoC,
      grupoD
    },
    interpretation
  };
}

// ============================================
// INTERPRETACIÓN DE RIESGO
// ============================================

function interpretGroup(score: number): 'normal' | 'leve' | 'moderado' | 'alto' {
  if (score >= 0.80) return 'normal';
  if (score >= 0.60) return 'leve';
  if (score >= 0.40) return 'moderado';
  return 'alto';
}

function interpretOverall(hScore: number): 'bajo' | 'moderado' | 'alto' | 'muy-alto' {
  if (hScore >= 80) return 'bajo';
  if (hScore >= 60) return 'moderado';
  if (hScore >= 40) return 'alto';
  return 'muy-alto';
}

function generateRecommendations(
  dimensions: GroupScore,
  hScore: number
): string[] {
  const recommendations: string[] = [];

  // Recomendaciones por grupo
  if (dimensions.grupoA < 0.70) {
    recommendations.push(
      'Control de factores de riesgo cardiovascular tradicionales',
      'Evaluación con especialista en cardiología'
    );
    if (dimensions.grupoA < 0.50) {
      recommendations.push('Iniciar tratamiento farmacológico según indicación médica');
    }
  }

  if (dimensions.grupoB < 0.70) {
    recommendations.push(
      'Evaluación ginecológica completa',
      'Screening cardiovascular enfocado en factores reproductivos'
    );
  }

  if (dimensions.grupoC < 0.70) {
    recommendations.push(
      'Estudios de biomarcadores avanzados',
      'Valoración de inflamación sistémica'
    );
  }

  if (dimensions.grupoD < 0.70) {
    recommendations.push(
      'Intervención en estilo de vida: Life\'s Essential 8',
      'Programa de actividad física supervisada'
    );
    if (dimensions.grupoD < 0.50) {
      recommendations.push(
        'Intervención intensiva en modificación de conducta',
        'Apoyo nutricional y psicológico'
      );
    }
  }

  // Recomendaciones por score global
  if (hScore < 60) {
    recommendations.push(
      'Seguimiento cardiovascular estrecho',
      'Plan integral de reducción de riesgo',
      'Considerar programa de rehabilitación cardiovascular'
    );
  }

  return recommendations;
}

export function interpretRisk(
  dimensions: GroupScore,
  hScore: number
): RiskInterpretation {
  return {
    overall: interpretOverall(hScore),
    grupoA: interpretGroup(dimensions.grupoA),
    grupoB: interpretGroup(dimensions.grupoB),
    grupoC: interpretGroup(dimensions.grupoC),
    grupoD: interpretGroup(dimensions.grupoD),
    recommendations: generateRecommendations(dimensions, hScore)
  };
}

// ============================================
// UTILIDADES DE FORMATO
// ============================================

export function formatScore(score: number): string {
  return score.toFixed(1);
}

export function getRiskColor(risk: string): string {
  const colors: Record<string, string> = {
    'bajo': '#2ECC71',
    'normal': '#2ECC71',
    'leve': '#F39C12',
    'moderado': '#E67E22',
    'alto': '#E74C3C',
    'muy-alto': '#C0392B'
  };
  return colors[risk] || '#95A5A6';
}

export function getRiskLabel(risk: string): string {
  const labels: Record<string, string> = {
    'bajo': 'Riesgo Bajo',
    'normal': 'Normal',
    'leve': 'Riesgo Leve',
    'moderado': 'Riesgo Moderado',
    'alto': 'Riesgo Alto',
    'muy-alto': 'Riesgo Muy Alto'
  };
  return labels[risk] || 'Sin clasificar';
}
