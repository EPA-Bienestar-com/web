/**
 * EPA Bienestar IA - HGraph Cardiovascular Femenino
 * Componente React principal con integración FHIR R4
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { MedplumClient } from '@medplum/core';
// @ts-ignore
import HGraph from 'hgraph-react';
import {
  HGraphCVDFemaleProps,
  HGraphScore,
  HGraphMetric,
  HGraphGroup,
  PatientHealthData,
  DEFAULT_VISUAL_CONFIG,
  DEFAULT_GROUP_WEIGHTS
} from './types';
import { usePatientHealthData, usePatient } from './hooks';
import { calculateHGraphScore, getRiskColor, getRiskLabel } from './calculator';
import { transformToHGraphData } from './transformer';

// ============================================
// ESTILOS CSS-IN-JS
// ============================================

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '24px',
    padding: '24px',
    backgroundColor: '#F8F9FA',
    borderRadius: '12px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottom: '2px solid #E9ECEF',
    paddingBottom: '16px'
  },
  title: {
    fontSize: '28px',
    fontWeight: 700,
    color: '#212529',
    margin: 0
  },
  patientInfo: {
    fontSize: '16px',
    color: '#6C757D'
  },
  mainContent: {
    display: 'grid',
    gridTemplateColumns: '2fr 1fr',
    gap: '24px',
    alignItems: 'start'
  },
  hgraphContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: '8px',
    padding: '24px',
    boxShadow: '0 1px 4px rgba(0,0,0,0.08)'
  },
  scorePanel: {
    backgroundColor: '#FFFFFF',
    borderRadius: '8px',
    padding: '24px',
    boxShadow: '0 1px 4px rgba(0,0,0,0.08)',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px'
  },
  scoreValue: {
    fontSize: '64px',
    fontWeight: 700,
    textAlign: 'center' as const,
    margin: '16px 0'
  },
  scoreLabel: {
    fontSize: '18px',
    fontWeight: 600,
    textAlign: 'center' as const,
    textTransform: 'uppercase' as const,
    letterSpacing: '1px'
  },
  dimensionScores: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '12px',
    marginTop: '16px'
  },
  dimensionRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '12px',
    backgroundColor: '#F8F9FA',
    borderRadius: '6px',
    borderLeft: '4px solid'
  },
  dimensionLabel: {
    fontSize: '14px',
    fontWeight: 600,
    color: '#495057'
  },
  dimensionValue: {
    fontSize: '16px',
    fontWeight: 700
  },
  recommendations: {
    backgroundColor: '#FFFFFF',
    borderRadius: '8px',
    padding: '24px',
    boxShadow: '0 1px 4px rgba(0,0,0,0.08)',
    gridColumn: '1 / -1'
  },
  recommendationsTitle: {
    fontSize: '20px',
    fontWeight: 700,
    color: '#212529',
    marginBottom: '16px'
  },
  recommendationsList: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '12px'
  },
  recommendationItem: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '12px',
    padding: '12px',
    backgroundColor: '#F1F3F5',
    borderRadius: '6px',
    fontSize: '14px',
    lineHeight: '1.6'
  },
  recommendationIcon: {
    fontSize: '20px',
    flexShrink: 0
  },
  loadingContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '400px',
    fontSize: '18px',
    color: '#6C757D'
  },
  errorContainer: {
    padding: '24px',
    backgroundColor: '#FFF3CD',
    borderLeft: '4px solid #FFC107',
    borderRadius: '6px',
    color: '#856404'
  },
  legend: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, 1fr)',
    gap: '12px',
    marginTop: '16px',
    padding: '16px',
    backgroundColor: '#F8F9FA',
    borderRadius: '6px'
  },
  legendItem: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '14px'
  },
  legendColor: {
    width: '16px',
    height: '16px',
    borderRadius: '4px',
    flexShrink: 0
  }
};

// ============================================
// COMPONENTE PRINCIPAL
// ============================================

export const HGraphCVDFemale: React.FC<HGraphCVDFemaleProps & { medplum: MedplumClient }> = ({
  medplum,
  patientId,
  observations,
  onScoreCalculated,
  onMetricClick,
  visualConfig = {},
  groupWeights = {},
  showLegend = true,
  showRecommendations = true,
  enableRealTimeUpdates = false,
  comparisonMode = 'single'
}) => {
  // ========================================
  // HOOKS Y STATE
  // ========================================
  
  const { patient, loading: patientLoading } = usePatient(medplum, patientId);
  const { data: healthData, loading: dataLoading, error, refetch } = usePatientHealthData(
    medplum,
    patientId
  );

  const [hgraphScore, setHgraphScore] = useState<HGraphScore | null>(null);
  const [selectedMetric, setSelectedMetric] = useState<HGraphMetric | null>(null);

  // Combinar configuraciones
  const finalVisualConfig = useMemo(
    () => ({ ...DEFAULT_VISUAL_CONFIG, ...visualConfig }),
    [visualConfig]
  );

  const finalGroupWeights = useMemo(
    () => ({ ...DEFAULT_GROUP_WEIGHTS, ...groupWeights }),
    [groupWeights]
  );

  // ========================================
  // TRANSFORMAR DATOS Y CALCULAR SCORE
  // ========================================

  const hgraphData = useMemo(() => {
    if (!healthData) return [];
    return transformToHGraphData(healthData);
  }, [healthData]);

  useEffect(() => {
    if (!healthData) return;

    const score = calculateHGraphScore(healthData, finalGroupWeights);
    setHgraphScore(score);

    if (onScoreCalculated) {
      onScoreCalculated(score);
    }
  }, [healthData, finalGroupWeights, onScoreCalculated]);

  // ========================================
  // HANDLERS
  // ========================================

  const handleMetricClick = useCallback(
    (metric: any, event: React.MouseEvent) => {
      setSelectedMetric(metric);
      if (onMetricClick) {
        onMetricClick(metric, event);
      }
    },
    [onMetricClick]
  );

  // ========================================
  // ESTADOS DE CARGA Y ERROR
  // ========================================

  if (patientLoading || dataLoading) {
    return (
      <div style={styles.loadingContainer}>
        <div>
          <div style={{ marginBottom: '16px' }}>⏳</div>
          <div>Cargando datos del paciente...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={styles.errorContainer}>
        <strong>Error al cargar datos:</strong>
        <p>{error.message}</p>
        <button onClick={refetch} style={{ marginTop: '12px' }}>
          Reintentar
        </button>
      </div>
    );
  }

  if (!healthData || !hgraphScore) {
    return (
      <div style={styles.errorContainer}>
        <strong>No hay datos disponibles</strong>
        <p>No se encontraron datos de salud para este paciente.</p>
      </div>
    );
  }

  // ========================================
  // RENDER
  // ========================================

  const patientName = patient
    ? `${patient.name?.[0]?.given?.[0] || ''} ${patient.name?.[0]?.family || ''}`.trim()
    : 'Paciente';

  return (
    <div style={styles.container}>
      {/* ========================================
          HEADER
      ======================================== */}
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>HGraph Cardiovascular Femenino</h1>
          <p style={styles.patientInfo}>
            {patientName} • {patient?.birthDate || 'Sin fecha de nacimiento'}
          </p>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: '12px', color: '#6C757D' }}>Programa Mujer</div>
          <div style={{ fontSize: '12px', color: '#6C757D' }}>
            EPA Bienestar IA
          </div>
        </div>
      </div>

      {/* ========================================
          CONTENIDO PRINCIPAL
      ======================================== */}
      <div style={styles.mainContent}>
        {/* HGRAPH VISUALIZATION */}
        <div style={styles.hgraphContainer}>
          <HGraph
            data={hgraphData}
            score={hgraphScore.composite}
            onPointClick={handleMetricClick}
            {...finalVisualConfig}
          />
          
          {showLegend && (
            <div style={styles.legend}>
              <div style={styles.legendItem}>
                <div style={{ ...styles.legendColor, backgroundColor: '#E74C3C' }} />
                <span>Factores Tradicionales</span>
              </div>
              <div style={styles.legendItem}>
                <div style={{ ...styles.legendColor, backgroundColor: '#9B59B6' }} />
                <span>Factores Femeninos</span>
              </div>
              <div style={styles.legendItem}>
                <div style={{ ...styles.legendColor, backgroundColor: '#3498DB' }} />
                <span>Biomarcadores</span>
              </div>
              <div style={styles.legendItem}>
                <div style={{ ...styles.legendColor, backgroundColor: '#2ECC71' }} />
                <span>Estilo de Vida</span>
              </div>
            </div>
          )}
        </div>

        {/* SCORE PANEL */}
        <div style={styles.scorePanel}>
          <h3 style={{ margin: 0, fontSize: '18px', color: '#495057' }}>
            Score Global
          </h3>
          
          <div
            style={{
              ...styles.scoreValue,
              color: getRiskColor(hgraphScore.interpretation.overall)
            }}
          >
            {hgraphScore.composite}
          </div>
          
          <div
            style={{
              ...styles.scoreLabel,
              color: getRiskColor(hgraphScore.interpretation.overall)
            }}
          >
            {getRiskLabel(hgraphScore.interpretation.overall)}
          </div>

          <div style={{ borderTop: '1px solid #DEE2E6', paddingTop: '16px' }}>
            <h4 style={{ margin: '0 0 12px 0', fontSize: '16px', color: '#495057' }}>
              Scores por Dimensión
            </h4>
            
            <div style={styles.dimensionScores}>
              {/* Grupo A */}
              <div
                style={{
                  ...styles.dimensionRow,
                  borderLeftColor: '#E74C3C'
                }}
              >
                <span style={styles.dimensionLabel}>Factores Tradicionales</span>
                <span
                  style={{
                    ...styles.dimensionValue,
                    color: getRiskColor(hgraphScore.interpretation.grupoA)
                  }}
                >
                  {(hgraphScore.dimensions.grupoA * 100).toFixed(0)}
                </span>
              </div>

              {/* Grupo B */}
              <div
                style={{
                  ...styles.dimensionRow,
                  borderLeftColor: '#9B59B6'
                }}
              >
                <span style={styles.dimensionLabel}>Factores Femeninos</span>
                <span
                  style={{
                    ...styles.dimensionValue,
                    color: getRiskColor(hgraphScore.interpretation.grupoB)
                  }}
                >
                  {(hgraphScore.dimensions.grupoB * 100).toFixed(0)}
                </span>
              </div>

              {/* Grupo C */}
              <div
                style={{
                  ...styles.dimensionRow,
                  borderLeftColor: '#3498DB'
                }}
              >
                <span style={styles.dimensionLabel}>Biomarcadores</span>
                <span
                  style={{
                    ...styles.dimensionValue,
                    color: getRiskColor(hgraphScore.interpretation.grupoC)
                  }}
                >
                  {(hgraphScore.dimensions.grupoC * 100).toFixed(0)}
                </span>
              </div>

              {/* Grupo D */}
              <div
                style={{
                  ...styles.dimensionRow,
                  borderLeftColor: '#2ECC71'
                }}
              >
                <span style={styles.dimensionLabel}>Estilo de Vida</span>
                <span
                  style={{
                    ...styles.dimensionValue,
                    color: getRiskColor(hgraphScore.interpretation.grupoD)
                  }}
                >
                  {(hgraphScore.dimensions.grupoD * 100).toFixed(0)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================
          RECOMENDACIONES
      ======================================== */}
      {showRecommendations && hgraphScore.interpretation.recommendations.length > 0 && (
        <div style={styles.recommendations}>
          <h3 style={styles.recommendationsTitle}>
            Recomendaciones Clínicas
          </h3>
          
          <div style={styles.recommendationsList}>
            {hgraphScore.interpretation.recommendations.map((rec, index) => (
              <div key={index} style={styles.recommendationItem}>
                <span style={styles.recommendationIcon}>📋</span>
                <span>{rec}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================
          METRIC DETAIL MODAL (opcional)
      ======================================== */}
      {selectedMetric && (
        <MetricDetailModal
          metric={selectedMetric}
          onClose={() => setSelectedMetric(null)}
        />
      )}
    </div>
  );
};

// ============================================
// COMPONENTE: MODAL DE DETALLE DE MÉTRICA
// ============================================

interface MetricDetailModalProps {
  metric: HGraphMetric;
  onClose: () => void;
}

const MetricDetailModal: React.FC<MetricDetailModalProps> = ({ metric, onClose }) => {
  const isHealthy = metric.value >= metric.healthyMin && metric.value <= metric.healthyMax;
  
  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0,0,0,0.5)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 1000
      }}
      onClick={onClose}
    >
      <div
        style={{
          backgroundColor: '#FFFFFF',
          borderRadius: '12px',
          padding: '32px',
          maxWidth: '500px',
          width: '90%',
          boxShadow: '0 8px 32px rgba(0,0,0,0.2)'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <h2 style={{ margin: '0 0 16px 0', fontSize: '24px', color: '#212529' }}>
          {metric.label}
        </h2>
        
        <div style={{ marginBottom: '24px' }}>
          <div style={{ fontSize: '48px', fontWeight: 700, color: isHealthy ? '#2ECC71' : '#E74C3C' }}>
            {metric.value.toFixed(1)} <span style={{ fontSize: '24px' }}>{metric.unitLabel}</span>
          </div>
          <div style={{ fontSize: '14px', color: '#6C757D', marginTop: '8px' }}>
            {isHealthy ? '✓ Dentro del rango saludable' : '⚠ Fuera del rango saludable'}
          </div>
        </div>

        <div style={{ marginBottom: '24px' }}>
          <h4 style={{ margin: '0 0 8px 0', fontSize: '16px', color: '#495057' }}>
            Rango Saludable
          </h4>
          <div style={{ fontSize: '14px', color: '#6C757D' }}>
            {metric.healthyMin} - {metric.healthyMax} {metric.unitLabel}
          </div>
        </div>

        {metric.fhirReference && (
          <div style={{ fontSize: '12px', color: '#ADB5BD', marginTop: '16px' }}>
            Referencia FHIR: {metric.fhirReference}
          </div>
        )}

        <button
          onClick={onClose}
          style={{
            marginTop: '24px',
            padding: '12px 24px',
            backgroundColor: '#007BFF',
            color: '#FFFFFF',
            border: 'none',
            borderRadius: '6px',
            fontSize: '16px',
            fontWeight: 600,
            cursor: 'pointer',
            width: '100%'
          }}
        >
          Cerrar
        </button>
      </div>
    </div>
  );
};

// ============================================
// EXPORTAR
// ============================================

export default HGraphCVDFemale;
