/**
 * EPA Bienestar IA - Ejemplo de Uso del HGraph CVD Female
 * 
 * Este archivo muestra cómo integrar el componente HGraphCVDFemale
 * en diferentes contextos: cuestionarios, Life's Essential 8, y dashboards
 */

import React from 'react';
import { MedplumClient } from '@medplum/core';
import { HGraphCVDFemale } from './HGraphCVDFemale';

// ============================================
// CONFIGURACIÓN DEL CLIENTE MEDPLUM
// ============================================

const medplum = new MedplumClient({
  baseUrl: 'https://api.epa-bienestar.com.ar',
  // Autenticación configurada previamente
});

// ============================================
// EJEMPLO 1: USO BÁSICO
// ============================================

export const BasicExample: React.FC = () => {
  return (
    <HGraphCVDFemale
      medplum={medplum}
      patientId="patient-12345"
    />
  );
};

// ============================================
// EJEMPLO 2: DESPUÉS DE CUESTIONARIO DE DETERMINANTES
// ============================================

export const AfterHealthDeterminantsQuestionnaire: React.FC = () => {
  const handleScoreCalculated = (score) => {
    console.log('Score calculado:', score);
    
    // Enviar a analytics
    trackEvent('hgraph_score_calculated', {
      composite: score.composite,
      grupoA: score.dimensions.grupoA,
      grupoB: score.dimensions.grupoB,
      grupoC: score.dimensions.grupoC,
      grupoD: score.dimensions.grupoD,
      riskLevel: score.interpretation.overall
    });
    
    // Guardar en Medplum como Observation
    saveHGraphScoreToFHIR(score);
  };

  return (
    <div style={{ padding: '24px' }}>
      <div style={{ marginBottom: '24px' }}>
        <h2>Cuestionario de Determinantes de Salud Completado ✓</h2>
        <p>A continuación, visualiza tu perfil de salud cardiovascular:</p>
      </div>
      
      <HGraphCVDFemale
        medplum={medplum}
        patientId="patient-12345"
        onScoreCalculated={handleScoreCalculated}
        showRecommendations={true}
        showLegend={true}
      />
    </div>
  );
};

// ============================================
// EJEMPLO 3: INTEGRADO CON LIFE'S ESSENTIAL 8
// ============================================

export const LifesEssential8Dashboard: React.FC = () => {
  const [selectedView, setSelectedView] = React.useState<'hgraph' | 'detailed'>('hgraph');

  return (
    <div style={{ padding: '24px' }}>
      <div style={{ marginBottom: '24px', display: 'flex', gap: '12px' }}>
        <button
          onClick={() => setSelectedView('hgraph')}
          style={{
            padding: '12px 24px',
            backgroundColor: selectedView === 'hgraph' ? '#007BFF' : '#E9ECEF',
            color: selectedView === 'hgraph' ? '#FFF' : '#495057',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer'
          }}
        >
          Vista HGraph
        </button>
        <button
          onClick={() => setSelectedView('detailed')}
          style={{
            padding: '12px 24px',
            backgroundColor: selectedView === 'detailed' ? '#007BFF' : '#E9ECEF',
            color: selectedView === 'detailed' ? '#FFF' : '#495057',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer'
          }}
        >
          Vista Detallada
        </button>
      </div>

      {selectedView === 'hgraph' ? (
        <HGraphCVDFemale
          medplum={medplum}
          patientId="patient-12345"
          visualConfig={{
            width: 700,
            height: 700,
            showScore: true
          }}
        />
      ) : (
        <DetailedMetricsView patientId="patient-12345" />
      )}
    </div>
  );
};

// ============================================
// EJEMPLO 4: COMPARACIÓN TEMPORAL
// ============================================

export const TemporalComparisonView: React.FC = () => {
  return (
    <div style={{ padding: '24px' }}>
      <h2>Evolución del Score Cardiovascular</h2>
      
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', marginTop: '24px' }}>
        <div>
          <h3>Evaluación Inicial (Enero 2026)</h3>
          <HGraphCVDFemale
            medplum={medplum}
            patientId="patient-12345"
            visualConfig={{ width: 400, height: 400 }}
            showRecommendations={false}
          />
        </div>
        
        <div>
          <h3>Evaluación Actual (Abril 2026)</h3>
          <HGraphCVDFemale
            medplum={medplum}
            patientId="patient-12345"
            visualConfig={{ width: 400, height: 400 }}
            showRecommendations={false}
          />
        </div>
      </div>
    </div>
  );
};

// ============================================
// EJEMPLO 5: PERSONALIZACIÓN AVANZADA
// ============================================

export const CustomizedHGraph: React.FC = () => {
  const handleMetricClick = (metric, event) => {
    console.log('Métrica clickeada:', metric);
    
    // Abrir modal con información detallada
    // Mostrar tendencia histórica de la métrica
    // Ofrecer intervenciones específicas
  };

  return (
    <HGraphCVDFemale
      medplum={medplum}
      patientId="patient-12345"
      onMetricClick={handleMetricClick}
      visualConfig={{
        width: 800,
        height: 800,
        color: '#9B59B6', // Color personalizado
        healthyRangeFillColor: '#E8F5E9',
        showScore: true,
        scoreFontSize: 140,
        pointRadius: 12,
        areaOpacity: 0.3,
        zoomOnPointClick: true
      }}
      groupWeights={{
        grupoA: 0.40, // Mayor peso a factores tradicionales
        grupoB: 0.30, // Mayor peso a factores femeninos
        grupoC: 0.15,
        grupoD: 0.15
      }}
      showLegend={true}
      showRecommendations={true}
      enableRealTimeUpdates={true}
    />
  );
};

// ============================================
// EJEMPLO 6: DASHBOARD DEL PROGRAMA MUJER
// ============================================

export const ProgramaMujerDashboard: React.FC = () => {
  const [patients, setPatients] = React.useState([
    { id: 'patient-001', name: 'María García', lastScore: 72 },
    { id: 'patient-002', name: 'Ana López', lastScore: 58 },
    { id: 'patient-003', name: 'Carmen Rodríguez', lastScore: 85 },
  ]);

  const [selectedPatient, setSelectedPatient] = React.useState(patients[0].id);

  return (
    <div style={{ padding: '24px' }}>
      <h1>Dashboard - Programa Mujer</h1>
      
      {/* Lista de pacientes */}
      <div style={{ marginBottom: '24px' }}>
        <h3>Pacientes</h3>
        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
          {patients.map((patient) => (
            <button
              key={patient.id}
              onClick={() => setSelectedPatient(patient.id)}
              style={{
                padding: '12px 24px',
                backgroundColor: selectedPatient === patient.id ? '#9B59B6' : '#E9ECEF',
                color: selectedPatient === patient.id ? '#FFF' : '#495057',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer'
              }}
            >
              {patient.name}
              <br />
              <small>Score: {patient.lastScore}</small>
            </button>
          ))}
        </div>
      </div>

      {/* HGraph del paciente seleccionado */}
      <HGraphCVDFemale
        medplum={medplum}
        patientId={selectedPatient}
        showRecommendations={true}
        showLegend={true}
      />
    </div>
  );
};

// ============================================
// UTILIDADES
// ============================================

async function saveHGraphScoreToFHIR(score) {
  const observation = {
    resourceType: 'Observation',
    status: 'final',
    code: {
      coding: [{
        system: 'http://epa-bienestar.com.ar/fhir/CodeSystem/hgraph-scores',
        code: 'hgraph-cvd-female',
        display: 'HGraph Score Cardiovascular Femenino'
      }]
    },
    subject: {
      reference: `Patient/${score.patientId}`
    },
    effectiveDateTime: new Date().toISOString(),
    valueQuantity: {
      value: score.composite,
      unit: 'score',
      system: 'http://unitsofmeasure.org',
      code: '{score}'
    },
    component: [
      {
        code: {
          coding: [{
            system: 'http://epa-bienestar.com.ar/fhir/CodeSystem/hgraph-dimensions',
            code: 'grupo-a-traditional'
          }]
        },
        valueQuantity: {
          value: score.dimensions.grupoA,
          unit: 'score'
        }
      },
      // ... otros componentes
    ]
  };

  await medplum.createResource(observation);
}

function trackEvent(eventName: string, properties: any) {
  // Integración con analytics (Google Analytics, Mixpanel, etc.)
  console.log('Analytics Event:', eventName, properties);
}

const DetailedMetricsView: React.FC<{ patientId: string }> = ({ patientId }) => {
  return (
    <div>
      <h3>Vista Detallada de Métricas</h3>
      {/* Implementar tabla con todas las métricas */}
    </div>
  );
};

// ============================================
// EXPORTAR EJEMPLOS
// ============================================

export default {
  BasicExample,
  AfterHealthDeterminantsQuestionnaire,
  LifesEssential8Dashboard,
  TemporalComparisonView,
  CustomizedHGraph,
  ProgramaMujerDashboard
};
