/**
 * EPA Bienestar IA - HGraph Cardiovascular Femenino
 * Punto de entrada principal del paquete
 */

// Componente principal
export { HGraphCVDFemale, default as HGraphCVDFemaleComponent } from './HGraphCVDFemale';

// Tipos
export type {
  HGraphMetric,
  HGraphGroup,
  HGraphScore,
  GroupScore,
  RiskInterpretation,
  PatientHealthData,
  HGraphObservation,
  HGraphCVDFemaleProps,
  HGraphVisualConfig,
  GroupWeights,
  MetricRange
} from './types';

export {
  DEFAULT_VISUAL_CONFIG,
  DEFAULT_GROUP_WEIGHTS,
  FHIR_SYSTEMS,
  EPA_CODES,
  LOINC_CODES
} from './types';

// Hooks
export {
  usePatientHealthData,
  useRealtimeObservations,
  usePatient
} from './hooks';

export type { UsePatientHealthDataResult } from './hooks';

// Utilidades de cálculo
export {
  calculateHGraphScore,
  normalizeMetricValue,
  calculateGroupScore,
  interpretRisk,
  formatScore,
  getRiskColor,
  getRiskLabel,
  METRIC_RANGES
} from './calculator';

// Transformador de datos
export {
  transformToHGraphData,
  GROUP_COLORS
} from './transformer';

// Ejemplos
export {
  BasicExample,
  AfterHealthDeterminantsQuestionnaire,
  LifesEssential8Dashboard,
  TemporalComparisonView,
  CustomizedHGraph,
  ProgramaMujerDashboard
} from './examples';
