# HGraph Cardiovascular Femenino - EPA Bienestar IA

**Visualización integral de salud cardiovascular femenina con integración FHIR R4**

[![TypeScript](https://img.shields.io/badge/TypeScript-5.1-blue.svg)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-18-61dafb.svg)](https://reactjs.org/)
[![FHIR R4](https://img.shields.io/badge/FHIR-R4-green.svg)](https://www.hl7.org/fhir/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## 🎯 Descripción

Componente React avanzado que visualiza la salud cardiovascular femenina mediante **HGraph**, integrando:

- ✅ **Factores de Riesgo Tradicionales** (Grupo A): Presión arterial, colesterol, glucosa, IMC, tabaquismo
- ✅ **Factores Específicos Femeninos** (Grupo B): Historia reproductiva, preeclampsia, diabetes gestacional, menopausia, PCOS
- ✅ **Biomarcadores Avanzados** (Grupo C): PCR-hs, Lp(a), homocisteína, BNP, troponina
- ✅ **Life's Essential 8** (Grupo D): Dieta, actividad física, sueño, estrés, adherencia

### Características Principales

🔹 **Data-Driven**: Extrae datos automáticamente desde servidores FHIR R4 (Medplum)  
🔹 **Cálculo Automático de hScore**: Algoritmo propietario para score cardiovascular 0-100  
🔹 **Interactivo**: Zoom en métricas, drill-down a sub-métricas, modal de detalles  
🔹 **Personalizable**: Colores, pesos de grupos, configuración visual completa  
🔹 **Tiempo Real**: Soporte para actualizaciones WebSocket/polling  
🔹 **Interpretación Clínica**: Recomendaciones automáticas basadas en score  

---

## 📦 Instalación

```bash
npm install @epa-bienestar/hgraph-cvd-female
# o
yarn add @epa-bienestar/hgraph-cvd-female
```

### Dependencias Peer

```bash
npm install react react-dom @medplum/core @medplum/fhirtypes hgraph-react
```

---

## 🚀 Uso Rápido

```tsx
import React from 'react';
import { MedplumClient } from '@medplum/core';
import { HGraphCVDFemale } from '@epa-bienestar/hgraph-cvd-female';

const medplum = new MedplumClient({
  baseUrl: 'https://api.epa-bienestar.com.ar'
});

function App() {
  return (
    <HGraphCVDFemale
      medplum={medplum}
      patientId="patient-12345"
    />
  );
}
```

---

## 📖 Documentación Detallada

### Props del Componente

| Prop | Tipo | Requerido | Descripción | Default |
|------|------|-----------|-------------|---------|
| `medplum` | `MedplumClient` | ✅ | Cliente Medplum configurado | - |
| `patientId` | `string` | ✅ | ID del paciente en FHIR | - |
| `observations` | `Observation[]` | ❌ | Observaciones manuales (omite fetch) | `undefined` |
| `onScoreCalculated` | `(score: HGraphScore) => void` | ❌ | Callback cuando se calcula el score | `undefined` |
| `onMetricClick` | `(metric, event) => void` | ❌ | Callback al clickear métrica | `undefined` |
| `visualConfig` | `Partial<HGraphVisualConfig>` | ❌ | Config visual de hGraph | Ver defaults |
| `groupWeights` | `Partial<GroupWeights>` | ❌ | Pesos de grupos (0-1) | `{A:0.35, B:0.25, C:0.20, D:0.20}` |
| `showLegend` | `boolean` | ❌ | Mostrar leyenda de colores | `true` |
| `showRecommendations` | `boolean` | ❌ | Mostrar recomendaciones clínicas | `true` |
| `enableRealTimeUpdates` | `boolean` | ❌ | Actualizaciones en tiempo real | `false` |

---

## 🎨 Configuración Visual

```tsx
<HGraphCVDFemale
  medplum={medplum}
  patientId="patient-12345"
  visualConfig={{
    width: 800,
    height: 800,
    color: '#9B59B6',
    healthyRangeFillColor: '#E8F5E9',
    showScore: true,
    scoreFontSize: 140,
    pointRadius: 12,
    areaOpacity: 0.3,
    zoomOnPointClick: true
  }}
/>
```

### Opciones Disponibles

```typescript
interface HGraphVisualConfig {
  width?: number;                    // Default: 600
  height?: number;                   // Default: 600
  margin?: { top, right, bottom, left };
  thresholdMin?: number;             // Default: 0.25
  thresholdMax?: number;             // Default: 0.75
  donutHoleFactor?: number;          // Default: 0.4
  color?: string;                    // Default: '#616363'
  healthyRangeFillColor?: string;    // Default: '#98bd8e'
  fontSize?: number;                 // Default: 16
  fontColor?: string;                // Default: '#000'
  showAxisLabel?: boolean;           // Default: true
  areaOpacity?: number;              // Default: 0.25
  pointRadius?: number;              // Default: 10
  showScore?: boolean;               // Default: true
  scoreFontSize?: number;            // Default: 120
  zoomOnPointClick?: boolean;        // Default: true
  zoomFactor?: number;               // Default: 2.25
  zoomTransitionTime?: number;       // Default: 750ms
}
```

---

## 🧮 Cálculo del hScore

### Algoritmo

El **hScore** (0-100) se calcula mediante:

1. **Normalización** de cada métrica a escala 0-1:
   - `1.0` = Valor dentro del rango saludable
   - `0.0` = Valor en los extremos absolutos

2. **Ponderación** por peso de la métrica dentro del grupo

3. **Agregación** por grupo (A, B, C, D) → Score de grupo 0-1

4. **Score Compuesto**:
   ```
   hScore = (grupoA × 0.35) + (grupoB × 0.25) + (grupoC × 0.20) + (grupoD × 0.20)
   hScore_final = hScore × 100
   ```

### Personalizar Pesos

```tsx
<HGraphCVDFemale
  medplum={medplum}
  patientId="patient-12345"
  groupWeights={{
    grupoA: 0.40,  // Mayor peso a tradicionales
    grupoB: 0.30,  // Mayor peso a femeninos
    grupoC: 0.15,
    grupoD: 0.15
  }}
/>
```

---

## 📊 Estructura de Datos FHIR

### Observation: HGraph Score

```json
{
  "resourceType": "Observation",
  "id": "hgraph-cvd-female-20260105",
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "90458-6",
      "display": "Cardiovascular health score"
    }]
  },
  "subject": {
    "reference": "Patient/patient-12345"
  },
  "valueQuantity": {
    "value": 72.5,
    "unit": "score"
  },
  "component": [
    {
      "code": {
        "coding": [{
          "system": "http://epa-bienestar.com.ar/fhir/CodeSystem/hgraph-dimensions",
          "code": "grupo-a-traditional"
        }]
      },
      "valueQuantity": {
        "value": 0.68,
        "unit": "score"
      }
    }
    // ... grupos B, C, D
  ],
  "derivedFrom": [
    { "reference": "Observation/bp-systolic" },
    { "reference": "Observation/ldl-cholesterol" }
    // ... todas las observaciones fuente
  ]
}
```

---

## 🎯 Casos de Uso

### 1️⃣ Después de Cuestionario de Determinantes de Salud

```tsx
export const AfterHealthDeterminantsQuestionnaire = () => {
  const handleScoreCalculated = (score) => {
    // Guardar score en FHIR
    saveScoreToMedplum(score);
    
    // Analytics
    trackEvent('hgraph_calculated', { score: score.composite });
    
    // Notificaciones si score < 60
    if (score.composite < 60) {
      sendAlertToProvider(score);
    }
  };

  return (
    <div>
      <h2>Cuestionario Completado ✓</h2>
      <HGraphCVDFemale
        medplum={medplum}
        patientId="patient-12345"
        onScoreCalculated={handleScoreCalculated}
      />
    </div>
  );
};
```

### 2️⃣ Dashboard Life's Essential 8

```tsx
export const LifesEssential8Dashboard = () => {
  return (
    <HGraphCVDFemale
      medplum={medplum}
      patientId="patient-12345"
      visualConfig={{ width: 700, height: 700 }}
      groupWeights={{
        grupoA: 0.30,
        grupoB: 0.20,
        grupoC: 0.15,
        grupoD: 0.35  // Enfoque en lifestyle
      }}
    />
  );
};
```

### 3️⃣ Comparación Temporal

```tsx
export const TemporalComparison = () => {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
      <div>
        <h3>Enero 2026</h3>
        <HGraphCVDFemale
          medplum={medplum}
          patientId="patient-12345"
          // Filtrar observaciones de enero
        />
      </div>
      <div>
        <h3>Abril 2026</h3>
        <HGraphCVDFemale
          medplum={medplum}
          patientId="patient-12345"
          // Filtrar observaciones de abril
        />
      </div>
    </div>
  );
};
```

---

## 🔧 API Reference

### Hooks

#### `usePatientHealthData`

```tsx
const { data, loading, error, refetch } = usePatientHealthData(medplum, patientId);
```

Extrae automáticamente todos los datos de salud desde FHIR.

**Returns:**
```typescript
{
  data: PatientHealthData | null;
  loading: boolean;
  error: Error | null;
  refetch: () => Promise<void>;
}
```

#### `usePatient`

```tsx
const { patient, loading, error } = usePatient(medplum, patientId);
```

Obtiene datos demográficos del paciente.

---

### Funciones de Cálculo

#### `calculateHGraphScore`

```tsx
import { calculateHGraphScore } from '@epa-bienestar/hgraph-cvd-female';

const score = calculateHGraphScore(healthData, groupWeights);
```

**Parameters:**
- `healthData: PatientHealthData` - Datos de salud del paciente
- `groupWeights?: GroupWeights` - Pesos personalizados (opcional)

**Returns:** `HGraphScore`

```typescript
{
  composite: number;        // hScore 0-100
  dimensions: {             // Scores por grupo 0-1
    grupoA: number;
    grupoB: number;
    grupoC: number;
    grupoD: number;
  };
  interpretation: {
    overall: 'bajo' | 'moderado' | 'alto' | 'muy-alto';
    grupoA: 'normal' | 'leve' | 'moderado' | 'alto';
    grupoB: 'normal' | 'leve' | 'moderado' | 'alto';
    grupoC: 'normal' | 'leve' | 'moderado' | 'alto';
    grupoD: 'normal' | 'leve' | 'moderado' | 'alto';
    recommendations: string[];
  };
}
```

---

## 🎨 Personalización de Colores

```tsx
import { GROUP_COLORS } from '@epa-bienestar/hgraph-cvd-female';

// Colores por defecto
GROUP_COLORS.grupoA  // '#E74C3C' - Rojo
GROUP_COLORS.grupoB  // '#9B59B6' - Púrpura
GROUP_COLORS.grupoC  // '#3498DB' - Azul
GROUP_COLORS.grupoD  // '#2ECC71' - Verde
```

---

## 📋 Rangos de Referencia

Todos los rangos están definidos en `METRIC_RANGES`:

```typescript
import { METRIC_RANGES } from '@epa-bienestar/hgraph-cvd-female';

METRIC_RANGES.bloodPressureSystolic
// {
//   healthyMin: 90,
//   healthyMax: 120,
//   absoluteMin: 70,
//   absoluteMax: 200,
//   weight: 1.5
// }
```

---

## 🔗 Códigos FHIR

### LOINC

```typescript
import { LOINC_CODES } from '@epa-bienestar/hgraph-cvd-female';

LOINC_CODES.LIFES_ESSENTIAL_8  // '90458-6'
LOINC_CODES.BP_SYSTOLIC        // '8480-6'
LOINC_CODES.LDL                // '18262-6'
LOINC_CODES.GLUCOSE            // '2339-0'
LOINC_CODES.BMI                // '39156-5'
// ... más códigos
```

### EPA Bienestar

```typescript
import { EPA_CODES } from '@epa-bienestar/hgraph-cvd-female';

EPA_CODES.HGRAPH_CVD_FEMALE    // 'hgraph-cvd-female'
EPA_CODES.GRUPO_A              // 'grupo-a-traditional'
EPA_CODES.GRUPO_B              // 'grupo-b-female-specific'
EPA_CODES.PROGRAMA_MUJER       // 'programa-mujer'
```

---

## 🧪 Testing

```bash
npm test
```

```tsx
import { render, screen } from '@testing-library/react';
import { HGraphCVDFemale } from '@epa-bienestar/hgraph-cvd-female';

test('renders HGraph component', () => {
  render(
    <HGraphCVDFemale
      medplum={mockMedplum}
      patientId="test-patient"
    />
  );
  
  expect(screen.getByText(/HGraph Cardiovascular Femenino/i)).toBeInTheDocument();
});
```

---

## 📄 Licencia

MIT © EPA Bienestar IA

---

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor:

1. Fork el repositorio
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

---

## 📞 Soporte

- **Email**: hola@epa-bienestar.com.ar
- **Website**: https://epa-bienestar.com.ar
- **GitHub Issues**: https://github.com/epa-bienestar-ia/hgraph-cvd-female/issues

---

## 🙏 Agradecimientos

- [hGraph Open Source](https://www.hgraph.org/) por la visualización base
- [Medplum](https://www.medplum.com/) por la infraestructura FHIR
- [American Heart Association](https://www.heart.org/) por Life's Essential 8
- [FHIR Community](https://www.hl7.org/fhir/) por los estándares

---

**Hecho con ❤️ por EPA Bienestar IA para mejorar la salud cardiovascular femenina en Argentina y Latinoamérica**
