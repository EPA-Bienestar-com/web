/**
 * EPA Bienestar IA - FHIR Data Hooks
 * Custom hooks para extraer datos del servidor Medplum
 */

import { useState, useEffect, useCallback } from 'react';
import { MedplumClient } from '@medplum/core';
import { Observation, Patient, Condition, MedicationStatement } from '@medplum/fhirtypes';
import { PatientHealthData, LOINC_CODES, FHIR_SYSTEMS } from './types';

// ============================================
// HOOK: DATOS DE SALUD DEL PACIENTE
// ============================================

export interface UsePatientHealthDataResult {
  data: PatientHealthData | null;
  loading: boolean;
  error: Error | null;
  refetch: () => Promise<void>;
}

export function usePatientHealthData(
  medplum: MedplumClient,
  patientId: string
): UsePatientHealthDataResult {
  const [data, setData] = useState<PatientHealthData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchData = useCallback(async () => {
    if (!patientId) {
      setError(new Error('Patient ID is required'));
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // Obtener todas las observaciones del paciente
      const observations = await medplum.searchResources('Observation', {
        subject: `Patient/${patientId}`,
        _sort: '-date',
        _count: '1000'
      });

      // Obtener condiciones (para historias de preeclampsia, diabetes gestacional, PCOS)
      const conditions = await medplum.searchResources('Condition', {
        subject: `Patient/${patientId}`,
        _count: '100'
      });

      // Obtener medicamentos (para terapia hormonal)
      const medications = await medplum.searchResources('MedicationStatement', {
        subject: `Patient/${patientId}`,
        _count: '100'
      });

      // Parsear datos
      const healthData = parseHealthData(observations, conditions, medications);
      setData(healthData);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Unknown error'));
    } finally {
      setLoading(false);
    }
  }, [medplum, patientId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    data,
    loading,
    error,
    refetch: fetchData
  };
}

// ============================================
// PARSEO DE DATOS FHIR
// ============================================

function parseHealthData(
  observations: Observation[],
  conditions: Condition[],
  medications: MedicationStatement[]
): PatientHealthData {
  const data: PatientHealthData = {};

  // ========================================
  // GRUPO A: FACTORES TRADICIONALES
  // ========================================
  
  // Presión arterial
  const bpObs = findLatestObservation(observations, LOINC_CODES.BP_SYSTOLIC);
  if (bpObs?.component) {
    const systolic = bpObs.component.find(c => 
      c.code.coding?.some(cod => cod.code === LOINC_CODES.BP_SYSTOLIC)
    );
    const diastolic = bpObs.component.find(c => 
      c.code.coding?.some(cod => cod.code === LOINC_CODES.BP_DIASTOLIC)
    );
    
    data.bloodPressureSystolic = systolic?.valueQuantity?.value;
    data.bloodPressureDiastolic = diastolic?.valueQuantity?.value;
  }

  // Colesterol
  data.cholesterolTotal = getObservationValue(observations, LOINC_CODES.CHOLESTEROL_TOTAL);
  data.ldlCholesterol = getObservationValue(observations, LOINC_CODES.LDL);
  data.hdlCholesterol = getObservationValue(observations, LOINC_CODES.HDL);
  data.triglycerides = getObservationValue(observations, LOINC_CODES.TRIGLYCERIDES);

  // Glucosa y HbA1c
  data.glucose = getObservationValue(observations, LOINC_CODES.GLUCOSE);
  data.hba1c = getObservationValue(observations, LOINC_CODES.HBA1C);

  // Antropometría
  data.bmi = getObservationValue(observations, LOINC_CODES.BMI);
  data.waistCircumference = getObservationValue(observations, '8280-0'); // LOINC para cintura

  // Tabaquismo
  const smokingObs = findLatestObservation(observations, LOINC_CODES.SMOKING_STATUS);
  if (smokingObs) {
    // Si hay observación de pack-years
    data.smokingPackYears = getObservationValue(observations, '72166-2') || 0;
  }

  // ========================================
  // GRUPO B: FACTORES FEMENINOS
  // ========================================
  
  // Edad de menarquia
  data.ageAtMenarche = getObservationValue(observations, '42798-9');

  // Paridad
  data.parity = getObservationValue(observations, '11977-6');

  // Edad primer embarazo
  data.ageAtFirstPregnancy = getObservationValue(observations, '11636-8');

  // Historia de preeclampsia
  const preeclampsiaCondition = conditions.find(c => 
    c.code?.coding?.some(cod => 
      cod.system === FHIR_SYSTEMS.SNOMED && 
      (cod.code === '15938005' || cod.code === '398254007')
    )
  );
  data.preeclampsiaHistory = !!preeclampsiaCondition;

  // Historia de diabetes gestacional
  const gestationalDMCondition = conditions.find(c => 
    c.code?.coding?.some(cod => 
      cod.system === FHIR_SYSTEMS.SNOMED && 
      cod.code === '11687002'
    )
  );
  data.gestationalDiabetesHistory = !!gestationalDMCondition;

  // Edad de menopausia
  data.ageAtMenopause = getObservationValue(observations, '49051-6');

  // Estado menopáusico
  const menopauseStatusObs = findLatestObservation(observations, '161712005');
  if (menopauseStatusObs?.valueCodeableConcept?.coding?.[0]?.code) {
    const code = menopauseStatusObs.valueCodeableConcept.coding[0].code;
    if (code === '289903006') data.menopauseStatus = 'premenopausal';
    else if (code === '289904000') data.menopauseStatus = 'perimenopausal';
    else if (code === '289905004') data.menopauseStatus = 'postmenopausal';
  }

  // Terapia hormonal (duración en años)
  const hormoneMeds = medications.filter(m => 
    m.medicationCodeableConcept?.coding?.some(cod => 
      cod.display?.toLowerCase().includes('estrogen') ||
      cod.display?.toLowerCase().includes('hormone replacement')
    )
  );
  if (hormoneMeds.length > 0) {
    // Calcular duración aproximada
    const durations = hormoneMeds.map(m => {
      if (m.effectivePeriod?.start && m.effectivePeriod?.end) {
        const start = new Date(m.effectivePeriod.start);
        const end = new Date(m.effectivePeriod.end);
        return (end.getTime() - start.getTime()) / (365.25 * 24 * 60 * 60 * 1000);
      }
      return 0;
    });
    data.hormonalTherapyDuration = durations.reduce((a, b) => a + b, 0);
  }

  // PCOS
  const pcosCondition = conditions.find(c => 
    c.code?.coding?.some(cod => 
      cod.system === FHIR_SYSTEMS.SNOMED && 
      cod.code === '237055002'
    )
  );
  data.pcos = !!pcosCondition;

  // ========================================
  // GRUPO C: BIOMARCADORES
  // ========================================
  
  data.crpUltrasensitive = getObservationValue(observations, LOINC_CODES.CRP_HS);
  data.lipoproteinA = getObservationValue(observations, LOINC_CODES.LIPOPROTEIN_A);
  data.homocysteine = getObservationValue(observations, LOINC_CODES.HOMOCYSTEINE);
  data.bnp = getObservationValue(observations, LOINC_CODES.BNP);
  data.ntProBnp = getObservationValue(observations, '33762-6'); // NT-proBNP
  data.troponinUltrasensitive = getObservationValue(observations, '89579-7');

  // ========================================
  // GRUPO D: ESTILO DE VIDA
  // ========================================
  
  // Diet score (DASH o Mediterranean)
  data.dietScore = getObservationValue(observations, '90459-4'); // LOINC para diet score

  // Actividad física (minutos/semana)
  data.physicalActivityMinutes = getObservationValue(observations, '82290-8');

  // Sueño
  data.sleepHours = getObservationValue(observations, '93832-4'); // Sleep duration
  data.sleepQuality = getObservationValue(observations, '93831-6'); // Sleep quality

  // Estrés
  data.stressLevel = getObservationValue(observations, '82667-7'); // Perceived stress

  // Adherencia a medicación
  data.medicationAdherence = getObservationValue(observations, '71799-1');

  return data;
}

// ============================================
// FUNCIONES AUXILIARES
// ============================================

function findLatestObservation(
  observations: Observation[],
  loincCode: string
): Observation | undefined {
  return observations.find(obs => 
    obs.code?.coding?.some(cod => 
      cod.system === FHIR_SYSTEMS.LOINC && 
      cod.code === loincCode
    )
  );
}

function getObservationValue(
  observations: Observation[],
  loincCode: string
): number | undefined {
  const obs = findLatestObservation(observations, loincCode);
  return obs?.valueQuantity?.value;
}

// ============================================
// HOOK: OBSERVACIONES EN TIEMPO REAL
// ============================================

export function useRealtimeObservations(
  medplum: MedplumClient,
  patientId: string,
  enabled: boolean = false
) {
  const [observations, setObservations] = useState<Observation[]>([]);

  useEffect(() => {
    if (!enabled || !patientId) return;

    // Subscribirse a cambios en observaciones (WebSocket/Polling)
    const subscription = medplum.subscribe(
      'Observation',
      { subject: `Patient/${patientId}` },
      (bundle) => {
        const newObservations = bundle.entry?.map(e => e.resource as Observation) || [];
        setObservations(prev => [...newObservations, ...prev]);
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, [medplum, patientId, enabled]);

  return observations;
}

// ============================================
// HOOK: DATOS DEL PACIENTE
// ============================================

export function usePatient(medplum: MedplumClient, patientId: string) {
  const [patient, setPatient] = useState<Patient | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!patientId) return;

    medplum
      .readResource('Patient', patientId)
      .then(setPatient)
      .catch(setError)
      .finally(() => setLoading(false));
  }, [medplum, patientId]);

  return { patient, loading, error };
}

// ============================================
// EXPORTAR TODO
// ============================================

export default {
  usePatientHealthData,
  useRealtimeObservations,
  usePatient
};
