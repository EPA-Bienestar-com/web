/**
 * EPA Bienestar IA - Data Transformer
 * Convierte PatientHealthData a formato HGraph React
 */

import {
  HGraphMetric,
  HGraphGroup,
  PatientHealthData
} from './types';
import { normalizeMetricValue, METRIC_RANGES } from './calculator';

// ============================================
// COLORES POR GRUPO
// ============================================

export const GROUP_COLORS = {
  grupoA: '#E74C3C', // Rojo - Factores tradicionales
  grupoB: '#9B59B6', // Púrpura - Factores femeninos
  grupoC: '#3498DB', // Azul - Biomarcadores
  grupoD: '#2ECC71'  // Verde - Estilo de vida
} as const;

// ============================================
// TRANSFORMADOR PRINCIPAL
// ============================================

export function transformToHGraphData(
  healthData: PatientHealthData
): HGraphGroup[] {
  return [
    createGrupoA(healthData),
    createGrupoB(healthData),
    createGrupoC(healthData),
    createGrupoD(healthData)
  ];
}

// ============================================
// GRUPO A: FACTORES TRADICIONALES
// ============================================

function createGrupoA(data: PatientHealthData): HGraphGroup {
  const children: HGraphMetric[] = [];

  // Presión Arterial Sistólica
  if (data.bloodPressureSystolic !== undefined) {
    children.push({
      id: 'bp-systolic',
      label: 'Presión Sistólica',
      value: data.bloodPressureSystolic,
      healthyMin: METRIC_RANGES.bloodPressureSystolic.healthyMin,
      healthyMax: METRIC_RANGES.bloodPressureSystolic.healthyMax,
      absoluteMin: METRIC_RANGES.bloodPressureSystolic.absoluteMin,
      absoluteMax: METRIC_RANGES.bloodPressureSystolic.absoluteMax,
      unitLabel: 'mmHg',
      fhirReference: 'Observation/bp-systolic'
    });
  }

  // Presión Arterial Diastólica
  if (data.bloodPressureDiastolic !== undefined) {
    children.push({
      id: 'bp-diastolic',
      label: 'Presión Diastólica',
      value: data.bloodPressureDiastolic,
      healthyMin: METRIC_RANGES.bloodPressureDiastolic.healthyMin,
      healthyMax: METRIC_RANGES.bloodPressureDiastolic.healthyMax,
      absoluteMin: METRIC_RANGES.bloodPressureDiastolic.absoluteMin,
      absoluteMax: METRIC_RANGES.bloodPressureDiastolic.absoluteMax,
      unitLabel: 'mmHg',
      fhirReference: 'Observation/bp-diastolic'
    });
  }

  // LDL Colesterol
  if (data.ldlCholesterol !== undefined) {
    children.push({
      id: 'ldl',
      label: 'LDL Colesterol',
      value: data.ldlCholesterol,
      healthyMin: METRIC_RANGES.ldlCholesterol.healthyMin,
      healthyMax: METRIC_RANGES.ldlCholesterol.healthyMax,
      absoluteMin: METRIC_RANGES.ldlCholesterol.absoluteMin,
      absoluteMax: METRIC_RANGES.ldlCholesterol.absoluteMax,
      unitLabel: 'mg/dL',
      fhirReference: 'Observation/ldl'
    });
  }

  // HDL Colesterol
  if (data.hdlCholesterol !== undefined) {
    children.push({
      id: 'hdl',
      label: 'HDL Colesterol',
      value: data.hdlCholesterol,
      healthyMin: METRIC_RANGES.hdlCholesterol.healthyMin,
      healthyMax: METRIC_RANGES.hdlCholesterol.healthyMax,
      absoluteMin: METRIC_RANGES.hdlCholesterol.absoluteMin,
      absoluteMax: METRIC_RANGES.hdlCholesterol.absoluteMax,
      unitLabel: 'mg/dL',
      fhirReference: 'Observation/hdl'
    });
  }

  // Triglicéridos
  if (data.triglycerides !== undefined) {
    children.push({
      id: 'triglycerides',
      label: 'Triglicéridos',
      value: data.triglycerides,
      healthyMin: METRIC_RANGES.triglycerides.healthyMin,
      healthyMax: METRIC_RANGES.triglycerides.healthyMax,
      absoluteMin: METRIC_RANGES.triglycerides.absoluteMin,
      absoluteMax: METRIC_RANGES.triglycerides.absoluteMax,
      unitLabel: 'mg/dL',
      fhirReference: 'Observation/triglycerides'
    });
  }

  // Glucosa
  if (data.glucose !== undefined) {
    children.push({
      id: 'glucose',
      label: 'Glucosa',
      value: data.glucose,
      healthyMin: METRIC_RANGES.glucose.healthyMin,
      healthyMax: METRIC_RANGES.glucose.healthyMax,
      absoluteMin: METRIC_RANGES.glucose.absoluteMin,
      absoluteMax: METRIC_RANGES.glucose.absoluteMax,
      unitLabel: 'mg/dL',
      fhirReference: 'Observation/glucose'
    });
  }

  // HbA1c
  if (data.hba1c !== undefined) {
    children.push({
      id: 'hba1c',
      label: 'Hemoglobina A1c',
      value: data.hba1c,
      healthyMin: METRIC_RANGES.hba1c.healthyMin,
      healthyMax: METRIC_RANGES.hba1c.healthyMax,
      absoluteMin: METRIC_RANGES.hba1c.absoluteMin,
      absoluteMax: METRIC_RANGES.hba1c.absoluteMax,
      unitLabel: '%',
      fhirReference: 'Observation/hba1c'
    });
  }

  // IMC
  if (data.bmi !== undefined) {
    children.push({
      id: 'bmi',
      label: 'Índice de Masa Corporal',
      value: data.bmi,
      healthyMin: METRIC_RANGES.bmi.healthyMin,
      healthyMax: METRIC_RANGES.bmi.healthyMax,
      absoluteMin: METRIC_RANGES.bmi.absoluteMin,
      absoluteMax: METRIC_RANGES.bmi.absoluteMax,
      unitLabel: 'kg/m²',
      fhirReference: 'Observation/bmi'
    });
  }

  // Circunferencia de cintura
  if (data.waistCircumference !== undefined) {
    children.push({
      id: 'waist',
      label: 'Circunferencia de Cintura',
      value: data.waistCircumference,
      healthyMin: METRIC_RANGES.waistCircumference.healthyMin,
      healthyMax: METRIC_RANGES.waistCircumference.healthyMax,
      absoluteMin: METRIC_RANGES.waistCircumference.absoluteMin,
      absoluteMax: METRIC_RANGES.waistCircumference.absoluteMax,
      unitLabel: 'cm',
      fhirReference: 'Observation/waist'
    });
  }

  // Tabaquismo
  if (data.smokingPackYears !== undefined) {
    children.push({
      id: 'smoking',
      label: 'Tabaquismo',
      value: data.smokingPackYears,
      healthyMin: METRIC_RANGES.smokingPackYears.healthyMin,
      healthyMax: METRIC_RANGES.smokingPackYears.healthyMax,
      absoluteMin: METRIC_RANGES.smokingPackYears.absoluteMin,
      absoluteMax: METRIC_RANGES.smokingPackYears.absoluteMax,
      unitLabel: 'años-paquete',
      fhirReference: 'Observation/smoking'
    });
  }

  // Calcular score promedio del grupo
  const groupScore = calculateGroupAverage(children);

  return {
    id: 'grupo-a',
    label: 'Factores Tradicionales',
    value: groupScore,
    healthyMin: 0.6,
    healthyMax: 0.9,
    absoluteMin: 0,
    absoluteMax: 1,
    unitLabel: 'score',
    color: GROUP_COLORS.grupoA,
    children
  };
}

// ============================================
// GRUPO B: FACTORES FEMENINOS
// ============================================

function createGrupoB(data: PatientHealthData): HGraphGroup {
  const children: HGraphMetric[] = [];

  // Edad de menarquia
  if (data.ageAtMenarche !== undefined) {
    children.push({
      id: 'age-menarche',
      label: 'Edad de Menarquia',
      value: data.ageAtMenarche,
      healthyMin: METRIC_RANGES.ageAtMenarche.healthyMin,
      healthyMax: METRIC_RANGES.ageAtMenarche.healthyMax,
      absoluteMin: METRIC_RANGES.ageAtMenarche.absoluteMin,
      absoluteMax: METRIC_RANGES.ageAtMenarche.absoluteMax,
      unitLabel: 'años',
      fhirReference: 'Observation/age-menarche'
    });
  }

  // Paridad
  if (data.parity !== undefined) {
    children.push({
      id: 'parity',
      label: 'Número de Embarazos',
      value: data.parity,
      healthyMin: METRIC_RANGES.parity.healthyMin,
      healthyMax: METRIC_RANGES.parity.healthyMax,
      absoluteMin: METRIC_RANGES.parity.absoluteMin,
      absoluteMax: METRIC_RANGES.parity.absoluteMax,
      unitLabel: 'embarazos',
      fhirReference: 'Observation/parity'
    });
  }

  // Edad primer embarazo
  if (data.ageAtFirstPregnancy !== undefined) {
    children.push({
      id: 'age-first-pregnancy',
      label: 'Edad Primer Embarazo',
      value: data.ageAtFirstPregnancy,
      healthyMin: METRIC_RANGES.ageAtFirstPregnancy.healthyMin,
      healthyMax: METRIC_RANGES.ageAtFirstPregnancy.healthyMax,
      absoluteMin: METRIC_RANGES.ageAtFirstPregnancy.absoluteMin,
      absoluteMax: METRIC_RANGES.ageAtFirstPregnancy.absoluteMax,
      unitLabel: 'años',
      fhirReference: 'Observation/age-first-pregnancy'
    });
  }

  // Historia de preeclampsia
  if (data.preeclampsiaHistory !== undefined) {
    children.push({
      id: 'preeclampsia',
      label: 'Historia de Preeclampsia',
      value: data.preeclampsiaHistory ? 1 : 0,
      healthyMin: METRIC_RANGES.preeclampsiaHistory.healthyMin,
      healthyMax: METRIC_RANGES.preeclampsiaHistory.healthyMax,
      absoluteMin: METRIC_RANGES.preeclampsiaHistory.absoluteMin,
      absoluteMax: METRIC_RANGES.preeclampsiaHistory.absoluteMax,
      unitLabel: data.preeclampsiaHistory ? 'Sí' : 'No',
      fhirReference: 'Condition/preeclampsia'
    });
  }

  // Historia de diabetes gestacional
  if (data.gestationalDiabetesHistory !== undefined) {
    children.push({
      id: 'gestational-diabetes',
      label: 'Diabetes Gestacional',
      value: data.gestationalDiabetesHistory ? 1 : 0,
      healthyMin: METRIC_RANGES.gestationalDiabetesHistory.healthyMin,
      healthyMax: METRIC_RANGES.gestationalDiabetesHistory.healthyMax,
      absoluteMin: METRIC_RANGES.gestationalDiabetesHistory.absoluteMin,
      absoluteMax: METRIC_RANGES.gestationalDiabetesHistory.absoluteMax,
      unitLabel: data.gestationalDiabetesHistory ? 'Sí' : 'No',
      fhirReference: 'Condition/gestational-diabetes'
    });
  }

  // Edad de menopausia
  if (data.ageAtMenopause !== undefined) {
    children.push({
      id: 'age-menopause',
      label: 'Edad de Menopausia',
      value: data.ageAtMenopause,
      healthyMin: METRIC_RANGES.ageAtMenopause.healthyMin,
      healthyMax: METRIC_RANGES.ageAtMenopause.healthyMax,
      absoluteMin: METRIC_RANGES.ageAtMenopause.absoluteMin,
      absoluteMax: METRIC_RANGES.ageAtMenopause.absoluteMax,
      unitLabel: 'años',
      fhirReference: 'Observation/age-menopause'
    });
  }

  // Terapia hormonal
  if (data.hormonalTherapyDuration !== undefined) {
    children.push({
      id: 'hormone-therapy',
      label: 'Terapia Hormonal',
      value: data.hormonalTherapyDuration,
      healthyMin: METRIC_RANGES.hormonalTherapyDuration.healthyMin,
      healthyMax: METRIC_RANGES.hormonalTherapyDuration.healthyMax,
      absoluteMin: METRIC_RANGES.hormonalTherapyDuration.absoluteMin,
      absoluteMax: METRIC_RANGES.hormonalTherapyDuration.absoluteMax,
      unitLabel: 'años',
      fhirReference: 'MedicationStatement/hormone-therapy'
    });
  }

  // PCOS
  if (data.pcos !== undefined) {
    children.push({
      id: 'pcos',
      label: 'Síndrome de Ovario Poliquístico',
      value: data.pcos ? 1 : 0,
      healthyMin: METRIC_RANGES.pcos.healthyMin,
      healthyMax: METRIC_RANGES.pcos.healthyMax,
      absoluteMin: METRIC_RANGES.pcos.absoluteMin,
      absoluteMax: METRIC_RANGES.pcos.absoluteMax,
      unitLabel: data.pcos ? 'Sí' : 'No',
      fhirReference: 'Condition/pcos'
    });
  }

  const groupScore = calculateGroupAverage(children);

  return {
    id: 'grupo-b',
    label: 'Factores Femeninos',
    value: groupScore,
    healthyMin: 0.7,
    healthyMax: 1.0,
    absoluteMin: 0,
    absoluteMax: 1,
    unitLabel: 'score',
    color: GROUP_COLORS.grupoB,
    children
  };
}

// ============================================
// GRUPO C: BIOMARCADORES
// ============================================

function createGrupoC(data: PatientHealthData): HGraphGroup {
  const children: HGraphMetric[] = [];

  // PCR ultrasensible
  if (data.crpUltrasensitive !== undefined) {
    children.push({
      id: 'crp-hs',
      label: 'PCR Ultrasensible',
      value: data.crpUltrasensitive,
      healthyMin: METRIC_RANGES.crpUltrasensitive.healthyMin,
      healthyMax: METRIC_RANGES.crpUltrasensitive.healthyMax,
      absoluteMin: METRIC_RANGES.crpUltrasensitive.absoluteMin,
      absoluteMax: METRIC_RANGES.crpUltrasensitive.absoluteMax,
      unitLabel: 'mg/L',
      fhirReference: 'Observation/crp-hs'
    });
  }

  // Lipoproteína(a)
  if (data.lipoproteinA !== undefined) {
    children.push({
      id: 'lp-a',
      label: 'Lipoproteína(a)',
      value: data.lipoproteinA,
      healthyMin: METRIC_RANGES.lipoproteinA.healthyMin,
      healthyMax: METRIC_RANGES.lipoproteinA.healthyMax,
      absoluteMin: METRIC_RANGES.lipoproteinA.absoluteMin,
      absoluteMax: METRIC_RANGES.lipoproteinA.absoluteMax,
      unitLabel: 'mg/dL',
      fhirReference: 'Observation/lp-a'
    });
  }

  // Homocisteína
  if (data.homocysteine !== undefined) {
    children.push({
      id: 'homocysteine',
      label: 'Homocisteína',
      value: data.homocysteine,
      healthyMin: METRIC_RANGES.homocysteine.healthyMin,
      healthyMax: METRIC_RANGES.homocysteine.healthyMax,
      absoluteMin: METRIC_RANGES.homocysteine.absoluteMin,
      absoluteMax: METRIC_RANGES.homocysteine.absoluteMax,
      unitLabel: 'µmol/L',
      fhirReference: 'Observation/homocysteine'
    });
  }

  // BNP
  if (data.bnp !== undefined) {
    children.push({
      id: 'bnp',
      label: 'Péptido Natriurético (BNP)',
      value: data.bnp,
      healthyMin: METRIC_RANGES.bnp.healthyMin,
      healthyMax: METRIC_RANGES.bnp.healthyMax,
      absoluteMin: METRIC_RANGES.bnp.absoluteMin,
      absoluteMax: METRIC_RANGES.bnp.absoluteMax,
      unitLabel: 'pg/mL',
      fhirReference: 'Observation/bnp'
    });
  }

  // NT-proBNP
  if (data.ntProBnp !== undefined) {
    children.push({
      id: 'nt-probnp',
      label: 'NT-proBNP',
      value: data.ntProBnp,
      healthyMin: METRIC_RANGES.ntProBnp.healthyMin,
      healthyMax: METRIC_RANGES.ntProBnp.healthyMax,
      absoluteMin: METRIC_RANGES.ntProBnp.absoluteMin,
      absoluteMax: METRIC_RANGES.ntProBnp.absoluteMax,
      unitLabel: 'pg/mL',
      fhirReference: 'Observation/nt-probnp'
    });
  }

  // Troponina ultrasensible
  if (data.troponinUltrasensitive !== undefined) {
    children.push({
      id: 'troponin-hs',
      label: 'Troponina Ultrasensible',
      value: data.troponinUltrasensitive,
      healthyMin: METRIC_RANGES.troponinUltrasensitive.healthyMin,
      healthyMax: METRIC_RANGES.troponinUltrasensitive.healthyMax,
      absoluteMin: METRIC_RANGES.troponinUltrasensitive.absoluteMin,
      absoluteMax: METRIC_RANGES.troponinUltrasensitive.absoluteMax,
      unitLabel: 'ng/L',
      fhirReference: 'Observation/troponin-hs'
    });
  }

  const groupScore = calculateGroupAverage(children);

  return {
    id: 'grupo-c',
    label: 'Biomarcadores',
    value: groupScore,
    healthyMin: 0.6,
    healthyMax: 0.9,
    absoluteMin: 0,
    absoluteMax: 1,
    unitLabel: 'score',
    color: GROUP_COLORS.grupoC,
    children
  };
}

// ============================================
// GRUPO D: ESTILO DE VIDA
// ============================================

function createGrupoD(data: PatientHealthData): HGraphGroup {
  const children: HGraphMetric[] = [];

  // Diet score
  if (data.dietScore !== undefined) {
    children.push({
      id: 'diet',
      label: 'Calidad de la Dieta',
      value: data.dietScore,
      healthyMin: METRIC_RANGES.dietScore.healthyMin,
      healthyMax: METRIC_RANGES.dietScore.healthyMax,
      absoluteMin: METRIC_RANGES.dietScore.absoluteMin,
      absoluteMax: METRIC_RANGES.dietScore.absoluteMax,
      unitLabel: 'puntos',
      fhirReference: 'Observation/diet-score'
    });
  }

  // Actividad física
  if (data.physicalActivityMinutes !== undefined) {
    children.push({
      id: 'physical-activity',
      label: 'Actividad Física',
      value: data.physicalActivityMinutes,
      healthyMin: METRIC_RANGES.physicalActivityMinutes.healthyMin,
      healthyMax: METRIC_RANGES.physicalActivityMinutes.healthyMax,
      absoluteMin: METRIC_RANGES.physicalActivityMinutes.absoluteMin,
      absoluteMax: METRIC_RANGES.physicalActivityMinutes.absoluteMax,
      unitLabel: 'min/semana',
      fhirReference: 'Observation/physical-activity'
    });
  }

  // Horas de sueño
  if (data.sleepHours !== undefined) {
    children.push({
      id: 'sleep-hours',
      label: 'Duración del Sueño',
      value: data.sleepHours,
      healthyMin: METRIC_RANGES.sleepHours.healthyMin,
      healthyMax: METRIC_RANGES.sleepHours.healthyMax,
      absoluteMin: METRIC_RANGES.sleepHours.absoluteMin,
      absoluteMax: METRIC_RANGES.sleepHours.absoluteMax,
      unitLabel: 'horas/noche',
      fhirReference: 'Observation/sleep-hours'
    });
  }

  // Calidad del sueño
  if (data.sleepQuality !== undefined) {
    children.push({
      id: 'sleep-quality',
      label: 'Calidad del Sueño',
      value: data.sleepQuality,
      healthyMin: METRIC_RANGES.sleepQuality.healthyMin,
      healthyMax: METRIC_RANGES.sleepQuality.healthyMax,
      absoluteMin: METRIC_RANGES.sleepQuality.absoluteMin,
      absoluteMax: METRIC_RANGES.sleepQuality.absoluteMax,
      unitLabel: 'escala 0-10',
      fhirReference: 'Observation/sleep-quality'
    });
  }

  // Nivel de estrés
  if (data.stressLevel !== undefined) {
    children.push({
      id: 'stress',
      label: 'Nivel de Estrés',
      value: data.stressLevel,
      healthyMin: METRIC_RANGES.stressLevel.healthyMin,
      healthyMax: METRIC_RANGES.stressLevel.healthyMax,
      absoluteMin: METRIC_RANGES.stressLevel.absoluteMin,
      absoluteMax: METRIC_RANGES.stressLevel.absoluteMax,
      unitLabel: 'escala 0-10',
      fhirReference: 'Observation/stress'
    });
  }

  // Adherencia a medicación
  if (data.medicationAdherence !== undefined) {
    children.push({
      id: 'medication-adherence',
      label: 'Adherencia Medicamentosa',
      value: data.medicationAdherence,
      healthyMin: METRIC_RANGES.medicationAdherence.healthyMin,
      healthyMax: METRIC_RANGES.medicationAdherence.healthyMax,
      absoluteMin: METRIC_RANGES.medicationAdherence.absoluteMin,
      absoluteMax: METRIC_RANGES.medicationAdherence.absoluteMax,
      unitLabel: '%',
      fhirReference: 'Observation/medication-adherence'
    });
  }

  const groupScore = calculateGroupAverage(children);

  return {
    id: 'grupo-d',
    label: 'Estilo de Vida',
    value: groupScore,
    healthyMin: 0.7,
    healthyMax: 1.0,
    absoluteMin: 0,
    absoluteMax: 1,
    unitLabel: 'score',
    color: GROUP_COLORS.grupoD,
    children
  };
}

// ============================================
// UTILIDAD: CALCULAR PROMEDIO DEL GRUPO
// ============================================

function calculateGroupAverage(children: HGraphMetric[]): number {
  if (children.length === 0) return 0.5;

  const sum = children.reduce((acc, child) => {
    const normalized = normalizeMetricValue(
      child.value,
      {
        healthyMin: child.healthyMin,
        healthyMax: child.healthyMax,
        absoluteMin: child.absoluteMin,
        absoluteMax: child.absoluteMax
      }
    );
    return acc + normalized;
  }, 0);

  return sum / children.length;
}

// ============================================
// EXPORTAR
// ============================================

export default {
  transformToHGraphData,
  GROUP_COLORS
};
