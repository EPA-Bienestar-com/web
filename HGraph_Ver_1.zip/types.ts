/**
 * EPA Bienestar IA - HGraph Cardiovascular Femenino
 * Tipos TypeScript para FHIR R4 y HGraph Integration
 */

import { Observation, Patient, Reference } from '@medplum/fhirtypes';

// ============================================
// TIPOS FHIR R4
// ============================================

export interface HGraphObservation extends Observation {
  code: {
    coding: Array<{
      system: string;
      code: string;
      display: string;
    }>;
    text: string;
  };
  valueQuantity?: {
    value: number;
    unit: string;
    system: string;
    code: string;
  };
  component?: Array<{
    code: {
      coding: Array<{
        system: string;
        code: string;
        display: string;
      }>;
    };
    valueQuantity: {
      value: number;
      unit: string;
    };
    interpretation?: Array<{
      coding: Array<{
        system: string;
        code: string;
        display?: string;
      }>;
      text?: string;
    }>;
  }>;
  derivedFrom?: Reference[];
}

// ============================================
// TIPOS HGRAPH METRIC
// ============================================

export interface HGraphMetric {
  id: string;
  label: string;
  value: number;
  healthyMin: number;
  healthyMax: number;
  absoluteMin: number;
  absoluteMax: number;
  unitLabel: string;
  color?: string;
  fhirReference?: string;
  children?: HGraphMetric[];
}

export interface HGraphGroup {
  id: string;
  label: string;
  value: number; // Normalized score 0-1
  healthyMin: number;
  healthyMax: number;
  absoluteMin: number;
  absoluteMax: number;
  unitLabel: string;
  color: string;
  children: HGraphMetric[];
}

// ============================================
// SCORES Y CÁLCULOS
// ============================================

export interface GroupScore {
  grupoA: number; // 0-1
  grupoB: number;
  grupoC: number;
  grupoD: number;
}

export interface HGraphScore {
  composite: number; // hScore principal 0-100
  dimensions: GroupScore; // Scores normalizados por dimensión
  raw: GroupScore; // Scores sin normalizar
  interpretation: RiskInterpretation;
}

export interface RiskInterpretation {
  overall: 'bajo' | 'moderado' | 'alto' | 'muy-alto';
  grupoA: 'normal' | 'leve' | 'moderado' | 'alto';
  grupoB: 'normal' | 'leve' | 'moderado' | 'alto';
  grupoC: 'normal' | 'leve' | 'moderado' | 'alto';
  grupoD: 'normal' | 'leve' | 'moderado' | 'alto';
  recommendations: string[];
}

// ============================================
// RANGOS Y PONDERACIONES
// ============================================

export interface MetricRange {
  healthyMin: number;
  healthyMax: number;
  absoluteMin: number;
  absoluteMax: number;
  weight?: number; // Peso relativo en el grupo
}

export interface GroupWeights {
  grupoA: number;
  grupoB: number;
  grupoC: number;
  grupoD: number;
}

export const DEFAULT_GROUP_WEIGHTS: GroupWeights = {
  grupoA: 0.35, // Factores tradicionales: mayor peso
  grupoB: 0.25, // Factores femeninos específicos
  grupoC: 0.20, // Biomarcadores
  grupoD: 0.20  // Estilo de vida
};

// ============================================
// CONFIGURACIÓN VISUAL
// ============================================

export interface HGraphVisualConfig {
  width?: number;
  height?: number;
  margin?: {
    top: number;
    right: number;
    bottom: number;
    left: number;
  };
  thresholdMin?: number; // 0-1
  thresholdMax?: number; // 0-1
  donutHoleFactor?: number; // 0-1
  color?: string;
  healthyRangeFillColor?: string;
  fontSize?: number;
  fontColor?: string;
  showAxisLabel?: boolean;
  axisLabelWrapWidth?: number;
  axisLabelOffset?: number;
  areaOpacity?: number;
  pointRadius?: number;
  pointLabelWrapWidth?: number | null;
  pointLabelOffset?: number;
  hitboxRadius?: number;
  showScore?: boolean;
  scoreFontSize?: number;
  scoreFontColor?: string;
  zoomFactor?: number;
  zoomTransitionTime?: number;
  zoomOnPointClick?: boolean;
}

export const DEFAULT_VISUAL_CONFIG: HGraphVisualConfig = {
  width: 600,
  height: 600,
  margin: { top: 70, right: 100, bottom: 70, left: 100 },
  thresholdMin: 0.25,
  thresholdMax: 0.75,
  donutHoleFactor: 0.4,
  color: '#616363',
  healthyRangeFillColor: '#98bd8e',
  fontSize: 16,
  fontColor: '#000',
  showAxisLabel: true,
  axisLabelWrapWidth: 80,
  axisLabelOffset: 12,
  areaOpacity: 0.25,
  pointRadius: 10,
  pointLabelWrapWidth: null,
  pointLabelOffset: 8,
  showScore: true,
  scoreFontSize: 120,
  scoreFontColor: '#000',
  zoomFactor: 2.25,
  zoomTransitionTime: 750,
  zoomOnPointClick: true
};

// ============================================
// PROPS DEL COMPONENTE
// ============================================

export interface HGraphCVDFemaleProps {
  patientId: string;
  observations?: Observation[]; // Opcional: pasar observaciones directamente
  onScoreCalculated?: (score: HGraphScore) => void;
  onMetricClick?: (metric: HGraphMetric, event: React.MouseEvent) => void;
  visualConfig?: Partial<HGraphVisualConfig>;
  groupWeights?: Partial<GroupWeights>;
  showLegend?: boolean;
  showRecommendations?: boolean;
  enableRealTimeUpdates?: boolean; // WebSocket updates
  comparisonMode?: 'single' | 'temporal' | 'population'; // Modo de comparación
}

// ============================================
// DATOS DE ENTRADA (desde FHIR)
// ============================================

export interface PatientHealthData {
  // Grupo A: Tradicionales
  bloodPressureSystolic?: number;
  bloodPressureDiastolic?: number;
  cholesterolTotal?: number;
  ldlCholesterol?: number;
  hdlCholesterol?: number;
  triglycerides?: number;
  glucose?: number;
  hba1c?: number;
  bmi?: number;
  waistCircumference?: number;
  smokingPackYears?: number;
  
  // Grupo B: Femeninos
  ageAtMenarche?: number;
  parity?: number;
  ageAtFirstPregnancy?: number;
  preeclampsiaHistory?: boolean;
  gestationalDiabetesHistory?: boolean;
  ageAtMenopause?: number;
  menopauseStatus?: 'premenopausal' | 'perimenopausal' | 'postmenopausal';
  hormonalTherapyDuration?: number;
  pcos?: boolean;
  
  // Grupo C: Biomarcadores
  crpUltrasensitive?: number;
  lipoproteinA?: number;
  homocysteine?: number;
  bnp?: number;
  ntProBnp?: number;
  troponinUltrasensitive?: number;
  
  // Grupo D: Estilo de Vida (Life's Essential 8)
  dietScore?: number; // DASH o Mediterranean
  physicalActivityMinutes?: number; // Por semana
  sleepHours?: number;
  sleepQuality?: number; // 0-10
  stressLevel?: number; // 0-10
  medicationAdherence?: number; // 0-100%
}

// ============================================
// CONSTANTES DE CODIFICACIÓN FHIR
// ============================================

export const FHIR_SYSTEMS = {
  LOINC: 'http://loinc.org',
  SNOMED: 'http://snomed.info/sct',
  EPA_BIENESTAR: 'http://epa-bienestar.com.ar/fhir/CodeSystem',
  UCUM: 'http://unitsofmeasure.org'
} as const;

export const EPA_CODES = {
  HGRAPH_CVD_FEMALE: 'hgraph-cvd-female',
  GRUPO_A: 'grupo-a-traditional',
  GRUPO_B: 'grupo-b-female-specific',
  GRUPO_C: 'grupo-c-biomarkers',
  GRUPO_D: 'grupo-d-lifestyle',
  PROGRAMA_MUJER: 'programa-mujer'
} as const;

export const LOINC_CODES = {
  LIFES_ESSENTIAL_8: '90458-6',
  BP_SYSTOLIC: '8480-6',
  BP_DIASTOLIC: '8462-4',
  CHOLESTEROL_TOTAL: '2093-3',
  LDL: '18262-6',
  HDL: '2085-9',
  TRIGLYCERIDES: '2571-8',
  GLUCOSE: '2339-0',
  HBA1C: '4548-4',
  BMI: '39156-5',
  SMOKING_STATUS: '72166-2',
  CRP_HS: '30522-7',
  LIPOPROTEIN_A: '10839-9',
  HOMOCYSTEINE: '13965-9',
  BNP: '30934-4'
} as const;
