// ============================================================================
// CONFIGURACIÓN DE CONTENIDOS POR GRUPO
// ============================================================================

/**
 * Catálogo completo de contenidos educativos
 * Organizado por grupos de vida y categorías del Plan Bienestar 100 Días
 */

export const CONTENT_CATALOG = {
  // ========== GRUPO A: Mujeres Jóvenes 18-30 años ==========
  groupA: {
    habits: [
      {
        id: 'a-hab-001',
        title: 'Alimentación Saludable en la Universidad',
        description: 'Recetas rápidas, nutritivas y económicas para estudiantes',
        url: 'https://plataforma.epa-bienestar.com.ar/alimentacion-universitaria',
        duration: 15,
        imageUrl: 'https://plataforma.epa-bienestar.com.ar/images/alimentacion-uni.jpg',
        priority: 1,
        tags: ['nutrición', 'estudiantes', 'recetas'],
        relatedPlanDefinition: 'PlanDefinition/plan-bienestar-100-habitos'
      },
      {
        id: 'a-hab-002',
        title: 'Ejercicio para Profesionales Ocupadas',
        description: 'Rutinas de 15 minutos para hacer en casa o la oficina',
        url: 'https://plataforma.epa-bienestar.com.ar/ejercicio-profesionales',
        duration: 20,
        priority: 2,
        tags: ['ejercicio', 'tiempo-limitado', 'oficina']
      },
      {
        id: 'a-hab-003',
        title: 'Sueño de Calidad: Fundamentos',
        description: 'Cómo optimizar tus horas de descanso para mejor rendimiento',
        url: 'https://plataforma.epa-bienestar.com.ar/sueno-calidad',
        duration: 12,
        priority: 3,
        tags: ['sueño', 'descanso', 'productividad']
      }
    ],
    emotions: [
      {
        id: 'a-emo-001',
        title: 'Gestión del Estrés Académico',
        description: 'Técnicas de mindfulness y organización para épocas de exámenes',
        url: 'https://plataforma.epa-bienestar.com.ar/estres-academico',
        duration: 18,
        priority: 1,
        tags: ['estrés', 'mindfulness', 'estudiantes']
      },
      {
        id: 'a-emo-002',
        title: 'Balance Trabajo-Vida Personal',
        description: 'Estrategias para mantener equilibrio en tu primer empleo',
        url: 'https://plataforma.epa-bienestar.com.ar/balance-trabajo-vida',
        duration: 16,
        priority: 2,
        tags: ['balance', 'trabajo', 'bienestar']
      }
    ],
    heart: [
      {
        id: 'a-hea-001',
        title: 'Presión Arterial: ¿Qué es Normal?',
        description: 'Entendiendo los valores de presión arterial en mujeres jóvenes',
        url: 'https://plataforma.epa-bienestar.com.ar/presion-arterial-jovenes',
        duration: 10,
        priority: 1,
        tags: ['presión-arterial', 'prevención', 'jóvenes']
      },
      {
        id: 'a-hea-002',
        title: 'Anticonceptivos y Salud Cardiovascular',
        description: 'Lo que debes saber sobre anticonceptivos hormonales y tu corazón',
        url: 'https://plataforma.epa-bienestar.com.ar/anticonceptivos-corazon',
        duration: 14,
        priority: 2,
        tags: ['anticonceptivos', 'hormonas', 'prevención']
      }
    ],
    brain: [
      {
        id: 'a-bra-001',
        title: 'Neuroplasticidad y Aprendizaje',
        description: 'Cómo aprovechar la neuroplasticidad en tu desarrollo profesional',
        url: 'https://plataforma.epa-bienestar.com.ar/neuroplasticidad',
        duration: 20,
        priority: 1,
        tags: ['cerebro', 'aprendizaje', 'desarrollo']
      }
    ]
  },

  // ========== GRUPO B: Mujeres 28-40 años (Planificando Maternidad) ==========
  groupB: {
    habits: [
      {
        id: 'b-hab-001',
        title: 'Nutrición Pre-Concepcional',
        description: 'Alimentación óptima para preparar tu cuerpo para el embarazo',
        url: 'https://plataforma.epa-bienestar.com.ar/nutricion-preconcepcional',
        duration: 25,
        priority: 1,
        tags: ['nutrición', 'embarazo', 'pre-concepción']
      },
      {
        id: 'b-hab-002',
        title: 'Ejercicio Seguro Pre-Embarazo',
        description: 'Rutinas de fortalecimiento para un embarazo más saludable',
        url: 'https://plataforma.epa-bienestar.com.ar/ejercicio-pre-embarazo',
        duration: 22,
        priority: 2,
        tags: ['ejercicio', 'embarazo', 'fortalecimiento']
      },
      {
        id: 'b-hab-003',
        title: 'Control de Peso Saludable',
        description: 'Alcanzar peso ideal antes del embarazo sin dietas extremas',
        url: 'https://plataforma.epa-bienestar.com.ar/peso-saludable',
        duration: 18,
        priority: 3,
        tags: ['peso', 'salud', 'embarazo']
      }
    ],
    emotions: [
      {
        id: 'b-emo-001',
        title: 'Ansiedad y Planificación Familiar',
        description: 'Manejar el estrés de planificar el momento ideal para ser madre',
        url: 'https://plataforma.epa-bienestar.com.ar/ansiedad-maternidad',
        duration: 20,
        priority: 1,
        tags: ['ansiedad', 'maternidad', 'planificación']
      },
      {
        id: 'b-emo-002',
        title: 'Relación de Pareja y Parentalidad',
        description: 'Fortalecer la relación antes de la llegada del bebé',
        url: 'https://plataforma.epa-bienestar.com.ar/pareja-parentalidad',
        duration: 24,
        priority: 2,
        tags: ['pareja', 'relación', 'maternidad']
      }
    ],
    heart: [
      {
        id: 'b-hea-001',
        title: 'Prevención de Preeclampsia',
        description: 'Factores de riesgo y estrategias de prevención',
        url: 'https://plataforma.epa-bienestar.com.ar/prevencion-preeclampsia',
        duration: 28,
        priority: 1,
        tags: ['preeclampsia', 'embarazo', 'prevención'],
        criticalContent: true
      },
      {
        id: 'b-hea-002',
        title: 'Diabetes Gestacional: Prevención',
        description: 'Control metabólico antes y durante el embarazo',
        url: 'https://plataforma.epa-bienestar.com.ar/diabetes-gestacional-prev',
        duration: 26,
        priority: 2,
        tags: ['diabetes', 'embarazo', 'metabolismo'],
        criticalContent: true
      },
      {
        id: 'b-hea-003',
        title: 'Salud Cardiovascular en el Embarazo',
        description: 'Cambios cardiovasculares normales y señales de alerta',
        url: 'https://plataforma.epa-bienestar.com.ar/corazon-embarazo',
        duration: 30,
        priority: 3,
        tags: ['corazón', 'embarazo', 'prevención']
      }
    ],
    brain: [
      {
        id: 'b-bra-001',
        title: 'Preparación Mental para la Maternidad',
        description: 'Cambios cognitivos y emocionales en el embarazo y posparto',
        url: 'https://plataforma.epa-bienestar.com.ar/mente-maternidad',
        duration: 22,
        priority: 1,
        tags: ['cerebro', 'maternidad', 'cognición']
      }
    ]
  },

  // ========== GRUPO C: Mujeres 45-65 años (Menopausia) ==========
  groupC: {
    habits: [
      {
        id: 'c-hab-001',
        title: 'Ejercicio de Resistencia en Menopausia',
        description: 'Fortalecimiento óseo y muscular para prevenir osteoporosis',
        url: 'https://plataforma.epa-bienestar.com.ar/resistencia-menopausia',
        duration: 30,
        priority: 1,
        tags: ['ejercicio', 'menopausia', 'osteoporosis']
      },
      {
        id: 'c-hab-002',
        title: 'Alimentación Anti-Inflamatoria',
        description: 'Nutrición para reducir síntomas de menopausia',
        url: 'https://plataforma.epa-bienestar.com.ar/alimentacion-menopausia',
        duration: 26,
        priority: 2,
        tags: ['nutrición', 'menopausia', 'anti-inflamatorio']
      },
      {
        id: 'c-hab-003',
        title: 'Sueño y Menopausia',
        description: 'Estrategias para mejorar el descanso durante la transición',
        url: 'https://plataforma.epa-bienestar.com.ar/sueno-menopausia',
        duration: 18,
        priority: 3,
        tags: ['sueño', 'menopausia', 'descanso']
      }
    ],
    emotions: [
      {
        id: 'c-emo-001',
        title: 'Salud Mental en la Menopausia',
        description: 'Cambios emocionales y estrategias de afrontamiento',
        url: 'https://plataforma.epa-bienestar.com.ar/salud-mental-menopausia',
        duration: 24,
        priority: 1,
        tags: ['salud-mental', 'menopausia', 'emociones']
      },
      {
        id: 'c-emo-002',
        title: 'Reinvención Profesional',
        description: 'Nuevas oportunidades y desafíos en la segunda mitad de la vida',
        url: 'https://plataforma.epa-bienestar.com.ar/reinvencion-profesional',
        duration: 28,
        priority: 2,
        tags: ['carrera', 'desarrollo', 'menopausia']
      }
    ],
    heart: [
      {
        id: 'c-hea-001',
        title: 'Síntomas Atípicos de Infarto en Mujeres',
        description: 'Reconoce las señales de alerta específicas en mujeres',
        url: 'https://plataforma.epa-bienestar.com.ar/sintomas-atipicos-infarto',
        duration: 35,
        priority: 1,
        tags: ['infarto', 'síntomas', 'emergencia'],
        criticalContent: true,
        requiredViewing: true
      },
      {
        id: 'c-hea-002',
        title: 'Menopausia y Riesgo Cardiovascular',
        description: 'Cómo los cambios hormonales afectan tu corazón',
        url: 'https://plataforma.epa-bienestar.com.ar/menopausia-corazon',
        duration: 32,
        priority: 2,
        tags: ['menopausia', 'corazón', 'hormonas'],
        criticalContent: true
      },
      {
        id: 'c-hea-003',
        title: 'Control de Presión Arterial sin Medicamentos',
        description: 'Intervenciones lifestyle para manejar la hipertensión',
        url: 'https://plataforma.epa-bienestar.com.ar/hta-sin-medicamentos',
        duration: 28,
        priority: 3,
        tags: ['hipertensión', 'lifestyle', 'prevención']
      },
      {
        id: 'c-hea-004',
        title: 'Colesterol y Menopausia',
        description: 'Manejo natural del perfil lipídico',
        url: 'https://plataforma.epa-bienestar.com.ar/colesterol-menopausia',
        duration: 24,
        priority: 4,
        tags: ['colesterol', 'menopausia', 'lípidos']
      }
    ],
    brain: [
      {
        id: 'c-bra-001',
        title: 'Prevención de Deterioro Cognitivo',
        description: 'Estrategias neuroprotectoras en la menopausia',
        url: 'https://plataforma.epa-bienestar.com.ar/cognicion-menopausia',
        duration: 26,
        priority: 1,
        tags: ['cognición', 'prevención', 'menopausia']
      }
    ]
  },

  // ========== GRUPO D: Mujeres 65+ años (Abuelas/Emprendedoras) ==========
  groupD: {
    habits: [
      {
        id: 'd-hab-001',
        title: 'Vida Activa para Abuelas Emprendedoras',
        description: 'Mantener vitalidad y energía después de los 65',
        url: 'https://plataforma.epa-bienestar.com.ar/vida-activa-65plus',
        duration: 28,
        priority: 1,
        tags: ['actividad', 'vitalidad', '65+']
      },
      {
        id: 'd-hab-002',
        title: 'Nutrición para Longevidad',
        description: 'Alimentación para envejecimiento saludable',
        url: 'https://plataforma.epa-bienestar.com.ar/nutricion-longevidad',
        duration: 24,
        priority: 2,
        tags: ['nutrición', 'longevidad', 'envejecimiento']
      },
      {
        id: 'd-hab-003',
        title: 'Prevención de Caídas',
        description: 'Ejercicios de equilibrio y fortalecimiento',
        url: 'https://plataforma.epa-bienestar.com.ar/prevencion-caidas',
        duration: 22,
        priority: 3,
        tags: ['caídas', 'equilibrio', 'prevención']
      }
    ],
    emotions: [
      {
        id: 'd-emo-001',
        title: 'Bienestar Emocional en la Tercera Edad',
        description: 'Cultivar alegría y propósito después de los 65',
        url: 'https://plataforma.epa-bienestar.com.ar/bienestar-tercera-edad',
        duration: 20,
        priority: 1,
        tags: ['bienestar', 'propósito', '65+']
      },
      {
        id: 'd-emo-002',
        title: 'Emprendimiento en la Madurez',
        description: 'Historias inspiradoras y guía práctica',
        url: 'https://plataforma.epa-bienestar.com.ar/emprendimiento-madurez',
        duration: 26,
        priority: 2,
        tags: ['emprendimiento', 'inspiración', 'madurez']
      }
    ],
    heart: [
      {
        id: 'd-hea-001',
        title: 'Manejo de Enfermedades Cardiovasculares',
        description: 'Vivir bien con condiciones cardíacas crónicas',
        url: 'https://plataforma.epa-bienestar.com.ar/manejo-cardiovascular',
        duration: 32,
        priority: 1,
        tags: ['cardiovascular', 'crónico', 'manejo']
      },
      {
        id: 'd-hea-002',
        title: 'Ejercicio Seguro con Cardiopatía',
        description: 'Guía para mantenerse activa con seguridad',
        url: 'https://plataforma.epa-bienestar.com.ar/ejercicio-cardiopatia',
        duration: 28,
        priority: 2,
        tags: ['ejercicio', 'cardiopatía', 'seguridad']
      }
    ],
    brain: [
      {
        id: 'd-bra-001',
        title: 'Conexión Cerebro-Corazón',
        description: 'Prevención simultánea de demencia y cardiopatía',
        url: 'https://plataforma.epa-bienestar.com.ar/cerebro-corazon',
        duration: 30,
        priority: 1,
        tags: ['cerebro', 'corazón', 'prevención'],
        criticalContent: true
      },
      {
        id: 'd-bra-002',
        title: 'Estimulación Cognitiva Diaria',
        description: 'Actividades para mantener la mente ágil',
        url: 'https://plataforma.epa-bienestar.com.ar/estimulacion-cognitiva',
        duration: 20,
        priority: 2,
        tags: ['cognición', 'actividades', 'mente']
      }
    ]
  },

  // ========== CONTENIDO UNIVERSAL (Todos los Grupos) ==========
  universal: {
    heart: [
      {
        id: 'uni-hea-001',
        title: "Life's Essential 8 - AHA",
        description: 'Las 8 métricas esenciales para salud cardiovascular óptima',
        url: 'https://plataforma.epa-bienestar.com.ar/lifes-essential-8',
        duration: 40,
        priority: 1,
        tags: ['AHA', 'métricas', 'prevención'],
        requiredViewing: true
      },
      {
        id: 'uni-hea-002',
        title: 'Plan Bienestar 100 Días - Introducción',
        description: 'Tu camino hacia la salud cardiovascular',
        url: 'https://plataforma.epa-bienestar.com.ar/plan-100-dias',
        duration: 35,
        priority: 2,
        tags: ['plan', '100-días', 'introducción'],
        requiredViewing: true
      },
      {
        id: 'uni-hea-003',
        title: 'Prevención de Hipertensión Arterial',
        description: 'Estrategias basadas en evidencia para controlar la presión',
        url: 'https://plataforma.epa-bienestar.com.ar/prevencion-hta',
        duration: 30,
        priority: 3,
        tags: ['hipertensión', 'prevención', 'control']
      },
      {
        id: 'uni-hea-004',
        title: 'Reconocer Señales de Emergencia Cardiovascular',
        description: 'Cuándo llamar al 107 o ir a urgencias',
        url: 'https://plataforma.epa-bienestar.com.ar/emergencias-cardiovasculares',
        duration: 15,
        priority: 4,
        tags: ['emergencia', '107', 'urgencias'],
        criticalContent: true,
        requiredViewing: true
      }
    ],
    habits: [
      {
        id: 'uni-hab-001',
        title: 'Los 4 Pilares del Plan Bienestar',
        description: 'Hábitos, Emociones, Corazón y Cerebro',
        url: 'https://plataforma.epa-bienestar.com.ar/4-pilares',
        duration: 25,
        priority: 1,
        tags: ['pilares', 'plan', 'fundamentos']
      }
    ]
  }
};

// ============================================================================
// FUNCIONES DE UTILIDAD
// ============================================================================

/**
 * Obtiene contenidos según grupo y filtros
 */
export function getContentsByGroup(
  group: 'A' | 'B' | 'C' | 'D',
  options?: {
    category?: 'habits' | 'emotions' | 'heart' | 'brain';
    maxItems?: number;
    includeUniversal?: boolean;
  }
): any[] {
  const groupKey = `group${group}` as keyof typeof CONTENT_CATALOG;
  const groupContent = CONTENT_CATALOG[groupKey];
  
  let items: any[] = [];
  
  // Agregar contenido del grupo específico
  if (options?.category) {
    items = groupContent[options.category] || [];
  } else {
    // Agregar todas las categorías
    Object.values(groupContent).forEach(categoryItems => {
      items.push(...categoryItems);
    });
  }
  
  // Agregar contenido universal si está habilitado
  if (options?.includeUniversal !== false) {
    if (options?.category) {
      const universalCat = CONTENT_CATALOG.universal[options.category];
      if (universalCat) items.push(...universalCat);
    } else {
      Object.values(CONTENT_CATALOG.universal).forEach(categoryItems => {
        items.push(...categoryItems);
      });
    }
  }
  
  // Ordenar por prioridad
  items.sort((a, b) => a.priority - b.priority);
  
  // Limitar cantidad si se especifica
  if (options?.maxItems) {
    items = items.slice(0, options.maxItems);
  }
  
  return items;
}

/**
 * Obtiene contenidos críticos (requiredViewing o criticalContent)
 */
export function getCriticalContent(group?: 'A' | 'B' | 'C' | 'D'): any[] {
  let allContent: any[] = [];
  
  if (group) {
    const groupKey = `group${group}` as keyof typeof CONTENT_CATALOG;
    Object.values(CONTENT_CATALOG[groupKey]).forEach(categoryItems => {
      allContent.push(...categoryItems);
    });
  } else {
    // Incluir todos los grupos
    ['groupA', 'groupB', 'groupC', 'groupD'].forEach(gKey => {
      const groupContent = CONTENT_CATALOG[gKey as keyof typeof CONTENT_CATALOG];
      Object.values(groupContent).forEach(categoryItems => {
        allContent.push(...(categoryItems as any[]));
      });
    });
  }
  
  // Agregar universal
  Object.values(CONTENT_CATALOG.universal).forEach(categoryItems => {
    allContent.push(...categoryItems);
  });
  
  return allContent.filter(item => 
    item.criticalContent || item.requiredViewing
  );
}

/**
 * Genera reporte de contenidos disponibles
 */
export function generateContentReport(): void {
  console.log('📊 REPORTE DE CONTENIDOS EPA BIENESTAR\n');
  console.log('='.repeat(60));
  
  ['A', 'B', 'C', 'D'].forEach(group => {
    const contents = getContentsByGroup(group as any, { includeUniversal: false });
    const critical = contents.filter(c => c.criticalContent || c.requiredViewing);
    
    console.log(`\n🎯 GRUPO ${group}:`);
    console.log(`   Total contenidos: ${contents.length}`);
    console.log(`   Contenidos críticos: ${critical.length}`);
    
    const byCategory = contents.reduce((acc: any, item: any) => {
      const cat = item.tags.find((t: string) => 
        ['hábitos', 'emociones', 'corazón', 'cerebro'].some(c => 
          t.includes(c.toLowerCase())
        )
      ) || 'otro';
      acc[cat] = (acc[cat] || 0) + 1;
      return acc;
    }, {});
    
    console.log('   Por categoría:', byCategory);
  });
  
  const universal = Object.values(CONTENT_CATALOG.universal)
    .flat()
    .length;
  console.log(`\n🌐 CONTENIDO UNIVERSAL: ${universal}`);
  
  console.log('\n' + '='.repeat(60));
}

// ============================================================================
// SCRIPTS DE MIGRACIÓN/SEEDING
// ============================================================================

/**
 * Script para crear todos los DocumentReference en Medplum
 */
export async function seedFHIRDocuments(medplum: any, patientId: string): Promise<void> {
  console.log('🌱 Seeding FHIR DocumentReference resources...');
  
  const allContent = [
    ...getContentsByGroup('A'),
    ...getContentsByGroup('B'),
    ...getContentsByGroup('C'),
    ...getContentsByGroup('D')
  ];
  
  let created = 0;
  let errors = 0;
  
  for (const content of allContent) {
    try {
      const docRef = {
        resourceType: 'DocumentReference',
        status: 'current',
        docStatus: 'final',
        identifier: [{
          system: 'https://plataforma.epa-bienestar.com.ar',
          value: content.id
        }],
        subject: {
          reference: `Patient/${patientId}`
        },
        type: {
          coding: [{
            system: 'http://loinc.org',
            code: '81215-6',
            display: 'Care plan'
          }]
        },
        content: [{
          attachment: {
            contentType: 'text/html',
            url: content.url,
            title: content.title
          }
        }]
      };
      
      await medplum.createResource(docRef);
      created++;
      console.log(`✅ Created: ${content.id}`);
    } catch (error) {
      errors++;
      console.error(`❌ Error: ${content.id}`, error);
    }
  }
  
  console.log(`\n📊 Resultados:`);
  console.log(`   ✅ Creados: ${created}`);
  console.log(`   ❌ Errores: ${errors}`);
}

// Ejecutar reporte si se corre directamente
if (require.main === module) {
  generateContentReport();
}
