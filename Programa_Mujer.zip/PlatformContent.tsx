import { useState, useEffect } from 'react';
import { useMedplum, useMedplumProfile } from '@medplum/react';
import { Patient, DocumentReference } from '@medplum/fhirtypes';
import { calculateAge } from '@medplum/core';

interface ContentItem {
  id: string;
  title: string;
  description: string;
  url: string;
  imageUrl?: string;
  targetGroup: 'A' | 'B' | 'C' | 'D' | 'ALL';
  category: 'habits' | 'emotions' | 'heart' | 'brain';
  priority: number;
}

// Mapeo de contenidos desde plataforma.epa-bienestar.com.ar
const PLATFORM_CONTENTS: ContentItem[] = [
  // Grupo A: Mujeres 18-30 años
  {
    id: 'plan-100-dias-intro',
    title: 'Plan Bienestar 100 Días - Introducción',
    description: 'Descubre cómo transformar tu salud cardiovascular en 100 días',
    url: 'https://plataforma.epa-bienestar.com.ar/plan-100-dias',
    targetGroup: 'A',
    category: 'habits',
    priority: 1
  },
  {
    id: 'habitos-saludables-jovenes',
    title: 'Hábitos Saludables para Jóvenes Profesionales',
    description: 'Construye rutinas que potencien tu desarrollo personal y profesional',
    url: 'https://plataforma.epa-bienestar.com.ar/habitos-jovenes',
    targetGroup: 'A',
    category: 'habits',
    priority: 2
  },
  {
    id: 'gestion-emocional-trabajo',
    title: 'Gestión Emocional en el Trabajo',
    description: 'Herramientas para manejar el estrés laboral y académico',
    url: 'https://plataforma.epa-bienestar.com.ar/emociones-trabajo',
    targetGroup: 'A',
    category: 'emotions',
    priority: 3
  },
  
  // Grupo B: Mujeres 28-40 años (planificando maternidad)
  {
    id: 'salud-cardiovascular-preconcepcional',
    title: 'Salud Cardiovascular Pre-Concepcional',
    description: 'Prepara tu corazón para un embarazo saludable',
    url: 'https://plataforma.epa-bienestar.com.ar/preconcepcional',
    targetGroup: 'B',
    category: 'heart',
    priority: 1
  },
  {
    id: 'prevencion-preeclampsia',
    title: 'Prevención de Preeclampsia',
    description: 'Factores de riesgo cardiovascular en el embarazo',
    url: 'https://plataforma.epa-bienestar.com.ar/preeclampsia',
    targetGroup: 'B',
    category: 'heart',
    priority: 2
  },
  {
    id: 'diabetes-gestacional',
    title: 'Prevención de Diabetes Gestacional',
    description: 'Control metabólico antes y durante el embarazo',
    url: 'https://plataforma.epa-bienestar.com.ar/diabetes-gestacional',
    targetGroup: 'B',
    category: 'habits',
    priority: 3
  },
  
  // Grupo C: Mujeres 45-65 años (menopausia)
  {
    id: 'menopausia-salud-cardiovascular',
    title: 'Menopausia y Salud Cardiovascular',
    description: 'Cambios hormonales y protección del corazón',
    url: 'https://plataforma.epa-bienestar.com.ar/menopausia-corazon',
    targetGroup: 'C',
    category: 'heart',
    priority: 1
  },
  {
    id: 'sintomas-atipicos-mujeres',
    title: 'Síntomas Atípicos de Infarto en Mujeres',
    description: 'Reconoce las señales de alerta específicas en mujeres',
    url: 'https://plataforma.epa-bienestar.com.ar/sintomas-atipicos',
    targetGroup: 'C',
    category: 'heart',
    priority: 2
  },
  {
    id: 'ejercicio-resistencia-menopausia',
    title: 'Ejercicio de Resistencia en la Menopausia',
    description: 'Fortalece tu salud ósea y cardiovascular',
    url: 'https://plataforma.epa-bienestar.com.ar/ejercicio-menopausia',
    targetGroup: 'C',
    category: 'habits',
    priority: 3
  },
  
  // Grupo D: Mujeres 65+ años
  {
    id: 'vida-activa-adultos-mayores',
    title: 'Vida Activa para Abuelas Emprendedoras',
    description: 'Mantén tu vitalidad y salud cardiovascular',
    url: 'https://plataforma.epa-bienestar.com.ar/vida-activa-65plus',
    targetGroup: 'D',
    category: 'habits',
    priority: 1
  },
  {
    id: 'salud-cerebral-cardiovascular',
    title: 'Conexión Cerebro-Corazón',
    description: 'Prevención de deterioro cognitivo y cardiovascular',
    url: 'https://plataforma.epa-bienestar.com.ar/cerebro-corazon',
    targetGroup: 'D',
    category: 'brain',
    priority: 2
  },
  
  // Contenido universal para todos los grupos
  {
    id: 'lifes-essential-8',
    title: "Life's Essential 8 - AHA",
    description: 'Las 8 métricas esenciales para la salud cardiovascular',
    url: 'https://plataforma.epa-bienestar.com.ar/lifes-essential-8',
    targetGroup: 'ALL',
    category: 'heart',
    priority: 1
  },
  {
    id: 'prevencion-hta',
    title: 'Prevención de Hipertensión Arterial',
    description: 'Control de presión arterial sin medicamentos',
    url: 'https://plataforma.epa-bienestar.com.ar/prevencion-hta',
    targetGroup: 'ALL',
    category: 'heart',
    priority: 2
  }
];

/**
 * Determina el grupo de vida de una paciente basado en edad y contexto clínico
 * Esta función debería eventualmente consultar FHIR Observations y Conditions
 */
function determineLifeStageGroup(patient: Patient): 'A' | 'B' | 'C' | 'D' {
  if (!patient.birthDate) return 'A';
  
  const age = calculateAge(patient.birthDate);
  
  // Grupo A: 18-30 años
  if (age >= 18 && age < 28) return 'A';
  
  // Grupo B: 28-40 años (idealmente verificar intención de maternidad en FHIR)
  if (age >= 28 && age < 45) return 'B';
  
  // Grupo C: 45-65 años (menopausia)
  if (age >= 45 && age < 65) return 'C';
  
  // Grupo D: 65+ años
  if (age >= 65) return 'D';
  
  return 'A';
}

/**
 * Componente que muestra contenidos educativos desde plataforma.epa-bienestar.com.ar
 * segmentados por grupo de vida y sincronizados con FHIR DocumentReference
 */
export function PlatformContent(): JSX.Element {
  const medplum = useMedplum();
  const profile = useMedplumProfile() as Patient;
  const [contents, setContents] = useState<ContentItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;

    const lifeStageGroup = determineLifeStageGroup(profile);
    
    // Filtrar contenidos relevantes para el grupo de vida
    const relevantContents = PLATFORM_CONTENTS
      .filter(c => c.targetGroup === lifeStageGroup || c.targetGroup === 'ALL')
      .sort((a, b) => a.priority - b.priority)
      .slice(0, 6); // Mostrar top 6 contenidos

    setContents(relevantContents);
    
    // Sincronizar con FHIR: crear/actualizar DocumentReference resources
    syncWithFHIR(relevantContents);
    
    setLoading(false);
  }, [profile]);

  /**
   * Sincroniza contenidos con FHIR DocumentReference
   * Esto permite que el contenido educativo sea parte del registro clínico
   */
  async function syncWithFHIR(items: ContentItem[]) {
    if (!profile?.id) return;

    for (const item of items) {
      try {
        // Buscar si ya existe DocumentReference para este contenido
        const existing = await medplum.searchOne('DocumentReference', {
          identifier: `platform-content|${item.id}`,
          subject: `Patient/${profile.id}`
        });

        if (existing) continue; // Ya existe, no duplicar

        // Crear DocumentReference FHIR R4 compliant
        const docRef: DocumentReference = {
          resourceType: 'DocumentReference',
          status: 'current',
          docStatus: 'final',
          identifier: [{
            system: 'https://plataforma.epa-bienestar.com.ar',
            value: item.id
          }],
          subject: {
            reference: `Patient/${profile.id}`,
            display: profile.name?.[0] ? 
              `${profile.name[0].given?.join(' ')} ${profile.name[0].family}` : 
              'Patient'
          },
          type: {
            coding: [{
              system: 'http://loinc.org',
              code: '81215-6',
              display: 'Care plan'
            }],
            text: 'Educational Content'
          },
          category: [{
            coding: [{
              system: 'https://epa-bienestar.com.ar/fhir/CodeSystem/content-category',
              code: item.category,
              display: item.category.charAt(0).toUpperCase() + item.category.slice(1)
            }]
          }],
          date: new Date().toISOString(),
          description: item.description,
          content: [{
            attachment: {
              contentType: 'text/html',
              url: item.url,
              title: item.title
            }
          }],
          context: {
            related: [{
              reference: `PlanDefinition/plan-bienestar-100-dias`
            }]
          }
        };

        await medplum.createResource(docRef);
      } catch (error) {
        console.error(`Error syncing content ${item.id}:`, error);
      }
    }
  }

  const handleContentClick = async (item: ContentItem) => {
    // Registrar interacción como Task o Observation
    try {
      await medplum.createResource({
        resourceType: 'Task',
        status: 'requested',
        intent: 'order',
        code: {
          coding: [{
            system: 'https://epa-bienestar.com.ar/fhir/CodeSystem/task-type',
            code: 'educational-content-access',
            display: 'Educational Content Access'
          }]
        },
        description: `Usuario accedió a: ${item.title}`,
        for: {
          reference: `Patient/${profile.id}`
        },
        authoredOn: new Date().toISOString(),
        input: [{
          type: {
            text: 'Content ID'
          },
          valueString: item.id
        }]
      });
    } catch (error) {
      console.error('Error registering content access:', error);
    }

    // Abrir contenido en nueva pestaña
    window.open(item.url, '_blank');
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (contents.length === 0) {
    return null;
  }

  return (
    <div className="mt-10 w-full">
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">
          Contenidos Recomendados para Ti
        </h2>
        <a 
          href="https://plataforma.epa-bienestar.com.ar" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-sm font-medium text-purple-600 hover:text-purple-700"
        >
          Ver todos →
        </a>
      </div>
      
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {contents.map((item) => (
          <div
            key={item.id}
            onClick={() => handleContentClick(item)}
            className="group relative flex flex-col overflow-hidden rounded-lg bg-white shadow-md transition-all duration-300 hover:shadow-xl hover:-translate-y-1 cursor-pointer"
          >
            {/* Indicador de categoría */}
            <div className="absolute top-4 left-4 z-10">
              <span className={`
                inline-flex items-center px-3 py-1 rounded-full text-xs font-medium
                ${item.category === 'habits' ? 'bg-green-100 text-green-800' : ''}
                ${item.category === 'emotions' ? 'bg-blue-100 text-blue-800' : ''}
                ${item.category === 'heart' ? 'bg-red-100 text-red-800' : ''}
                ${item.category === 'brain' ? 'bg-purple-100 text-purple-800' : ''}
              `}>
                {item.category === 'habits' && '🎯 Hábitos'}
                {item.category === 'emotions' && '💭 Emociones'}
                {item.category === 'heart' && '❤️ Corazón'}
                {item.category === 'brain' && '🧠 Cerebro'}
              </span>
            </div>

            {/* Imagen o placeholder */}
            <div className="h-48 bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center">
              {item.imageUrl ? (
                <img 
                  src={item.imageUrl} 
                  alt={item.title}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="text-6xl">
                  {item.category === 'habits' && '🎯'}
                  {item.category === 'emotions' && '💭'}
                  {item.category === 'heart' && '❤️'}
                  {item.category === 'brain' && '🧠'}
                </div>
              )}
            </div>

            {/* Contenido */}
            <div className="flex flex-1 flex-col p-6">
              <h3 className="text-lg font-semibold text-gray-900 group-hover:text-purple-600 transition-colors">
                {item.title}
              </h3>
              <p className="mt-2 flex-1 text-sm text-gray-600">
                {item.description}
              </p>
              <div className="mt-4 flex items-center text-sm font-medium text-purple-600">
                Explorar
                <svg className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" 
                     fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* CTA para Plan Bienestar 100 Días */}
      <div className="mt-8 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 p-8 text-white shadow-lg">
        <div className="flex flex-col items-center text-center md:flex-row md:text-left md:justify-between">
          <div className="mb-4 md:mb-0 md:mr-8">
            <h3 className="text-2xl font-bold mb-2">Plan Bienestar 100 Días</h3>
            <p className="text-purple-100">
              Transforma tu salud cardiovascular con nuestro programa basado en Life's Essential 8 de la AHA
            </p>
          </div>
          <a
            href="https://plataforma.epa-bienestar.com.ar/plan-100-dias"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-6 py-3 bg-white text-purple-600 rounded-lg font-semibold hover:bg-purple-50 transition-colors whitespace-nowrap"
          >
            Comenzar ahora
            <svg className="ml-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </a>
        </div>
      </div>
    </div>
  );
}
