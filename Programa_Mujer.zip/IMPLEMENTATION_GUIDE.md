# 🚀 Guía de Implementación: Integración de Contenidos Educativos

## 📋 Índice
1. [Resumen Ejecutivo](#resumen-ejecutivo)
2. [Arquitectura de la Solución](#arquitectura)
3. [Implementación Paso a Paso](#implementacion)
4. [Alternativas de Integración](#alternativas)
5. [Consideraciones FHIR R4](#fhir-considerations)
6. [Testing y Validación](#testing)
7. [Roadmap y Evolución](#roadmap)

---

## 🎯 Resumen Ejecutivo

Esta guía describe cómo integrar contenidos educativos desde **plataforma.epa-bienestar.com.ar** 
hacia la HomePage de la aplicación THRIVE, manteniendo:

✅ **Compliance con FHIR R4**: DocumentReference resources  
✅ **Segmentación por grupos de vida**: A, B, C, D  
✅ **Interoperabilidad clínica**: Tracking de engagement  
✅ **SEO preservado**: Contenido original permanece accesible  
✅ **Data-driven personalization**: Basado en perfil de paciente  

---

## 🏗️ Arquitectura de la Solución

```
┌─────────────────────────────────────────────────────────────┐
│                        HomePage.tsx                         │
│  ┌────────────────────────────────────────────────────┐    │
│  │          PlatformContent Component                  │    │
│  │  ┌──────────────────────────────────────────────┐  │    │
│  │  │  1. Determina grupo de vida (A/B/C/D)        │  │    │
│  │  │  2. Filtra contenidos relevantes             │  │    │
│  │  │  3. Renderiza cards interactivas             │  │    │
│  │  │  4. Sincroniza con FHIR DocumentReference    │  │    │
│  │  │  5. Trackea acceso con Task resources        │  │    │
│  │  └──────────────────────────────────────────────┘  │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
         │                                    │
         │                                    │
         ▼                                    ▼
┌─────────────────────┐          ┌─────────────────────────┐
│  FHIR Server        │          │ plataforma.epa-         │
│  (Medplum)          │          │ bienestar.com.ar        │
│                     │          │                         │
│  - DocumentReference│◄─────────│  - Contenido HTML       │
│  - Task (tracking)  │          │  - Plan 100 Días        │
│  - Patient          │          │  - Life's Essential 8   │
│  - CarePlan         │          │  - Recursos educativos  │
└─────────────────────┘          └─────────────────────────┘
```

### Flujo de Datos

1. **Usuario accede a HomePage** → `HomePage.tsx`
2. **PlatformContent se monta** → `useEffect()` se ejecuta
3. **Obtiene perfil de paciente** → `useMedplumProfile()`
4. **Determina grupo de vida** → Edad + contexto clínico
5. **Filtra contenidos** → Array de `ContentItem[]`
6. **Sincroniza con FHIR** → Crea `DocumentReference`
7. **Usuario hace click** → Registra `Task` + abre URL
8. **Analytics post-access** → Métricas de engagement

---

## 🛠️ Implementación Paso a Paso

### Paso 1: Instalar el Componente

```bash
# 1. Copiar PlatformContent.tsx a tu proyecto
cp PlatformContent.tsx src/components/

# 2. Copiar tipos TypeScript
cp types-platform-content.ts src/types/

# 3. Copiar servicio (opcional pero recomendado)
cp platform-content-service.ts src/services/
```

### Paso 2: Actualizar HomePage.tsx

```typescript
// src/pages/HomePage.tsx

import { PlatformContent } from '../components/PlatformContent';

export function HomePage(): JSX.Element {
  // ... código existente ...
  
  return (
    <div>
      <Header />
      {/* ... otras secciones ... */}
      
      <div className="w-full bg-gray-50">
        <section className="mx-auto max-w-7xl px-2 pb-10 sm:px-4 md:pt-6 md:pb-20 lg:px-8">
          <Carousel items={carouselItems} />
          
          {/* ✨ AGREGAR AQUÍ ✨ */}
          <PlatformContent />
          
          {/* ... resto del contenido ... */}
        </section>
      </div>
      
      <Footer />
    </div>
  );
}
```

### Paso 3: Configurar Contenidos

Edita `PlatformContent.tsx` para actualizar el array `PLATFORM_CONTENTS`:

```typescript
const PLATFORM_CONTENTS: ContentItem[] = [
  {
    id: 'tu-contenido-1',
    title: 'Título del Contenido',
    description: 'Descripción breve',
    url: 'https://plataforma.epa-bienestar.com.ar/ruta-al-contenido',
    targetGroup: 'B', // A, B, C, D, o ALL
    category: 'heart',  // habits, emotions, heart, brain
    priority: 1         // 1 = más prioritario
  },
  // ... más contenidos
];
```

### Paso 4: Personalizar Estilos (Opcional)

Los estilos usan **Tailwind CSS**. Puedes modificar:

```typescript
// Cambiar colores de categorías
${item.category === 'heart' ? 'bg-red-100 text-red-800' : ''}

// Ajustar grid responsive
<div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">

// Modificar hover effects
hover:shadow-xl hover:-translate-y-1
```

---

## 🔀 Alternativas de Integración

### Opción 1: Componente React (Recomendado) ✅

**Pros:**
- Control total sobre UI/UX
- Sincronización FHIR nativa
- Analytics detallados
- Personalización por paciente

**Contras:**
- Requiere actualizar componente cuando cambia contenido
- Mayor complejidad de desarrollo

**Cuándo usar:** Cuando necesitas personalización avanzada y tracking FHIR.

---

### Opción 2: Iframe Embebido

```typescript
export function PlatformContentIframe(): JSX.Element {
  const profile = useMedplumProfile() as Patient;
  const group = determineLifeStageGroup(profile);
  
  return (
    <div className="mt-10 w-full">
      <iframe
        src={`https://plataforma.epa-bienestar.com.ar/embed?group=${group}`}
        width="100%"
        height="600px"
        frameBorder="0"
        className="rounded-lg shadow-lg"
        title="Contenidos EPA Bienestar"
      />
    </div>
  );
}
```

**Pros:**
- Implementación muy rápida
- Contenido siempre actualizado
- No requiere mantenimiento

**Contras:**
- Sin integración FHIR
- SEO limitado
- Analytics separados
- Menos control sobre UX

**Cuándo usar:** MVP rápido o prueba de concepto.

---

### Opción 3: API Backend + Caché

```typescript
// Arquitectura
┌──────────────┐       ┌──────────────┐       ┌─────────────────┐
│   Frontend   │──────►│  API Gateway │──────►│   Plataforma    │
│  (React)     │◄──────│  (Node.js)   │◄──────│   (CMS/Strapi)  │
└──────────────┘       └──────────────┘       └─────────────────┘
                              │
                              ▼
                       ┌──────────────┐
                       │  Redis Cache │
                       └──────────────┘
```

**Servicio Backend (Node.js + Express):**

```typescript
// services/content-api.ts
import express from 'express';
import axios from 'axios';
import Redis from 'redis';

const app = express();
const redis = Redis.createClient();

app.get('/api/content/:group', async (req, res) => {
  const { group } = req.params;
  const cacheKey = `content:${group}`;
  
  // Verificar caché
  const cached = await redis.get(cacheKey);
  if (cached) {
    return res.json(JSON.parse(cached));
  }
  
  // Fetch desde plataforma
  const response = await axios.get(
    `https://plataforma.epa-bienestar.com.ar/api/content?group=${group}`
  );
  
  // Cachear por 1 hora
  await redis.setex(cacheKey, 3600, JSON.stringify(response.data));
  
  res.json(response.data);
});

app.listen(3001);
```

**Pros:**
- Performance optimizado (caché)
- Escalable
- Separación de concerns
- Fácil agregar lógica de negocio

**Contras:**
- Mayor complejidad de infraestructura
- Costos de hosting adicionales
- Requiere mantenimiento del backend

**Cuándo usar:** Producción a escala, múltiples fuentes de contenido.

---

## 📊 Consideraciones FHIR R4

### DocumentReference Resource

```json
{
  "resourceType": "DocumentReference",
  "id": "edu-content-123",
  "status": "current",
  "docStatus": "final",
  "identifier": [{
    "system": "https://plataforma.epa-bienestar.com.ar",
    "value": "plan-100-dias-intro"
  }],
  "subject": {
    "reference": "Patient/patient-456"
  },
  "type": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "81215-6",
      "display": "Care plan"
    }]
  },
  "category": [{
    "coding": [{
      "system": "https://epa-bienestar.com.ar/fhir/CodeSystem/content-category",
      "code": "heart",
      "display": "Salud Cardiovascular"
    }]
  }],
  "content": [{
    "attachment": {
      "contentType": "text/html",
      "url": "https://plataforma.epa-bienestar.com.ar/plan-100-dias",
      "title": "Plan Bienestar 100 Días - Introducción"
    }
  }]
}
```

### Task Resource (Tracking)

```json
{
  "resourceType": "Task",
  "status": "completed",
  "intent": "order",
  "code": {
    "coding": [{
      "system": "https://epa-bienestar.com.ar/fhir/CodeSystem/task-type",
      "code": "educational-content-access",
      "display": "Educational Content Access"
    }]
  },
  "for": {
    "reference": "Patient/patient-456"
  },
  "authoredOn": "2025-01-15T10:30:00Z",
  "input": [{
    "type": { "text": "Content ID" },
    "valueString": "plan-100-dias-intro"
  }],
  "output": [{
    "type": { "text": "Time Spent (seconds)" },
    "valueInteger": 180
  }, {
    "type": { "text": "Completed" },
    "valueBoolean": true
  }]
}
```

---

## 🧪 Testing y Validación

### Tests Unitarios

```typescript
// PlatformContent.test.tsx
import { render, screen, waitFor } from '@testing-library/react';
import { PlatformContent } from './PlatformContent';
import { MockedProvider } from '@medplum/react';

describe('PlatformContent', () => {
  it('muestra contenidos para Grupo A', async () => {
    const mockPatient = {
      resourceType: 'Patient',
      birthDate: '2000-01-01'  // 25 años = Grupo A
    };
    
    render(
      <MockedProvider medplum={mockMedplum} profile={mockPatient}>
        <PlatformContent />
      </MockedProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/Hábitos Saludables para Jóvenes/)).toBeInTheDocument();
    });
  });
  
  it('crea DocumentReference al montar', async () => {
    // ... test de sincronización FHIR
  });
});
```

### Validación FHIR

```bash
# Usar FHIR Validator de HL7
java -jar validator_cli.jar document-reference.json -version 4.0
```

---

## 🗺️ Roadmap y Evolución

### Fase 1: MVP (Actual) ✅
- [x] Componente básico PlatformContent
- [x] Segmentación por grupos A, B, C, D
- [x] Sincronización con DocumentReference
- [x] Tracking básico con Tasks

### Fase 2: Analytics Avanzados 🔄
- [ ] Dashboard de engagement
- [ ] Métricas de completitud
- [ ] Recomendaciones ML-powered
- [ ] A/B testing de contenidos

### Fase 3: Personalización Profunda 🚀
- [ ] Integración con PCOS product
- [ ] Contenido dinámico basado en Observations
- [ ] Chatbot para guiar el aprendizaje
- [ ] Certificados de completitud

### Fase 4: Ecosistema Completo 🌐
- [ ] Mobile app (React Native)
- [ ] API pública para partners
- [ ] Integración con wearables (Terra API)
- [ ] Exportación a registros EMR externos

---

## 📚 Recursos Adicionales

### Documentación
- [FHIR R4 DocumentReference](https://www.hl7.org/fhir/documentreference.html)
- [FHIR R4 Task](https://www.hl7.org/fhir/task.html)
- [Life's Essential 8 - AHA](https://www.heart.org/lifes8)
- [Medplum TypeScript SDK](https://www.medplum.com/docs/sdk)

### Contacto y Soporte
- **Tech Lead**: Alejandro D'Alessandro
- **Repo**: https://github.com/drdalessandro/mujer
- **Medplum Instance**: https://api.epa-bienestar.com.ar/fhir/r4
- **Plataforma**: https://plataforma.epa-bienestar.com.ar

---

## ⚠️ Consideraciones Importantes

### Performance
- Implementar lazy loading para imágenes
- Considerar virtualización para >20 items
- Cachear resultados de FHIR búsquedas

### Privacidad y Seguridad
- NUNCA exponer datos sensibles en URLs
- Validar todos los inputs de usuario
- Implementar rate limiting en API calls

### Accesibilidad
- Asegurar contraste de colores WCAG AA
- Agregar `aria-labels` descriptivos
- Soporte para navegación por teclado

### SEO
- Agregar structured data (JSON-LD)
- Meta tags dinámicos por contenido
- Sitemap.xml actualizado automáticamente

---

## 🎉 ¡Próximos Pasos!

1. **Implementar** el componente básico
2. **Testear** con usuarios de cada grupo
3. **Iterar** basado en feedback
4. **Escalar** a toda la plataforma

¿Preguntas? Escríbenos o abre un issue en GitHub.
