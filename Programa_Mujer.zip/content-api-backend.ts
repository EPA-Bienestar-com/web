/**
 * API BACKEND PARA CONTENIDOS EDUCATIVOS
 * 
 * Microservicio Node.js/Express que sirve contenidos desde
 * plataforma.epa-bienestar.com.ar con:
 * - Caché en Redis
 * - Analytics de engagement
 * - Personalización basada en FHIR
 * - Rate limiting
 * 
 * Stack: Node.js + Express + Redis + TypeScript
 */

import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import Redis from 'ioredis';
import rateLimit from 'express-rate-limit';
import { MedplumClient } from '@medplum/core';

// ============================================================================
// CONFIGURACIÓN
// ============================================================================

const app = express();
const PORT = process.env.PORT || 3001;

// Redis client
const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD,
  retryStrategy: (times) => Math.min(times * 50, 2000)
});

// Medplum client
const medplum = new MedplumClient({
  baseUrl: process.env.MEDPLUM_BASE_URL || 'https://api.epa-bienestar.com.ar/fhir/r4',
  clientId: process.env.MEDPLUM_CLIENT_ID!,
  clientSecret: process.env.MEDPLUM_CLIENT_SECRET!
});

// Middleware
app.use(cors({
  origin: ['https://app.epa-bienestar.com.ar', 'http://localhost:3000'],
  credentials: true
}));
app.use(express.json());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // 100 requests por ventana
  message: 'Demasiadas solicitudes, intenta de nuevo más tarde'
});
app.use('/api/', limiter);

// ============================================================================
// TIPOS
// ============================================================================

interface ContentItem {
  id: string;
  title: string;
  description: string;
  url: string;
  imageUrl?: string;
  targetGroup: 'A' | 'B' | 'C' | 'D' | 'ALL';
  category: 'habits' | 'emotions' | 'heart' | 'brain';
  priority: number;
  duration?: number;
  tags?: string[];
  criticalContent?: boolean;
  requiredViewing?: boolean;
}

interface ContentResponse {
  items: ContentItem[];
  totalCount: number;
  filteredGroup: string;
  cached: boolean;
  cacheAge?: number;
}

interface AnalyticsEvent {
  eventType: 'view' | 'click' | 'complete';
  contentId: string;
  patientId: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

// ============================================================================
// MIDDLEWARE DE AUTENTICACIÓN
// ============================================================================

async function authenticate(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token no proporcionado' });
  }
  
  const token = authHeader.substring(7);
  
  try {
    // Validar token con Medplum
    const profile = await medplum.get('auth/me', {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    (req as any).user = profile;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Token inválido' });
  }
}

// ============================================================================
// SERVICIOS
// ============================================================================

class ContentService {
  /**
   * Obtiene contenidos desde caché o genera nuevos
   */
  async getContents(
    group: string,
    patientId: string,
    options?: {
      category?: string;
      maxItems?: number;
    }
  ): Promise<ContentResponse> {
    const cacheKey = `contents:${group}:${options?.category || 'all'}:${options?.maxItems || 6}`;
    
    // Intentar obtener desde caché
    const cached = await redis.get(cacheKey);
    if (cached) {
      const data = JSON.parse(cached);
      const cacheAge = await redis.ttl(cacheKey);
      return {
        ...data,
        cached: true,
        cacheAge
      };
    }
    
    // Generar contenidos (aquí iría lógica de filtrado real)
    const items: ContentItem[] = await this.fetchFromPlatform(group, options);
    
    const response: ContentResponse = {
      items,
      totalCount: items.length,
      filteredGroup: group,
      cached: false
    };
    
    // Cachear por 1 hora
    await redis.setex(cacheKey, 3600, JSON.stringify(response));
    
    return response;
  }
  
  /**
   * Obtiene contenidos desde plataforma.epa-bienestar.com.ar
   * En producción, esto consultaría una API real o CMS
   */
  private async fetchFromPlatform(
    group: string,
    options?: any
  ): Promise<ContentItem[]> {
    // Placeholder: aquí iría la lógica real de fetch
    // Por ahora retornamos mock data
    return [];
  }
  
  /**
   * Sincroniza contenido con FHIR DocumentReference
   */
  async syncToFHIR(content: ContentItem, patientId: string): Promise<any> {
    try {
      // Verificar si ya existe
      const existing = await medplum.searchOne('DocumentReference', {
        identifier: `https://plataforma.epa-bienestar.com.ar|${content.id}`,
        subject: `Patient/${patientId}`
      });
      
      if (existing) return existing;
      
      // Crear nuevo
      return await medplum.createResource({
        resourceType: 'DocumentReference',
        status: 'current',
        docStatus: 'final',
        identifier: [{
          system: 'https://plataforma.epa-bienestar.com.ar',
          value: content.id
        }],
        subject: {
          reference: `Patient/${patientId}`
        },
        type: {
          coding: [{
            system: 'http://loinc.org',
            code: '81215-6',
            display: 'Care plan'
          }]
        },
        content: [{
          attachment: {
            contentType: 'text/html',
            url: content.url,
            title: content.title
          }
        }]
      });
    } catch (error) {
      console.error('Error syncing to FHIR:', error);
      throw error;
    }
  }
}

class AnalyticsService {
  /**
   * Registra un evento de analytics
   */
  async trackEvent(event: AnalyticsEvent): Promise<void> {
    // Guardar en Redis (stream de eventos)
    await redis.xadd(
      'analytics:events',
      '*',
      'event', JSON.stringify(event)
    );
    
    // Incrementar contadores
    await redis.incr(`analytics:content:${event.contentId}:${event.eventType}`);
    await redis.incr(`analytics:patient:${event.patientId}:total-events`);
    
    // Registrar en FHIR como Task
    if (event.eventType === 'complete') {
      await medplum.createResource({
        resourceType: 'Task',
        status: 'completed',
        intent: 'order',
        code: {
          coding: [{
            system: 'https://epa-bienestar.com.ar/fhir/CodeSystem/task-type',
            code: 'educational-content-access'
          }]
        },
        for: {
          reference: `Patient/${event.patientId}`
        },
        authoredOn: event.timestamp,
        input: [{
          type: { text: 'Content ID' },
          valueString: event.contentId
        }],
        output: event.metadata ? [{
          type: { text: 'Metadata' },
          valueString: JSON.stringify(event.metadata)
        }] : undefined
      });
    }
  }
  
  /**
   * Obtiene métricas de un contenido específico
   */
  async getContentMetrics(contentId: string): Promise<any> {
    const views = await redis.get(`analytics:content:${contentId}:view`) || '0';
    const clicks = await redis.get(`analytics:content:${contentId}:click`) || '0';
    const completes = await redis.get(`analytics:content:${contentId}:complete`) || '0';
    
    return {
      contentId,
      views: parseInt(views),
      clicks: parseInt(clicks),
      completes: parseInt(completes),
      completionRate: parseInt(clicks) > 0 
        ? (parseInt(completes) / parseInt(clicks)) * 100 
        : 0
    };
  }
  
  /**
   * Obtiene métricas de engagement de un paciente
   */
  async getPatientEngagement(patientId: string): Promise<any> {
    const totalEvents = await redis.get(`analytics:patient:${patientId}:total-events`) || '0';
    
    // Obtener últimos eventos del paciente
    const events = await redis.xrevrange(
      'analytics:events',
      '+',
      '-',
      'COUNT',
      100
    );
    
    const patientEvents = events
      .map(([id, fields]) => {
        const eventData = fields.find((f, i) => i % 2 === 0 && f === 'event');
        if (!eventData) return null;
        return JSON.parse(fields[fields.indexOf(eventData) + 1]);
      })
      .filter(e => e && e.patientId === patientId);
    
    return {
      patientId,
      totalEvents: parseInt(totalEvents),
      recentEvents: patientEvents.slice(0, 10),
      uniqueContents: new Set(patientEvents.map(e => e.contentId)).size
    };
  }
}

// Instanciar servicios
const contentService = new ContentService();
const analyticsService = new AnalyticsService();

// ============================================================================
// ENDPOINTS
// ============================================================================

/**
 * GET /api/health
 * Health check endpoint
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    redis: redis.status,
    medplum: 'connected'
  });
});

/**
 * GET /api/contents/:group
 * Obtiene contenidos para un grupo específico
 */
app.get('/api/contents/:group', authenticate, async (req, res) => {
  try {
    const { group } = req.params;
    const { category, maxItems } = req.query;
    const patientId = (req as any).user.id;
    
    if (!['A', 'B', 'C', 'D', 'ALL'].includes(group)) {
      return res.status(400).json({ error: 'Grupo inválido' });
    }
    
    const contents = await contentService.getContents(
      group,
      patientId,
      {
        category: category as string,
        maxItems: maxItems ? parseInt(maxItems as string) : undefined
      }
    );
    
    res.json(contents);
  } catch (error) {
    console.error('Error obteniendo contenidos:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

/**
 * POST /api/contents/:contentId/sync
 * Sincroniza un contenido con FHIR
 */
app.post('/api/contents/:contentId/sync', authenticate, async (req, res) => {
  try {
    const { contentId } = req.params;
    const patientId = (req as any).user.id;
    const contentData = req.body;
    
    const docRef = await contentService.syncToFHIR(
      { ...contentData, id: contentId },
      patientId
    );
    
    res.json({
      success: true,
      documentReference: docRef
    });
  } catch (error) {
    console.error('Error sincronizando con FHIR:', error);
    res.status(500).json({ error: 'Error en sincronización' });
  }
});

/**
 * POST /api/analytics/track
 * Registra un evento de analytics
 */
app.post('/api/analytics/track', authenticate, async (req, res) => {
  try {
    const event: AnalyticsEvent = {
      ...req.body,
      patientId: (req as any).user.id,
      timestamp: new Date().toISOString()
    };
    
    await analyticsService.trackEvent(event);
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error tracking event:', error);
    res.status(500).json({ error: 'Error registrando evento' });
  }
});

/**
 * GET /api/analytics/content/:contentId
 * Obtiene métricas de un contenido
 */
app.get('/api/analytics/content/:contentId', authenticate, async (req, res) => {
  try {
    const { contentId } = req.params;
    const metrics = await analyticsService.getContentMetrics(contentId);
    res.json(metrics);
  } catch (error) {
    console.error('Error obteniendo métricas:', error);
    res.status(500).json({ error: 'Error obteniendo métricas' });
  }
});

/**
 * GET /api/analytics/patient/:patientId/engagement
 * Obtiene engagement de un paciente
 */
app.get('/api/analytics/patient/:patientId/engagement', authenticate, async (req, res) => {
  try {
    const { patientId } = req.params;
    
    // Verificar que el usuario puede ver estos datos
    if ((req as any).user.id !== patientId && !(req as any).user.admin) {
      return res.status(403).json({ error: 'Acceso denegado' });
    }
    
    const engagement = await analyticsService.getPatientEngagement(patientId);
    res.json(engagement);
  } catch (error) {
    console.error('Error obteniendo engagement:', error);
    res.status(500).json({ error: 'Error obteniendo engagement' });
  }
});

// ============================================================================
// ERROR HANDLING
// ============================================================================

app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  console.error('Error no manejado:', err);
  res.status(500).json({
    error: 'Error interno del servidor',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// ============================================================================
// INICIO DEL SERVIDOR
// ============================================================================

async function startServer() {
  try {
    // Verificar conexión Redis
    await redis.ping();
    console.log('✅ Redis conectado');
    
    // Verificar conexión Medplum
    await medplum.get('metadata');
    console.log('✅ Medplum conectado');
    
    // Iniciar servidor
    app.listen(PORT, () => {
      console.log(`🚀 Servidor corriendo en puerto ${PORT}`);
      console.log(`📊 API disponible en http://localhost:${PORT}/api`);
    });
  } catch (error) {
    console.error('❌ Error iniciando servidor:', error);
    process.exit(1);
  }
}

// Manejar shutdown gracefully
process.on('SIGTERM', async () => {
  console.log('⚠️  SIGTERM recibido, cerrando servidor...');
  await redis.quit();
  process.exit(0);
});

// Iniciar
if (require.main === module) {
  startServer();
}

export { app, contentService, analyticsService };
