import { MedplumClient } from '@medplum/core';
import { Patient, DocumentReference, Task, Bundle } from '@medplum/fhirtypes';
import {
  ContentItem,
  LifeStageGroup,
  ContentCategory,
  ContentSearchFilters,
  PlatformContentResponse,
  EducationalDocumentReference,
  ContentAccessTask,
  UserEngagementMetrics,
  PersonalizedActionPlan
} from './types-platform-content';

/**
 * Servicio para gestionar contenidos educativos desde plataforma.epa-bienestar.com.ar
 * Maneja sincronización bidireccional con FHIR R4
 */
export class PlatformContentService {
  private medplum: MedplumClient;
  private baseUrl = 'https://plataforma.epa-bienestar.com.ar';

  constructor(medplum: MedplumClient) {
    this.medplum = medplum;
  }

  /**
   * Obtiene contenidos filtrados para un paciente específico
   */
  async getContentForPatient(
    patient: Patient,
    filters?: ContentSearchFilters
  ): Promise<PlatformContentResponse> {
    const group = this.determineLifeStageGroup(patient);
    
    // En producción, esto consultaría una API backend
    // Por ahora, filtramos del catálogo local
    let contents = await this.getAllContents();
    
    // Filtrar por grupo
    contents = contents.filter(
      c => c.targetGroup === group || c.targetGroup === 'ALL'
    );
    
    // Aplicar filtros adicionales
    if (filters?.category) {
      contents = contents.filter(c => c.category === filters.category);
    }
    
    if (filters?.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      contents = contents.filter(c =>
        c.title.toLowerCase().includes(term) ||
        c.description.toLowerCase().includes(term)
      );
    }
    
    if (filters?.minPriority) {
      contents = contents.filter(c => c.priority >= filters.minPriority);
    }
    
    // Ordenar por prioridad
    contents.sort((a, b) => a.priority - b.priority);
    
    // Limitar resultados
    const maxResults = filters?.maxResults || 6;
    const items = contents.slice(0, maxResults);
    
    // Obtener progreso del usuario
    const userProgress = await this.getUserProgress(patient.id!);
    
    return {
      items,
      totalCount: contents.length,
      filteredGroup: group,
      userProgress
    };
  }

  /**
   * Determina el grupo de vida según edad y contexto clínico
   * TODO: Implementar lógica más sofisticada consultando Observations y Conditions
   */
  private determineLifeStageGroup(patient: Patient): LifeStageGroup {
    if (!patient.birthDate) return 'A';
    
    const birthDate = new Date(patient.birthDate);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    if (age >= 18 && age < 28) return 'A';
    if (age >= 28 && age < 45) return 'B';
    if (age >= 45 && age < 65) return 'C';
    if (age >= 65) return 'D';
    
    return 'A';
  }

  /**
   * Sincroniza un contenido con FHIR DocumentReference
   */
  async syncContentToFHIR(
    content: ContentItem,
    patientId: string
  ): Promise<DocumentReference | null> {
    try {
      // Verificar si ya existe
      const existing = await this.medplum.searchOne('DocumentReference', {
        identifier: `${this.baseUrl}|${content.id}`,
        subject: `Patient/${patientId}`
      });

      if (existing) {
        return existing;
      }

      // Crear nuevo DocumentReference
      const docRef: EducationalDocumentReference = {
        resourceType: 'DocumentReference',
        status: 'current',
        docStatus: 'final',
        identifier: [{
          system: this.baseUrl,
          value: content.id
        }],
        subject: {
          reference: `Patient/${patientId}`
        },
        type: {
          coding: [{
            system: 'http://loinc.org',
            code: '81215-6',
            display: 'Care plan'
          }],
          text: 'Educational Content - EPA Bienestar'
        },
        category: [{
          coding: [{
            system: 'https://epa-bienestar.com.ar/fhir/CodeSystem/content-category',
            code: content.category,
            display: this.getCategoryDisplay(content.category)
          }]
        }],
        date: new Date().toISOString(),
        description: content.description,
        content: [{
          attachment: {
            contentType: 'text/html',
            url: content.url,
            title: content.title
          }
        }],
        // Extensiones personalizadas
        extension: [{
          url: 'https://epa-bienestar.com.ar/fhir/StructureDefinition/content-metadata',
          extension: [
            {
              url: 'targetGroup',
              valueString: content.targetGroup
            },
            {
              url: 'category',
              valueString: content.category
            },
            {
              url: 'priority',
              valueInteger: content.priority
            }
          ]
        }]
      };

      // Si el contenido está asociado a un PlanDefinition
      if (content.planDefinitionReference) {
        docRef.context = {
          related: [{
            reference: content.planDefinitionReference
          }]
        };
      }

      return await this.medplum.createResource(docRef);
    } catch (error) {
      console.error(`Error syncing content ${content.id}:`, error);
      return null;
    }
  }

  /**
   * Registra el acceso a un contenido
   */
  async trackContentAccess(
    content: ContentItem,
    patientId: string,
    metadata?: {
      timeSpent?: number;
      completed?: boolean;
    }
  ): Promise<Task | null> {
    try {
      const task: ContentAccessTask = {
        resourceType: 'Task',
        status: 'completed',
        intent: 'order',
        code: {
          coding: [{
            system: 'https://epa-bienestar.com.ar/fhir/CodeSystem/task-type',
            code: 'educational-content-access',
            display: 'Educational Content Access'
          }]
        },
        description: `Acceso a contenido: ${content.title}`,
        for: {
          reference: `Patient/${patientId}`
        },
        authoredOn: new Date().toISOString(),
        lastModified: new Date().toISOString(),
        input: [{
          type: {
            text: 'Content ID'
          },
          valueString: content.id
        }, {
          type: {
            text: 'Content Category'
          },
          valueString: content.category
        }]
      };

      // Agregar outputs si hay metadata
      if (metadata) {
        task.output = [];
        
        if (metadata.timeSpent) {
          task.output.push({
            type: {
              text: 'Time Spent (seconds)'
            },
            valueInteger: metadata.timeSpent
          });
        }
        
        if (metadata.completed !== undefined) {
          task.output.push({
            type: {
              text: 'Completed'
            },
            valueBoolean: metadata.completed
          });
        }
      }

      return await this.medplum.createResource(task);
    } catch (error) {
      console.error(`Error tracking content access for ${content.id}:`, error);
      return null;
    }
  }

  /**
   * Obtiene métricas de engagement del usuario
   */
  async getUserEngagementMetrics(patientId: string): Promise<UserEngagementMetrics> {
    try {
      // Buscar todas las Tasks de acceso a contenido
      const tasks = await this.medplum.searchResources('Task', {
        for: `Patient/${patientId}`,
        code: 'educational-content-access'
      });

      const totalContentViewed = tasks.length;
      let totalTimeSpent = 0;
      const categoryCount: Record<string, number> = {};

      tasks.forEach(task => {
        // Extraer tiempo gastado
        const timeOutput = task.output?.find(o => o.type.text === 'Time Spent (seconds)');
        if (timeOutput?.valueInteger) {
          totalTimeSpent += timeOutput.valueInteger;
        }

        // Contar categorías
        const categoryInput = task.input?.find(i => i.type.text === 'Content Category');
        if (categoryInput?.valueString) {
          const cat = categoryInput.valueString;
          categoryCount[cat] = (categoryCount[cat] || 0) + 1;
        }
      });

      // Ordenar categorías por frecuencia
      const favoriteCategories = Object.entries(categoryCount)
        .sort(([, a], [, b]) => b - a)
        .map(([cat]) => cat as ContentCategory);

      // Calcular completion rate
      const completedTasks = tasks.filter(t => {
        const completedOutput = t.output?.find(o => o.type.text === 'Completed');
        return completedOutput?.valueBoolean === true;
      });
      const completionRate = tasks.length > 0 
        ? (completedTasks.length / tasks.length) * 100 
        : 0;

      // Última fecha de actividad
      const lastActiveDate = tasks.length > 0
        ? tasks.reduce((latest, task) => {
            const taskDate = new Date(task.authoredOn || task.lastModified || '');
            return taskDate > latest ? taskDate : latest;
          }, new Date(0)).toISOString()
        : new Date().toISOString();

      return {
        patientId,
        totalContentViewed,
        totalTimeSpent: Math.round(totalTimeSpent / 60), // Convertir a minutos
        favoriteCategories,
        completionRate: Math.round(completionRate),
        lastActiveDate,
        streakDays: 0 // TODO: Implementar cálculo de racha
      };
    } catch (error) {
      console.error('Error getting user engagement metrics:', error);
      return {
        patientId,
        totalContentViewed: 0,
        totalTimeSpent: 0,
        favoriteCategories: [],
        completionRate: 0,
        lastActiveDate: new Date().toISOString(),
        streakDays: 0
      };
    }
  }

  /**
   * Obtiene el progreso del usuario en contenidos
   */
  private async getUserProgress(patientId: string) {
    try {
      const tasks = await this.medplum.searchResources('Task', {
        for: `Patient/${patientId}`,
        code: 'educational-content-access'
      });

      const completedItems: string[] = [];
      const inProgressItems: string[] = [];
      let totalTimeSpent = 0;

      tasks.forEach(task => {
        const contentIdInput = task.input?.find(i => i.type.text === 'Content ID');
        const contentId = contentIdInput?.valueString;
        
        if (!contentId) return;

        const completedOutput = task.output?.find(o => o.type.text === 'Completed');
        const timeOutput = task.output?.find(o => o.type.text === 'Time Spent (seconds)');

        if (completedOutput?.valueBoolean) {
          completedItems.push(contentId);
        } else {
          inProgressItems.push(contentId);
        }

        if (timeOutput?.valueInteger) {
          totalTimeSpent += timeOutput.valueInteger;
        }
      });

      return {
        completedItems: [...new Set(completedItems)],
        inProgressItems: [...new Set(inProgressItems)],
        totalTimeSpent: Math.round(totalTimeSpent / 60)
      };
    } catch (error) {
      console.error('Error getting user progress:', error);
      return {
        completedItems: [],
        inProgressItems: [],
        totalTimeSpent: 0
      };
    }
  }

  /**
   * Genera un plan de acción personalizado
   */
  async generatePersonalizedPlan(patient: Patient): Promise<PersonalizedActionPlan> {
    const group = this.determineLifeStageGroup(patient);
    const metrics = await this.getUserEngagementMetrics(patient.id!);
    const contents = await this.getContentForPatient(patient);

    // Determinar fase actual basada en categorías favoritas
    let currentPhase: 'habits' | 'emotions' | 'heart' | 'brain' = 'habits';
    if (metrics.favoriteCategories.length > 0) {
      currentPhase = metrics.favoriteCategories[0] as any;
    }

    // Calcular progreso
    const totalAvailableContent = contents.totalCount;
    const completedContent = contents.userProgress?.completedItems.length || 0;
    const progressPercentage = totalAvailableContent > 0
      ? Math.round((completedContent / totalAvailableContent) * 100)
      : 0;

    return {
      patientId: patient.id!,
      group,
      recommendedContents: contents.items.slice(0, 3),
      currentPhase,
      progressPercentage,
      nextMilestone: this.getNextMilestone(progressPercentage),
      estimatedCompletionDate: this.estimateCompletionDate(
        progressPercentage,
        metrics.totalTimeSpent
      )
    };
  }

  // ========== Métodos auxiliares ==========

  private getCategoryDisplay(category: ContentCategory): string {
    const displays: Record<ContentCategory, string> = {
      habits: 'Hábitos Saludables',
      emotions: 'Bienestar Emocional',
      heart: 'Salud Cardiovascular',
      brain: 'Salud Cerebral'
    };
    return displays[category];
  }

  private getNextMilestone(progressPercentage: number): string {
    if (progressPercentage < 25) return 'Completar fase de Hábitos';
    if (progressPercentage < 50) return 'Completar fase de Emociones';
    if (progressPercentage < 75) return 'Completar fase de Corazón';
    if (progressPercentage < 100) return 'Completar fase de Cerebro';
    return '¡Plan Bienestar 100 Días completado!';
  }

  private estimateCompletionDate(
    progressPercentage: number,
    totalTimeSpent: number
  ): string {
    // Estimación simple: si llevas X% en Y minutos, el total será...
    if (progressPercentage === 0) {
      // Estimado: 100 días
      const estimatedDate = new Date();
      estimatedDate.setDate(estimatedDate.getDate() + 100);
      return estimatedDate.toISOString().split('T')[0];
    }

    const remainingPercentage = 100 - progressPercentage;
    const estimatedRemainingMinutes = 
      (totalTimeSpent / progressPercentage) * remainingPercentage;
    
    // Asumiendo 30 minutos por día
    const estimatedDays = Math.ceil(estimatedRemainingMinutes / 30);
    
    const estimatedDate = new Date();
    estimatedDate.setDate(estimatedDate.getDate() + estimatedDays);
    
    return estimatedDate.toISOString().split('T')[0];
  }

  /**
   * Obtiene todos los contenidos disponibles
   * En producción, esto consultaría una API o base de datos
   */
  private async getAllContents(): Promise<ContentItem[]> {
    // Este catálogo debería venir de una API o configuración externa
    // Por ahora retornamos el catálogo hardcoded
    return []; // Implementar según necesidades
  }
}

/**
 * Hook de React para facilitar el uso del servicio
 */
export function usePlatformContent(medplum: MedplumClient) {
  const service = new PlatformContentService(medplum);
  
  return {
    getContentForPatient: service.getContentForPatient.bind(service),
    syncContentToFHIR: service.syncContentToFHIR.bind(service),
    trackContentAccess: service.trackContentAccess.bind(service),
    getUserEngagementMetrics: service.getUserEngagementMetrics.bind(service),
    generatePersonalizedPlan: service.generatePersonalizedPlan.bind(service)
  };
}
