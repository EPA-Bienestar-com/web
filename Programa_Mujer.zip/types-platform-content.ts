import { DocumentReference, Task, CodeableConcept, Reference } from '@medplum/fhirtypes';

/**
 * Grupos de segmentación de vida para FemTech
 * Basados en la estrategia de mercado de EPA Bienestar
 */
export type LifeStageGroup = 'A' | 'B' | 'C' | 'D' | 'ALL';

/**
 * Grupo A: Mujeres Jóvenes (18-30 años)
 * - Desarrollo académico y profesional
 * - Establecimiento de hábitos saludables
 * - Prevención primaria cardiovascular
 */
export interface GroupAProfile {
  ageRange: [18, 30];
  focus: ['academic', 'professional-development', 'health-habits'];
  riskFactors: ['sedentary-lifestyle', 'stress', 'poor-nutrition'];
}

/**
 * Grupo B: Mujeres Jóvenes (28-40 años)
 * - Planificación de maternidad
 * - Balance trabajo-vida personal
 * - Prevención preconcepcional
 */
export interface GroupBProfile {
  ageRange: [28, 40];
  focus: ['maternity-planning', 'career-advancement', 'preconception-health'];
  riskFactors: ['preeclampsia-risk', 'gestational-diabetes', 'work-stress'];
}

/**
 * Grupo C: Mujeres Adultas (45-65 años)
 * - Transición menopáusica
 * - Prevención cardiovascular intensiva
 * - Madres de hijos adultos
 */
export interface GroupCProfile {
  ageRange: [45, 65];
  focus: ['menopause-management', 'cardiovascular-prevention', 'professional-continuity'];
  riskFactors: ['hormonal-changes', 'hypertension', 'metabolic-syndrome'];
}

/**
 * Grupo D: Mujeres Adultas (65+ años)
 * - Tercera y cuarta edad activa
 * - Abuelas y emprendedoras
 * - Mantenimiento de vitalidad
 */
export interface GroupDProfile {
  ageRange: [65, number];
  focus: ['active-aging', 'brain-health', 'entrepreneurship'];
  riskFactors: ['cardiovascular-disease', 'cognitive-decline', 'mobility'];
}

/**
 * Categorías del Plan Bienestar 100 Días
 * Basadas en Life's Essential 8 de AHA
 */
export type ContentCategory = 
  | 'habits'      // Hábitos: alimentación, ejercicio, sueño
  | 'emotions'    // Emociones: estrés, salud mental, bienestar
  | 'heart'       // Corazón: prevención cardiovascular, métricas
  | 'brain';      // Cerebro: salud cognitiva, prevención demencia

/**
 * Item de contenido educativo desde plataforma
 */
export interface ContentItem {
  id: string;
  title: string;
  description: string;
  url: string;
  imageUrl?: string;
  targetGroup: LifeStageGroup;
  category: ContentCategory;
  priority: number;
  
  // Metadatos adicionales
  duration?: number;           // Duración estimada en minutos
  completionRate?: number;     // % de usuarias que completan
  engagementScore?: number;    // Score de engagement
  lastUpdated?: string;        // Última actualización del contenido
  
  // FHIR references
  planDefinitionReference?: string;    // PlanDefinition relacionado
  activityDefinitionReference?: string; // ActivityDefinition relacionado
}

/**
 * Configuración de contenido para un grupo específico
 */
export interface GroupContentConfig {
  group: LifeStageGroup;
  priorityTopics: string[];
  maxItemsToDisplay: number;
  refreshInterval?: number; // Milisegundos
}

/**
 * Extended DocumentReference para contenido educativo
 * Incluye metadatos específicos de EPA Bienestar
 */
export interface EducationalDocumentReference extends DocumentReference {
  // Campos base de DocumentReference
  identifier?: Array<{
    system: 'https://plataforma.epa-bienestar.com.ar' | string;
    value: string;
  }>;
  
  // Extensiones personalizadas
  extension?: Array<{
    url: 'https://epa-bienestar.com.ar/fhir/StructureDefinition/content-metadata';
    extension: Array<{
      url: 'targetGroup' | 'category' | 'priority' | 'engagementScore';
      valueString?: string;
      valueInteger?: number;
    }>;
  }>;
}

/**
 * Task para tracking de acceso a contenidos
 */
export interface ContentAccessTask extends Task {
  code: {
    coding: [{
      system: 'https://epa-bienestar.com.ar/fhir/CodeSystem/task-type';
      code: 'educational-content-access';
      display: 'Educational Content Access';
    }];
  };
  
  input?: Array<{
    type: CodeableConcept;
    valueString?: string; // Content ID
    valueReference?: Reference; // DocumentReference
  }>;
  
  output?: Array<{
    type: CodeableConcept;
    valueInteger?: number; // Tiempo de lectura en segundos
    valueBoolean?: boolean; // ¿Completó el contenido?
  }>;
}

/**
 * Estructura de respuesta de la API de contenidos
 */
export interface PlatformContentResponse {
  items: ContentItem[];
  totalCount: number;
  filteredGroup: LifeStageGroup;
  recommendedNextSteps?: string[];
  userProgress?: {
    completedItems: string[];
    inProgressItems: string[];
    totalTimeSpent: number; // minutos
  };
}

/**
 * Filtros para búsqueda de contenidos
 */
export interface ContentSearchFilters {
  group?: LifeStageGroup;
  category?: ContentCategory;
  searchTerm?: string;
  minPriority?: number;
  maxResults?: number;
}

/**
 * Analytics de contenido
 */
export interface ContentAnalytics {
  contentId: string;
  views: number;
  completions: number;
  averageTimeSpent: number;
  userSatisfaction?: number; // 1-5
  returnVisits: number;
}

/**
 * User engagement metrics
 */
export interface UserEngagementMetrics {
  patientId: string;
  totalContentViewed: number;
  totalTimeSpent: number;
  favoriteCategories: ContentCategory[];
  completionRate: number;
  lastActiveDate: string;
  streakDays: number; // Días consecutivos con actividad
}

/**
 * Plan de acción personalizado
 */
export interface PersonalizedActionPlan {
  patientId: string;
  group: LifeStageGroup;
  recommendedContents: ContentItem[];
  currentPhase: 'habits' | 'emotions' | 'heart' | 'brain';
  progressPercentage: number;
  nextMilestone: string;
  estimatedCompletionDate: string;
}
