/**
 * DATOS DE PRUEBA - Life's Essential 8
 * EPA Bienestar - Programa Mujer
 * 
 * Este archivo contiene ejemplos de recursos FHIR R4 para testing del Dashboard
 */

// ============================================================================
// EJEMPLO 1: Patient Resource
// ============================================================================

export const EXAMPLE_PATIENT = {
  resourceType: 'Patient',
  id: 'patient-test-001',
  meta: {
    versionId: '1',
    lastUpdated: '2025-01-05T10:00:00Z',
  },
  identifier: [
    {
      system: 'urn:oid:2.16.840.1.113883.2.49.3',
      value: '12345678',
      type: {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/v2-0203',
            code: 'NI',
            display: 'National identifier',
          },
        ],
      },
    },
  ],
  active: true,
  name: [
    {
      use: 'official',
      family: 'González',
      given: ['María', 'Laura'],
    },
  ],
  gender: 'female',
  birthDate: '1990-05-15', // 34 años - Grupo B
  address: [
    {
      use: 'home',
      line: ['Av. Corrientes 1234'],
      city: 'Buenos Aires',
      state: 'CABA',
      postalCode: '1043',
      country: 'AR',
    },
  ],
  telecom: [
    {
      system: 'phone',
      value: '+54 11 1234-5678',
      use: 'mobile',
    },
    {
      system: 'email',
      value: 'maria.gonzalez@example.com',
    },
  ],
};

// ============================================================================
// EJEMPLO 2: Observations para Life's Essential 8
// ============================================================================

// Dieta Mediterránea (MEPA Score)
export const OBSERVATION_DIET = {
  resourceType: 'Observation',
  id: 'obs-diet-001',
  status: 'final',
  category: [
    {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/observation-category',
          code: 'survey',
          display: 'Survey',
        },
      ],
    },
  ],
  code: {
    coding: [
      {
        system: 'http://loinc.org',
        code: '8689-2',
        display: 'Mediterranean Diet Score',
      },
    ],
    text: 'Score de Dieta Mediterránea (MEPA)',
  },
  subject: {
    reference: 'Patient/patient-test-001',
  },
  effectiveDateTime: '2025-01-05T09:00:00Z',
  issued: '2025-01-05T09:00:00Z',
  valueQuantity: {
    value: 75,
    unit: 'score',
    system: 'http://unitsofmeasure.org',
    code: '{score}',
  },
  interpretation: [
    {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation',
          code: 'N',
          display: 'Normal',
        },
      ],
    },
  ],
};

// Actividad Física
export const OBSERVATION_ACTIVITY = {
  resourceType: 'Observation',
  id: 'obs-activity-001',
  status: 'final',
  category: [
    {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/observation-category',
          code: 'activity',
          display: 'Activity',
        },
      ],
    },
  ],
  code: {
    coding: [
      {
        system: 'http://loinc.org',
        code: '82290-8',
        display: 'Physical activity score',
      },
    ],
    text: 'Score de Actividad Física',
  },
  subject: {
    reference: 'Patient/patient-test-001',
  },
  effectiveDateTime: '2025-01-05T09:00:00Z',
  valueQuantity: {
    value: 85,
    unit: 'score',
    system: 'http://unitsofmeasure.org',
    code: '{score}',
  },
};

// Exposición a Nicotina
export const OBSERVATION_NICOTINE = {
  resourceType: 'Observation',
  id: 'obs-nicotine-001',
  status: 'final',
  code: {
    coding: [
      {
        system: 'http://loinc.org',
        code: '72166-2',
        display: 'Tobacco smoking status',
      },
    ],
    text: 'Estado de Tabaquismo',
  },
  subject: {
    reference: 'Patient/patient-test-001',
  },
  effectiveDateTime: '2025-01-05T09:00:00Z',
  valueQuantity: {
    value: 100, // Nunca fumó
    unit: 'score',
    system: 'http://unitsofmeasure.org',
    code: '{score}',
  },
};

// Sueño
export const OBSERVATION_SLEEP = {
  resourceType: 'Observation',
  id: 'obs-sleep-001',
  status: 'final',
  code: {
    coding: [
      {
        system: 'http://loinc.org',
        code: '93832-4',
        display: 'Sleep health score',
      },
    ],
    text: 'Score de Salud del Sueño',
  },
  subject: {
    reference: 'Patient/patient-test-001',
  },
  effectiveDateTime: '2025-01-05T09:00:00Z',
  valueQuantity: {
    value: 70,
    unit: 'score',
    system: 'http://unitsofmeasure.org',
    code: '{score}',
  },
};

// IMC (Body Mass Index)
export const OBSERVATION_BMI = {
  resourceType: 'Observation',
  id: 'obs-bmi-001',
  status: 'final',
  category: [
    {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/observation-category',
          code: 'vital-signs',
          display: 'Vital Signs',
        },
      ],
    },
  ],
  code: {
    coding: [
      {
        system: 'http://loinc.org',
        code: '39156-5',
        display: 'Body mass index (BMI) [Ratio]',
      },
    ],
    text: 'Índice de Masa Corporal',
  },
  subject: {
    reference: 'Patient/patient-test-001',
  },
  effectiveDateTime: '2025-01-05T09:00:00Z',
  valueQuantity: {
    value: 80, // Score 0-100 (no el IMC real)
    unit: 'score',
    system: 'http://unitsofmeasure.org',
    code: '{score}',
  },
};

// Lípidos (Non-HDL Cholesterol)
export const OBSERVATION_LIPIDS = {
  resourceType: 'Observation',
  id: 'obs-lipids-001',
  status: 'final',
  category: [
    {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/observation-category',
          code: 'laboratory',
          display: 'Laboratory',
        },
      ],
    },
  ],
  code: {
    coding: [
      {
        system: 'http://loinc.org',
        code: '43396-1',
        display: 'Cholesterol non HDL [Mass/volume] in Serum or Plasma',
      },
    ],
    text: 'Colesterol No-HDL',
  },
  subject: {
    reference: 'Patient/patient-test-001',
  },
  effectiveDateTime: '2025-01-04T08:30:00Z',
  valueQuantity: {
    value: 65,
    unit: 'score',
    system: 'http://unitsofmeasure.org',
    code: '{score}',
  },
};

// Glucosa
export const OBSERVATION_GLUCOSE = {
  resourceType: 'Observation',
  id: 'obs-glucose-001',
  status: 'final',
  category: [
    {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/observation-category',
          code: 'laboratory',
          display: 'Laboratory',
        },
      ],
    },
  ],
  code: {
    coding: [
      {
        system: 'http://loinc.org',
        code: '2339-0',
        display: 'Glucose [Mass/volume] in Blood',
      },
    ],
    text: 'Glucosa en Sangre',
  },
  subject: {
    reference: 'Patient/patient-test-001',
  },
  effectiveDateTime: '2025-01-04T08:30:00Z',
  valueQuantity: {
    value: 90,
    unit: 'score',
    system: 'http://unitsofmeasure.org',
    code: '{score}',
  },
};

// Presión Arterial Sistólica
export const OBSERVATION_BP_SYSTOLIC = {
  resourceType: 'Observation',
  id: 'obs-bp-systolic-001',
  status: 'final',
  category: [
    {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/observation-category',
          code: 'vital-signs',
          display: 'Vital Signs',
        },
      ],
    },
  ],
  code: {
    coding: [
      {
        system: 'http://loinc.org',
        code: '8480-6',
        display: 'Systolic blood pressure',
      },
    ],
    text: 'Presión Arterial Sistólica',
  },
  subject: {
    reference: 'Patient/patient-test-001',
  },
  effectiveDateTime: '2025-01-05T09:00:00Z',
  valueQuantity: {
    value: 85, // Score calculado, no mmHg real
    unit: 'score',
    system: 'http://unitsofmeasure.org',
    code: '{score}',
  },
};

// Presión Arterial Diastólica
export const OBSERVATION_BP_DIASTOLIC = {
  resourceType: 'Observation',
  id: 'obs-bp-diastolic-001',
  status: 'final',
  category: [
    {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/observation-category',
          code: 'vital-signs',
          display: 'Vital Signs',
        },
      ],
    },
  ],
  code: {
    coding: [
      {
        system: 'http://loinc.org',
        code: '8462-4',
        display: 'Diastolic blood pressure',
      },
    ],
    text: 'Presión Arterial Diastólica',
  },
  subject: {
    reference: 'Patient/patient-test-001',
  },
  effectiveDateTime: '2025-01-05T09:00:00Z',
  valueQuantity: {
    value: 85,
    unit: 'score',
    system: 'http://unitsofmeasure.org',
    code: '{score}',
  },
};

// ============================================================================
// SCRIPT PARA CARGAR DATOS DE PRUEBA EN MEDPLUM
// ============================================================================

/**
 * Función para cargar todos los datos de prueba en Medplum
 * Ejecutar desde la consola del navegador o desde un script Node.js
 */
export async function loadTestDataToMedplum(medplum: any) {
  try {
    console.log('🚀 Iniciando carga de datos de prueba...');

    // 1. Crear/Actualizar Patient
    const patient = await medplum.createResource(EXAMPLE_PATIENT);
    console.log('✅ Patient creado:', patient.id);

    // 2. Crear todas las Observations
    const observations = [
      OBSERVATION_DIET,
      OBSERVATION_ACTIVITY,
      OBSERVATION_NICOTINE,
      OBSERVATION_SLEEP,
      OBSERVATION_BMI,
      OBSERVATION_LIPIDS,
      OBSERVATION_GLUCOSE,
      OBSERVATION_BP_SYSTOLIC,
      OBSERVATION_BP_DIASTOLIC,
    ];

    for (const obs of observations) {
      const created = await medplum.createResource(obs);
      console.log(`✅ Observation creada: ${obs.code.text}`);
    }

    console.log('🎉 Todos los datos de prueba cargados exitosamente!');
    console.log(`📊 Score LE8 esperado: ~80 (Excelente)`);

    return patient.id;
  } catch (error) {
    console.error('❌ Error cargando datos de prueba:', error);
    throw error;
  }
}

// ============================================================================
// SCRIPT PARA TESTING MANUAL
// ============================================================================

/**
 * Cómo usar estos datos de prueba:
 * 
 * 1. Desde la consola del navegador en https://mujer.epa-bienestar.com.ar:
 * 
 *    import { loadTestDataToMedplum } from './testData';
 *    import { useMedplum } from '@medplum/react';
 *    
 *    const medplum = useMedplum();
 *    loadTestDataToMedplum(medplum).then(patientId => {
 *      console.log('Patient ID:', patientId);
 *      window.location.href = '/dashboard';
 *    });
 * 
 * 2. O crear un script separado para ejecutar con ts-node:
 * 
 *    npx ts-node scripts/loadTestData.ts
 * 
 * 3. Los scores esperados son:
 *    - Dieta: 75 (Intermedio)
 *    - Actividad: 85 (Excelente)
 *    - Nicotina: 100 (Excelente)
 *    - Sueño: 70 (Intermedio)
 *    - IMC: 80 (Excelente)
 *    - Lípidos: 65 (Intermedio)
 *    - Glucosa: 90 (Excelente)
 *    - Presión Arterial: 85 (Excelente)
 *    - SCORE GLOBAL: ~81 (Excelente)
 */

// ============================================================================
// DATOS ADICIONALES: Diferentes Escenarios
// ============================================================================

// Escenario 2: Paciente con scores bajos (necesita atención)
export const LOW_SCORES_OBSERVATIONS = {
  diet: { ...OBSERVATION_DIET, valueQuantity: { ...OBSERVATION_DIET.valueQuantity, value: 30 } },
  activity: { ...OBSERVATION_ACTIVITY, valueQuantity: { ...OBSERVATION_ACTIVITY.valueQuantity, value: 25 } },
  nicotine: { ...OBSERVATION_NICOTINE, valueQuantity: { ...OBSERVATION_NICOTINE.valueQuantity, value: 0 } },
  sleep: { ...OBSERVATION_SLEEP, valueQuantity: { ...OBSERVATION_SLEEP.valueQuantity, value: 40 } },
};

// Escenario 3: Paciente con scores intermedios
export const MEDIUM_SCORES_OBSERVATIONS = {
  diet: { ...OBSERVATION_DIET, valueQuantity: { ...OBSERVATION_DIET.valueQuantity, value: 60 } },
  activity: { ...OBSERVATION_ACTIVITY, valueQuantity: { ...OBSERVATION_ACTIVITY.valueQuantity, value: 55 } },
  nicotine: { ...OBSERVATION_NICOTINE, valueQuantity: { ...OBSERVATION_NICOTINE.valueQuantity, value: 75 } },
  sleep: { ...OBSERVATION_SLEEP, valueQuantity: { ...OBSERVATION_SLEEP.valueQuantity, value: 65 } },
};

console.log('📦 Datos de prueba cargados y listos para usar');
