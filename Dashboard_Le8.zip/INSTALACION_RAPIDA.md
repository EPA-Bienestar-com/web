# 🚀 Guía de Instalación Rápida - Dashboard LE8

## Pasos de Instalación

### 1️⃣ Copiar archivos al proyecto

Copia los archivos en las siguientes ubicaciones de tu proyecto `mujer`:

```bash
# Desde la carpeta donde descargaste los archivos

# Tipos
cp types/le8.types.ts ../mujer/src/types/

# Servicios
cp services/le8Service.ts ../mujer/src/services/

# Componentes
cp components/HGraphVisualization.tsx ../mujer/src/components/

# Páginas
cp pages/DashboardPage.tsx ../mujer/src/pages/
```

### 2️⃣ Modificar App.tsx

Abre `src/App.tsx` y agrega:

```tsx
// Al inicio, con los otros imports
import { DashboardPage } from './pages/DashboardPage';

// Dentro de <Routes>, agrega esta ruta
<Route 
  path="/dashboard" 
  element={
    <RequireAuth>
      <DashboardPage />
    </RequireAuth>
  } 
/>
```

### 3️⃣ Agregar enlace en navegación

En tu componente de navegación (probablemente en `LandingPage.tsx` o un componente `Header`):

```tsx
<Link 
  to="/dashboard" 
  className="nav-link"
>
  Dashboard
</Link>
```

### 4️⃣ Verificar dependencias

Asegúrate de tener instalado:

```bash
npm install @medplum/core @medplum/react @medplum/fhirtypes
```

### 5️⃣ Probar con datos de ejemplo

Usa el archivo `examples/testData.ts` para cargar datos de prueba:

```typescript
import { loadTestDataToMedplum } from './examples/testData';

// En tu aplicación
const medplum = useMedplum();
await loadTestDataToMedplum(medplum);
```

### 6️⃣ Iniciar la aplicación

```bash
npm run dev
```

Navega a: `http://localhost:5173/dashboard`

## ✅ Checklist de Instalación

- [ ] Archivos copiados en las carpetas correctas
- [ ] App.tsx modificado con la nueva ruta
- [ ] Navegación actualizada con enlace al Dashboard
- [ ] Dependencias verificadas/instaladas
- [ ] Datos de prueba cargados en Medplum
- [ ] Dashboard funcionando correctamente

## 🐛 Problemas Comunes

### El Dashboard no carga

**Solución**: Verifica que el usuario esté autenticado y que el `patientId` sea correcto.

### No se muestran las métricas

**Solución**: Asegúrate de tener Observations con los códigos LOINC correctos en Medplum.

### Errores de TypeScript

**Solución**: Verifica que todas las importaciones estén correctas y que los tipos de `@medplum/fhirtypes` estén instalados.

## 📞 Soporte

Si tienes problemas, revisa:
1. `docs/DASHBOARD_README.md` - Documentación completa
2. `examples/App.integration.example.tsx` - Ejemplo de integración
3. `examples/testData.ts` - Datos de prueba

---

¡Dashboard instalado! 🎉
