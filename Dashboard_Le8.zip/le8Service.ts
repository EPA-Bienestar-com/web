/**
 * Life's Essential 8 Service
 * EPA Bienestar - Programa Mujer
 * Servicio para interactuar con Medplum FHIR R4 API
 */

import { MedplumClient } from '@medplum/core';
import { Observation, Patient } from '@medplum/fhirtypes';
import {
  LE8_LOINC_CODES,
  LifeEssential8Data,
  LE8Metric,
  LifeStageGroup,
  calculateLifeStageGroup,
  getScoreCategory,
  LE8_METRIC_NAMES,
  HGraphData,
  HGraphDataPoint,
  LE8_COLORS,
} from '../types/le8.types';

/**
 * Obtiene la observación más reciente para un código LOINC específico
 */
async function getLatestObservation(
  medplum: MedplumClient,
  patientId: string,
  loincCode: string
): Promise<Observation | null> {
  try {
    const response = await medplum.searchResources('Observation', {
      patient: `Patient/${patientId}`,
      code: `http://loinc.org|${loincCode}`,
      _sort: '-date',
      _count: '1',
    });

    return response.length > 0 ? response[0] : null;
  } catch (error) {
    console.error(`Error fetching observation for LOINC ${loincCode}:`, error);
    return null;
  }
}

/**
 * Convierte una Observation FHIR a LE8Metric
 */
function observationToMetric(
  observation: Observation | null,
  name: string
): LE8Metric | null {
  if (!observation || !observation.valueQuantity) {
    return null;
  }

  const value = observation.valueQuantity.value || 0;
  const unit = observation.valueQuantity.unit || '';
  const date = observation.effectiveDateTime 
    ? new Date(observation.effectiveDateTime)
    : new Date();

  return {
    code: observation.code?.coding?.[0]?.code || '',
    name,
    value: Math.min(100, Math.max(0, value)), // Asegurar rango 0-100
    unit,
    lastUpdated: date,
    category: getScoreCategory(value),
    resourceId: observation.id,
  };
}

/**
 * Calcula el score combinado de presión arterial según criterios AHA
 * Combina sistólica y diastólica en un único score
 */
function calculateBloodPressureScore(
  systolic: number | null,
  diastolic: number | null
): number | null {
  if (systolic === null || diastolic === null) return null;

  // Lógica simplificada - ajustar según criterios AHA exactos
  // Óptima: <120/<80 = 100 puntos
  // Normal: 120-129/<80 = 75 puntos
  // Elevada: 130-139/80-89 = 50 puntos
  // HTA Stage 1: 140-159/90-99 = 25 puntos
  // HTA Stage 2: ≥160/≥100 = 0 puntos

  if (systolic < 120 && diastolic < 80) return 100;
  if (systolic < 130 && diastolic < 80) return 75;
  if (systolic < 140 && diastolic < 90) return 50;
  if (systolic < 160 && diastolic < 100) return 25;
  return 0;
}

/**
 * Obtiene todos los datos de Life's Essential 8 para un paciente
 */
export async function getLifeEssential8Data(
  medplum: MedplumClient,
  patientId: string
): Promise<LifeEssential8Data> {
  try {
    // Obtener información del paciente para calcular grupo
    const patient = await medplum.readResource('Patient', patientId);
    const lifeStageGroup = patient.birthDate
      ? calculateLifeStageGroup(patient.birthDate)
      : LifeStageGroup.A;

    // Obtener todas las observaciones en paralelo
    const [
      dietObs,
      activityObs,
      nicotineObs,
      sleepObs,
      bmiObs,
      lipidsObs,
      glucoseObs,
      systolicObs,
      diastolicObs,
    ] = await Promise.all([
      getLatestObservation(medplum, patientId, LE8_LOINC_CODES.DIET),
      getLatestObservation(medplum, patientId, LE8_LOINC_CODES.ACTIVITY),
      getLatestObservation(medplum, patientId, LE8_LOINC_CODES.NICOTINE),
      getLatestObservation(medplum, patientId, LE8_LOINC_CODES.SLEEP),
      getLatestObservation(medplum, patientId, LE8_LOINC_CODES.BMI),
      getLatestObservation(medplum, patientId, LE8_LOINC_CODES.LIPIDS),
      getLatestObservation(medplum, patientId, LE8_LOINC_CODES.GLUCOSE),
      getLatestObservation(medplum, patientId, LE8_LOINC_CODES.BP_SYSTOLIC),
      getLatestObservation(medplum, patientId, LE8_LOINC_CODES.BP_DIASTOLIC),
    ]);

    // Convertir observaciones a métricas
    const diet = observationToMetric(dietObs, LE8_METRIC_NAMES.diet);
    const activity = observationToMetric(activityObs, LE8_METRIC_NAMES.activity);
    const nicotine = observationToMetric(nicotineObs, LE8_METRIC_NAMES.nicotine);
    const sleep = observationToMetric(sleepObs, LE8_METRIC_NAMES.sleep);
    const bmi = observationToMetric(bmiObs, LE8_METRIC_NAMES.bmi);
    const lipids = observationToMetric(lipidsObs, LE8_METRIC_NAMES.lipids);
    const glucose = observationToMetric(glucoseObs, LE8_METRIC_NAMES.glucose);
    const systolic = observationToMetric(systolicObs, 'Presión Sistólica');
    const diastolic = observationToMetric(diastolicObs, 'Presión Diastólica');

    // Calcular score combinado de presión arterial
    const combinedBPScore = calculateBloodPressureScore(
      systolic?.value || null,
      diastolic?.value || null
    );

    // Calcular score global (promedio de las 8 métricas)
    const scores = [
      diet?.value,
      activity?.value,
      nicotine?.value,
      sleep?.value,
      bmi?.value,
      lipids?.value,
      glucose?.value,
      combinedBPScore,
    ].filter((score): score is number => score !== null && score !== undefined);

    const overallScore = scores.length > 0
      ? Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length)
      : null;

    // Encontrar la última fecha de actualización
    const dates = [
      diet?.lastUpdated,
      activity?.lastUpdated,
      nicotine?.lastUpdated,
      sleep?.lastUpdated,
      bmi?.lastUpdated,
      lipids?.lastUpdated,
      glucose?.lastUpdated,
      systolic?.lastUpdated,
      diastolic?.lastUpdated,
    ].filter((date): date is Date => date !== null && date !== undefined);

    const lastUpdated = dates.length > 0
      ? new Date(Math.max(...dates.map(d => d.getTime())))
      : null;

    return {
      patientId,
      lifeStageGroup,
      metrics: {
        diet,
        activity,
        nicotine,
        sleep,
        bmi,
        lipids,
        glucose,
        bloodPressure: {
          systolic,
          diastolic,
          combinedScore: combinedBPScore,
        },
      },
      overallScore,
      overallCategory: overallScore !== null ? getScoreCategory(overallScore) : null,
      lastUpdated,
    };
  } catch (error) {
    console.error('Error fetching Life\'s Essential 8 data:', error);
    throw error;
  }
}

/**
 * Convierte datos LE8 al formato requerido por HGraph
 */
export function convertToHGraphData(le8Data: LifeEssential8Data): HGraphData {
  const dataPoints: HGraphDataPoint[] = [
    {
      label: LE8_METRIC_NAMES.diet,
      value: le8Data.metrics.diet?.value || 0,
      maxValue: 100,
      color: LE8_COLORS.diet,
    },
    {
      label: LE8_METRIC_NAMES.activity,
      value: le8Data.metrics.activity?.value || 0,
      maxValue: 100,
      color: LE8_COLORS.activity,
    },
    {
      label: LE8_METRIC_NAMES.nicotine,
      value: le8Data.metrics.nicotine?.value || 0,
      maxValue: 100,
      color: LE8_COLORS.nicotine,
    },
    {
      label: LE8_METRIC_NAMES.sleep,
      value: le8Data.metrics.sleep?.value || 0,
      maxValue: 100,
      color: LE8_COLORS.sleep,
    },
    {
      label: LE8_METRIC_NAMES.bmi,
      value: le8Data.metrics.bmi?.value || 0,
      maxValue: 100,
      color: LE8_COLORS.bmi,
    },
    {
      label: LE8_METRIC_NAMES.lipids,
      value: le8Data.metrics.lipids?.value || 0,
      maxValue: 100,
      color: LE8_COLORS.lipids,
    },
    {
      label: LE8_METRIC_NAMES.glucose,
      value: le8Data.metrics.glucose?.value || 0,
      maxValue: 100,
      color: LE8_COLORS.glucose,
    },
    {
      label: LE8_METRIC_NAMES.bloodPressure,
      value: le8Data.metrics.bloodPressure.combinedScore || 0,
      maxValue: 100,
      color: LE8_COLORS.bloodPressure,
    },
  ];

  return {
    dataPoints,
    centerScore: le8Data.overallScore || 0,
    centerLabel: 'Score LE8',
  };
}

/**
 * Obtiene el mensaje motivacional según el grupo y score
 */
export function getMotivationalMessage(
  group: LifeStageGroup,
  score: number
): string {
  const category = getScoreCategory(score);

  const messages: Record<LifeStageGroup, Record<string, string>> = {
    [LifeStageGroup.A]: {
      high: '¡Excelente! Estás construyendo bases sólidas para tu salud cardiovascular.',
      intermediate: 'Buen progreso. Pequeños cambios diarios te llevarán al siguiente nivel.',
      poor: 'Este es tu punto de partida. Cada paso cuenta en tu camino al bienestar.',
    },
    [LifeStageGroup.B]: {
      high: '¡Fantástico! Tu corazón está listo para esta etapa de planificación.',
      intermediate: 'Vas bien. Optimizar tu salud cardiovascular beneficia tu futura maternidad.',
      poor: 'Es el momento ideal para fortalecer tu salud cardiovascular.',
    },
    [LifeStageGroup.C]: {
      high: '¡Admirable! Estás manejando esta transición con excelencia cardiovascular.',
      intermediate: 'En el camino correcto. La menopausia es una oportunidad para optimizar tu salud.',
      poor: 'Tu salud cardiovascular merece atención especial en esta etapa.',
    },
    [LifeStageGroup.D]: {
      high: '¡Inspirador! Eres un ejemplo de vitalidad y cuidado cardiovascular.',
      intermediate: 'Continúa así. Tu corazón te agradece cada esfuerzo.',
      poor: 'Nunca es tarde para cuidar tu corazón y disfrutar la vida plenamente.',
    },
  };

  return messages[group][category];
}
