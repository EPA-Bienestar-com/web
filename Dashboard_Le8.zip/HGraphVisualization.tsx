/**
 * HGraph Visualization Component
 * EPA Bienestar - Programa Mujer
 * Componente de visualización radial para Life's Essential 8
 */

import React, { useMemo } from 'react';
import { HGraphData, HGraphDataPoint } from '../types/le8.types';

interface HGraphVisualizationProps {
  data: HGraphData;
  size?: number;
  className?: string;
}

export const HGraphVisualization: React.FC<HGraphVisualizationProps> = ({
  data,
  size = 400,
  className = '',
}) => {
  const radius = size / 2 - 60; // Radio del gráfico
  const centerX = size / 2;
  const centerY = size / 2;

  // Calcular puntos del polígono para cada métrica
  const polygonPoints = useMemo(() => {
    const points = data.dataPoints.map((point, index) => {
      const angle = (index * 2 * Math.PI) / data.dataPoints.length - Math.PI / 2;
      const normalizedValue = point.value / point.maxValue;
      const x = centerX + radius * normalizedValue * Math.cos(angle);
      const y = centerY + radius * normalizedValue * Math.sin(angle);
      return { x, y };
    });
    return points;
  }, [data.dataPoints, centerX, centerY, radius]);

  // Generar path del polígono
  const polygonPath = useMemo(() => {
    if (polygonPoints.length === 0) return '';
    const pathCommands = polygonPoints.map((point, index) => {
      const command = index === 0 ? 'M' : 'L';
      return `${command} ${point.x},${point.y}`;
    });
    pathCommands.push('Z'); // Cerrar el path
    return pathCommands.join(' ');
  }, [polygonPoints]);

  // Calcular categoría de color según score
  const getCategoryColor = (score: number): string => {
    if (score >= 80) return 'text-green-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getCategoryBgColor = (score: number): string => {
    if (score >= 80) return 'bg-green-100';
    if (score >= 50) return 'bg-yellow-100';
    return 'bg-red-100';
  };

  const getCategoryLabel = (score: number): string => {
    if (score >= 80) return 'Excelente';
    if (score >= 50) return 'Intermedio';
    return 'Necesita Atención';
  };

  return (
    <div className={`flex flex-col items-center ${className}`}>
      {/* SVG del HGraph */}
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="drop-shadow-lg"
      >
        {/* Círculos de referencia (fondo) */}
        {[0.25, 0.5, 0.75, 1].map((fraction, idx) => (
          <circle
            key={`ref-circle-${idx}`}
            cx={centerX}
            cy={centerY}
            r={radius * fraction}
            fill="none"
            stroke="#e5e7eb"
            strokeWidth="1"
            strokeDasharray="4 4"
          />
        ))}

        {/* Líneas radiales hacia cada métrica */}
        {data.dataPoints.map((_, index) => {
          const angle = (index * 2 * Math.PI) / data.dataPoints.length - Math.PI / 2;
          const x = centerX + radius * Math.cos(angle);
          const y = centerY + radius * Math.sin(angle);
          return (
            <line
              key={`radial-${index}`}
              x1={centerX}
              y1={centerY}
              x2={x}
              y2={y}
              stroke="#e5e7eb"
              strokeWidth="1"
            />
          );
        })}

        {/* Polígono de datos */}
        <path
          d={polygonPath}
          fill="rgba(59, 130, 246, 0.3)"
          stroke="rgba(59, 130, 246, 0.8)"
          strokeWidth="2"
          strokeLinejoin="round"
        />

        {/* Puntos en cada vértice del polígono */}
        {polygonPoints.map((point, index) => (
          <circle
            key={`point-${index}`}
            cx={point.x}
            cy={point.y}
            r="4"
            fill={data.dataPoints[index].color || '#3b82f6'}
            stroke="white"
            strokeWidth="2"
            className="cursor-pointer hover:r-6 transition-all"
          />
        ))}

        {/* Etiquetas de cada métrica */}
        {data.dataPoints.map((point, index) => {
          const angle = (index * 2 * Math.PI) / data.dataPoints.length - Math.PI / 2;
          const labelRadius = radius + 30;
          const x = centerX + labelRadius * Math.cos(angle);
          const y = centerY + labelRadius * Math.sin(angle);

          // Ajustar alineación del texto según posición
          let textAnchor: 'start' | 'middle' | 'end' = 'middle';
          if (x < centerX - 10) textAnchor = 'end';
          if (x > centerX + 10) textAnchor = 'start';

          return (
            <g key={`label-${index}`}>
              <text
                x={x}
                y={y}
                textAnchor={textAnchor}
                className="text-xs font-medium fill-gray-700"
                dominantBaseline="middle"
              >
                {point.label}
              </text>
              <text
                x={x}
                y={y + 14}
                textAnchor={textAnchor}
                className="text-xs font-bold"
                fill={point.color || '#3b82f6'}
                dominantBaseline="middle"
              >
                {Math.round(point.value)}
              </text>
            </g>
          );
        })}

        {/* Score central */}
        <circle
          cx={centerX}
          cy={centerY}
          r="45"
          fill="white"
          stroke="#e5e7eb"
          strokeWidth="2"
        />
        <text
          x={centerX}
          y={centerY - 5}
          textAnchor="middle"
          className={`text-3xl font-bold ${getCategoryColor(data.centerScore)}`}
          dominantBaseline="middle"
        >
          {Math.round(data.centerScore)}
        </text>
        <text
          x={centerX}
          y={centerY + 15}
          textAnchor="middle"
          className="text-xs fill-gray-600"
          dominantBaseline="middle"
        >
          {data.centerLabel}
        </text>
      </svg>

      {/* Badge de categoría */}
      <div
        className={`mt-4 px-4 py-2 rounded-full ${getCategoryBgColor(
          data.centerScore
        )} ${getCategoryColor(data.centerScore)} text-sm font-semibold`}
      >
        {getCategoryLabel(data.centerScore)}
      </div>
    </div>
  );
};

/**
 * Componente simple de carga para el HGraph
 */
export const HGraphSkeleton: React.FC<{ size?: number }> = ({ size = 400 }) => {
  return (
    <div className="flex flex-col items-center animate-pulse">
      <div
        className="bg-gray-200 rounded-full"
        style={{ width: size, height: size }}
      />
      <div className="mt-4 bg-gray-200 h-8 w-32 rounded-full" />
    </div>
  );
};
