/**
 * Dashboard Page
 * EPA Bienestar - Programa Mujer
 * Página principal del Dashboard con visualización Life's Essential 8
 */

import React, { useEffect, useState } from 'react';
import { useMedplum } from '@medplum/react';
import {
  HGraphVisualization,
  HGraphSkeleton,
} from '../components/HGraphVisualization';
import {
  getLifeEssential8Data,
  convertToHGraphData,
  getMotivationalMessage,
} from '../services/le8Service';
import {
  LifeEssential8Data,
  LifeStageGroup,
  LE8_METRIC_NAMES,
} from '../types/le8.types';

export const DashboardPage: React.FC = () => {
  const medplum = useMedplum();
  const [le8Data, setLe8Data] = useState<LifeEssential8Data | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Obtener ID del paciente actual (ajustar según tu implementación)
      const profile = medplum.getProfile();
      if (!profile) {
        throw new Error('No se encontró perfil de usuario');
      }

      // Si el profile es un Patient, usar su ID directamente
      // Si es un Practitioner u otro recurso, necesitas buscar el Patient asociado
      const patientId = profile.resourceType === 'Patient' 
        ? profile.id 
        : await getPatientIdFromProfile(profile.id!);

      if (!patientId) {
        throw new Error('No se pudo determinar el ID del paciente');
      }

      const data = await getLifeEssential8Data(medplum, patientId);
      setLe8Data(data);
    } catch (err) {
      console.error('Error loading dashboard data:', err);
      setError(
        err instanceof Error
          ? err.message
          : 'Error al cargar datos del dashboard'
      );
    } finally {
      setLoading(false);
    }
  };

  // Helper para obtener Patient ID (ajustar según tu modelo de datos)
  const getPatientIdFromProfile = async (profileId: string): Promise<string | null> => {
    // Implementar lógica para obtener Patient asociado
    // Por ejemplo, si usas RelatedPerson o tienen otra estructura
    return null;
  };

  const getGroupLabel = (group: LifeStageGroup): string => {
    const labels: Record<LifeStageGroup, string> = {
      [LifeStageGroup.A]: 'Grupo A: Crecimiento Personal (18-30 años)',
      [LifeStageGroup.B]: 'Grupo B: Planificación Maternidad (30-45 años)',
      [LifeStageGroup.C]: 'Grupo C: Menopausia (45-65 años)',
      [LifeStageGroup.D]: 'Grupo D: Adultas Mayores (65+ años)',
    };
    return labels[group];
  };

  const getGroupDescription = (group: LifeStageGroup): string => {
    const descriptions: Record<LifeStageGroup, string> = {
      [LifeStageGroup.A]:
        'En esta etapa, construyes las bases de tu salud cardiovascular para toda la vida.',
      [LifeStageGroup.B]:
        'Tu salud cardiovascular es fundamental para una maternidad saludable.',
      [LifeStageGroup.C]:
        'La menopausia es una oportunidad para optimizar tu cuidado cardiovascular.',
      [LifeStageGroup.D]:
        'Mantener tu corazón saludable te permite disfrutar plenamente esta etapa.',
    };
    return descriptions[group];
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-blue-50 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-1/3 mb-4" />
              <div className="h-4 bg-gray-200 rounded w-2/3 mb-8" />
            </div>
            <HGraphSkeleton size={400} />
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-blue-50 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center">
              <div className="text-red-600 text-6xl mb-4">⚠️</div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Error al cargar el Dashboard
              </h2>
              <p className="text-gray-600 mb-6">{error}</p>
              <button
                onClick={loadDashboardData}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Reintentar
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!le8Data) {
    return null;
  }

  const hgraphData = convertToHGraphData(le8Data);
  const motivationalMessage = getMotivationalMessage(
    le8Data.lifeStageGroup,
    le8Data.overallScore || 0
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-blue-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Tu Salud Cardiovascular
              </h1>
              <p className="text-gray-600">
                Plan Bienestar 100 Días - Life's Essential 8
              </p>
            </div>
            {le8Data.lastUpdated && (
              <div className="text-right">
                <p className="text-sm text-gray-500">Última actualización</p>
                <p className="text-sm font-medium text-gray-700">
                  {le8Data.lastUpdated.toLocaleDateString('es-AR', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}
                </p>
              </div>
            )}
          </div>

          {/* Grupo de vida */}
          <div className="bg-gradient-to-r from-pink-100 to-blue-100 rounded-xl p-4 mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-1">
              {getGroupLabel(le8Data.lifeStageGroup)}
            </h3>
            <p className="text-gray-700">
              {getGroupDescription(le8Data.lifeStageGroup)}
            </p>
          </div>

          {/* Mensaje motivacional */}
          <div className="bg-blue-50 border-l-4 border-blue-600 rounded-lg p-4">
            <p className="text-blue-900 font-medium">{motivationalMessage}</p>
          </div>
        </div>

        {/* HGraph Visualization */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Visualización de tus 8 Pasos para la Salud Cardiovascular
          </h2>
          <HGraphVisualization data={hgraphData} size={500} />
        </div>

        {/* Métricas detalladas */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Detalle de Métricas
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Dieta */}
            <MetricCard
              name={LE8_METRIC_NAMES.diet}
              metric={le8Data.metrics.diet}
              icon="🥗"
            />

            {/* Actividad */}
            <MetricCard
              name={LE8_METRIC_NAMES.activity}
              metric={le8Data.metrics.activity}
              icon="🏃‍♀️"
            />

            {/* Nicotina */}
            <MetricCard
              name={LE8_METRIC_NAMES.nicotine}
              metric={le8Data.metrics.nicotine}
              icon="🚭"
            />

            {/* Sueño */}
            <MetricCard
              name={LE8_METRIC_NAMES.sleep}
              metric={le8Data.metrics.sleep}
              icon="😴"
            />

            {/* IMC */}
            <MetricCard
              name={LE8_METRIC_NAMES.bmi}
              metric={le8Data.metrics.bmi}
              icon="⚖️"
            />

            {/* Lípidos */}
            <MetricCard
              name={LE8_METRIC_NAMES.lipids}
              metric={le8Data.metrics.lipids}
              icon="🧪"
            />

            {/* Glucosa */}
            <MetricCard
              name={LE8_METRIC_NAMES.glucose}
              metric={le8Data.metrics.glucose}
              icon="🩸"
            />

            {/* Presión Arterial */}
            <MetricCard
              name={LE8_METRIC_NAMES.bloodPressure}
              metric={
                le8Data.metrics.bloodPressure.combinedScore !== null
                  ? {
                      name: LE8_METRIC_NAMES.bloodPressure,
                      value: le8Data.metrics.bloodPressure.combinedScore,
                      unit: 'score',
                      lastUpdated: new Date(),
                      category: 'high' as any,
                      code: '',
                    }
                  : null
              }
              icon="❤️"
            />
          </div>
        </div>

        {/* Call to action */}
        <div className="bg-gradient-to-r from-blue-600 to-pink-600 rounded-2xl shadow-xl p-8 text-white text-center">
          <h2 className="text-2xl font-bold mb-4">
            ¿Lista para mejorar tu salud cardiovascular?
          </h2>
          <p className="mb-6 text-blue-50">
            Completa las métricas faltantes para obtener una evaluación completa
          </p>
          <button className="px-8 py-3 bg-white text-blue-600 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
            Agregar Mediciones
          </button>
        </div>
      </div>
    </div>
  );
};

// Componente auxiliar para tarjetas de métricas
interface MetricCardProps {
  name: string;
  metric: any | null;
  icon: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ name, metric, icon }) => {
  if (!metric) {
    return (
      <div className="bg-gray-50 rounded-xl p-4 border-2 border-dashed border-gray-300">
        <div className="text-center">
          <div className="text-4xl mb-2">{icon}</div>
          <h4 className="font-semibold text-gray-900 mb-1">{name}</h4>
          <p className="text-sm text-gray-500">Sin datos</p>
        </div>
      </div>
    );
  }

  const getColorClass = (value: number): string => {
    if (value >= 80) return 'text-green-600 bg-green-50 border-green-200';
    if (value >= 50) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-red-600 bg-red-50 border-red-200';
  };

  return (
    <div className={`rounded-xl p-4 border-2 ${getColorClass(metric.value)}`}>
      <div className="text-center">
        <div className="text-4xl mb-2">{icon}</div>
        <h4 className="font-semibold text-gray-900 mb-1">{name}</h4>
        <div className="text-3xl font-bold mb-1">{Math.round(metric.value)}</div>
        <p className="text-xs text-gray-600">
          {metric.lastUpdated.toLocaleDateString('es-AR')}
        </p>
      </div>
    </div>
  );
};
