# 📊 Dashboard Life's Essential 8 - EPA Bienestar Programa Mujer

## 🎯 Descripción del Proyecto

Dashboard interactivo con visualización HGraph para las 8 métricas cardiovasculares de la American Heart Association, integrado con Medplum FHIR R4 API.

**Versión**: 1.0.0 (Fase 1)  
**Fecha**: Enero 2025  
**Autor**: EPA Bienestar IA  

---

## 📁 Estructura del Proyecto

```
dashboard-le8/
├── types/
│   └── le8.types.ts              # Tipos TypeScript para LE8
├── services/
│   └── le8Service.ts             # Lógica de negocio y queries FHIR
├── components/
│   └── HGraphVisualization.tsx   # Componente visual del HGraph
├── pages/
│   └── DashboardPage.tsx         # Página principal del Dashboard
├── examples/
│   ├── App.integration.example.tsx  # Ejemplo de integración
│   └── testData.ts               # Datos de prueba FHIR
├── docs/
│   └── DASHBOARD_README.md       # Documentación completa
├── INSTALACION_RAPIDA.md         # Guía rápida de instalación
└── README.md                     # Este archivo
```

---

## 🚀 Inicio Rápido

### Instalación en 3 Pasos

1. **Copiar archivos** a tu proyecto `mujer`
2. **Modificar** `App.tsx` para agregar la ruta
3. **Agregar enlace** en tu navegación

Ver: [INSTALACION_RAPIDA.md](./INSTALACION_RAPIDA.md)

---

## 📋 Características Principales

### ✅ Fase 1 (Implementada)

- [x] Visualización HGraph de 8 métricas cardiovasculares
- [x] Score global LE8 (0-100) con categorización AHA
- [x] Segmentación automática por grupos de vida (A/B/C/D)
- [x] Mensajes motivacionales personalizados
- [x] Integración completa con Medplum FHIR R4
- [x] Códigos LOINC estándar para interoperabilidad
- [x] Diseño responsivo con TailwindCSS
- [x] TypeScript para type-safety completo

### 🔜 Fase 2 (Roadmap)

- [ ] HGraph interactivo (click en métricas)
- [ ] Modales con histórico de cada métrica
- [ ] Gráficos de evolución temporal
- [ ] Comparación con promedios del grupo
- [ ] Recomendaciones personalizadas
- [ ] Integración con wearables en tiempo real

### 🔮 Fase 3 (Futuro)

- [ ] Visualización de Determinantes de Salud
- [ ] Predicción de abandono (Wellness Resilience Score)
- [ ] Digital twins cardiovascular para Grupo C
- [ ] Integración con PCOS monitoring para Grupo B

---

## 🎨 Life's Essential 8 - Métricas

| # | Métrica | Código LOINC | Descripción |
|---|---------|--------------|-------------|
| 1 | 🥗 Dieta | 8689-2 | Mediterranean Diet Score (MEPA) |
| 2 | 🏃‍♀️ Actividad | 82290-8 | Physical Activity Score |
| 3 | 🚭 Nicotina | 72166-2 | Tobacco Use Score |
| 4 | 😴 Sueño | 93832-4 | Sleep Health Score |
| 5 | ⚖️ IMC | 39156-5 | Body Mass Index Score |
| 6 | 🧪 Lípidos | 43396-1 | Non-HDL Cholesterol Score |
| 7 | 🩸 Glucosa | 2339-0 | Glucose Score |
| 8 | ❤️ Presión | 8480-6 / 8462-4 | Blood Pressure Score |

**Todos los scores en escala 0-100**

---

## 👥 Grupos de Vida

El Dashboard personaliza automáticamente la experiencia según edad:

| Grupo | Edad | Enfoque Principal |
|-------|------|-------------------|
| **A** | 18-29 | Jóvenes en crecimiento personal |
| **B** | 30-44 | Programando maternidad |
| **C** | 45-64 | Menopausia y desarrollo profesional |
| **D** | 65+ | Adultas mayores, emprendedoras |

---

## 🏗️ Arquitectura Técnica

### Stack Tecnológico

- **Frontend**: React 18 + TypeScript
- **UI**: TailwindCSS
- **Routing**: React Router v6
- **FHIR**: Medplum Client (FHIR R4)
- **Visualización**: SVG nativo
- **API**: https://api.epa-bienestar.com.ar/fhir/r4

### Flujo de Datos

```
Usuario → DashboardPage
         ↓
    le8Service (FHIR Queries)
         ↓
    Medplum API (R4)
         ↓
    Observations con LOINC
         ↓
    Cálculo de Scores
         ↓
    HGraph Visualization
         ↓
    Renderizado SVG
```

---

## 📖 Documentación

### Guías Disponibles

- **[INSTALACION_RAPIDA.md](./INSTALACION_RAPIDA.md)** - Para empezar en 5 minutos
- **[docs/DASHBOARD_README.md](./docs/DASHBOARD_README.md)** - Documentación completa
- **[examples/App.integration.example.tsx](./examples/App.integration.example.tsx)** - Ejemplo de código
- **[examples/testData.ts](./examples/testData.ts)** - Datos de prueba

### Archivos por Función

| Archivo | Propósito | Líneas |
|---------|-----------|--------|
| `le8.types.ts` | Definiciones TypeScript | ~200 |
| `le8Service.ts` | Lógica de negocio FHIR | ~250 |
| `HGraphVisualization.tsx` | Componente visual | ~180 |
| `DashboardPage.tsx` | Página principal | ~300 |

**Total: ~930 líneas de código**

---

## 🧪 Testing

### Cargar Datos de Prueba

```typescript
import { loadTestDataToMedplum } from './examples/testData';
import { useMedplum } from '@medplum/react';

const medplum = useMedplum();
await loadTestDataToMedplum(medplum);
```

Esto crea:
- 1 Patient (34 años, Grupo B)
- 9 Observations con scores realistas
- Score global esperado: ~81 (Excelente)

---

## 🔒 Seguridad y Compliance

- ✅ FHIR R4 Compliant
- ✅ Códigos LOINC estándar
- ✅ Autenticación con Medplum
- ✅ Protected routes
- ✅ TypeScript type-safety
- ✅ No expone datos sensibles en cliente

---

## 🤝 Contribución

Este es un proyecto interno de EPA Bienestar IA.

**Contacto**: [Definir contacto del equipo]

---

## 📝 Changelog

### v1.0.0 - Enero 2025 (Fase 1)

- ✨ Implementación inicial del Dashboard
- ✨ Visualización HGraph de Life's Essential 8
- ✨ Integración con Medplum FHIR R4
- ✨ Segmentación por grupos de vida
- ✨ Diseño responsivo con TailwindCSS
- 📚 Documentación completa

---

## 📄 Licencia

[Definir licencia según EPA Bienestar]

---

## 🙏 Agradecimientos

- **American Heart Association** - Life's Essential 8 Framework
- **Medplum** - FHIR R4 Infrastructure
- **HGraph Project** - Inspiración para visualización
- **Equipo Médico EPA**: Dras. Aquieri, Crosa, Pages, Cavenago, Mg. Sanguinetti

---

**Desarrollado con ❤️ para la salud cardiovascular de las mujeres argentinas**

EPA Bienestar IA | Programa Mujer | 2025
