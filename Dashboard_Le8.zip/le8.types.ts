/**
 * Life's Essential 8 Types
 * EPA Bienestar - Programa Mujer
 * FHIR R4 Compliant Types
 */

// LOINC Codes para Life's Essential 8
export const LE8_LOINC_CODES = {
  DIET: '8689-2',           // Mediterranean Diet Score
  ACTIVITY: '82290-8',      // Physical Activity Score
  NICOTINE: '72166-2',      // Tobacco Use Score
  SLEEP: '93832-4',         // Sleep Health Score
  BMI: '39156-5',           // Body Mass Index
  LIPIDS: '43396-1',        // Non-HDL Cholesterol
  GLUCOSE: '2339-0',        // Glucose
  BP_SYSTOLIC: '8480-6',    // Systolic Blood Pressure
  BP_DIASTOLIC: '8462-4',   // Diastolic Blood Pressure
} as const;

// Grupos de usuarias según momento de vida
export enum LifeStageGroup {
  A = 'A', // 18-30 años: Jóvenes en crecimiento personal y desarrollo
  B = 'B', // 28-40 años: Programando maternidad
  C = 'C', // 45-65 años: Menopausia y desarrollo profesional
  D = 'D', // 65+ años: Adultas mayores, abuelas, emprendedoras
}

// Categorías de score según AHA
export enum LE8ScoreCategory {
  POOR = 'poor',           // 0-49
  INTERMEDIATE = 'intermediate', // 50-79
  HIGH = 'high',           // 80-100
}

// Estructura de una métrica individual de LE8
export interface LE8Metric {
  code: string;           // LOINC code
  name: string;           // Nombre de la métrica
  value: number;          // Valor 0-100
  unit: string;           // Unidad de medida
  lastUpdated: Date;      // Última actualización
  category: LE8ScoreCategory; // Categoría según valor
  resourceId?: string;    // ID del recurso FHIR Observation
}

// Estructura completa de Life's Essential 8
export interface LifeEssential8Data {
  patientId: string;
  lifeStageGroup: LifeStageGroup;
  metrics: {
    diet: LE8Metric | null;
    activity: LE8Metric | null;
    nicotine: LE8Metric | null;
    sleep: LE8Metric | null;
    bmi: LE8Metric | null;
    lipids: LE8Metric | null;
    glucose: LE8Metric | null;
    bloodPressure: {
      systolic: LE8Metric | null;
      diastolic: LE8Metric | null;
      combinedScore: number | null; // Score combinado de PA
    };
  };
  overallScore: number | null;    // Promedio de las 8 métricas
  overallCategory: LE8ScoreCategory | null;
  lastUpdated: Date | null;
}

// Datos para HGraph
export interface HGraphDataPoint {
  label: string;
  value: number;        // 0-100
  maxValue: number;     // Siempre 100 para LE8
  color?: string;       // Color del segmento
  icon?: string;        // Icono opcional
}

export interface HGraphData {
  dataPoints: HGraphDataPoint[];
  centerScore: number;  // Score global en el centro
  centerLabel: string;
}

// Helper para calcular categoría según score
export function getScoreCategory(score: number): LE8ScoreCategory {
  if (score >= 80) return LE8ScoreCategory.HIGH;
  if (score >= 50) return LE8ScoreCategory.INTERMEDIATE;
  return LE8ScoreCategory.POOR;
}

// Helper para calcular grupo según fecha de nacimiento
export function calculateLifeStageGroup(birthDate: string): LifeStageGroup {
  const birth = new Date(birthDate);
  const today = new Date();
  const ageInYears = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  
  const age = monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())
    ? ageInYears - 1
    : ageInYears;

  if (age >= 18 && age < 30) return LifeStageGroup.A;
  if (age >= 30 && age < 45) return LifeStageGroup.B;
  if (age >= 45 && age < 65) return LifeStageGroup.C;
  return LifeStageGroup.D;
}

// Colores para cada métrica (personalizables según diseño EPA)
export const LE8_COLORS = {
  diet: '#10b981',        // Verde - Dieta
  activity: '#3b82f6',    // Azul - Actividad
  nicotine: '#8b5cf6',    // Púrpura - Nicotina
  sleep: '#6366f1',       // Índigo - Sueño
  bmi: '#f59e0b',         // Ámbar - IMC
  lipids: '#ef4444',      // Rojo - Lípidos
  glucose: '#ec4899',     // Rosa - Glucosa
  bloodPressure: '#14b8a6', // Teal - Presión Arterial
} as const;

// Nombres legibles en español
export const LE8_METRIC_NAMES = {
  diet: 'Dieta Mediterránea',
  activity: 'Actividad Física',
  nicotine: 'Sin Nicotina',
  sleep: 'Sueño Saludable',
  bmi: 'Índice de Masa Corporal',
  lipids: 'Colesterol',
  glucose: 'Glucosa',
  bloodPressure: 'Presión Arterial',
} as const;
