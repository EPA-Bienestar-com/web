# Dashboard Life's Essential 8 - EPA Bienestar Programa Mujer

## 📋 Descripción

Dashboard interactivo con visualización HGraph para Life's Essential 8 (LE8) de la American Heart Association, integrado con Medplum FHIR R4 API.

## ✨ Características

- ✅ Visualización HGraph radial de las 8 métricas cardiovasculares
- ✅ Score global LE8 (0-100) con categorización AHA
- ✅ Segmentación por grupos de vida (A, B, C, D)
- ✅ Mensajes motivacionales personalizados por grupo
- ✅ Integración completa con Medplum FHIR R4
- ✅ Códigos LOINC estándar para interoperabilidad
- ✅ Diseño responsivo con TailwindCSS
- ✅ TypeScript para type-safety

## 📦 Dependencias Requeridas

Verifica que tengas estas dependencias en tu `package.json`:

```json
{
  "dependencies": {
    "react": "^18.0.0",
    "react-dom": "^18.0.0",
    "react-router-dom": "^6.0.0",
    "@medplum/core": "^3.0.0",
    "@medplum/react": "^3.0.0",
    "@medplum/fhirtypes": "^3.0.0"
  },
  "devDependencies": {
    "typescript": "^5.0.0",
    "tailwindcss": "^3.0.0",
    "@types/react": "^18.0.0",
    "@types/react-dom": "^18.0.0"
  }
}
```

Si falta alguna dependencia, instálala con:

```bash
npm install @medplum/core @medplum/react @medplum/fhirtypes react-router-dom
```

## 📂 Estructura de Archivos

Copia los siguientes archivos en tu proyecto:

```
src/
├── types/
│   └── le8.types.ts              ⬅️ Tipos TypeScript para LE8
├── services/
│   └── le8Service.ts             ⬅️ Servicio para obtener datos de Medplum
├── components/
│   └── HGraphVisualization.tsx   ⬅️ Componente de visualización HGraph
├── pages/
│   └── DashboardPage.tsx         ⬅️ Página principal del Dashboard
└── App.tsx                       ⬅️ Modificar para agregar ruta
```

## 🔧 Instalación Paso a Paso

### Paso 1: Crear estructura de carpetas

```bash
# Desde la raíz de tu proyecto mujer
mkdir -p src/types
mkdir -p src/services
# src/components y src/pages ya deberían existir
```

### Paso 2: Copiar archivos

Copia los siguientes archivos en las ubicaciones correspondientes:

1. **`src/types/le8.types.ts`** - Contiene todos los tipos TypeScript
2. **`src/services/le8Service.ts`** - Lógica de negocio y queries FHIR
3. **`src/components/HGraphVisualization.tsx`** - Componente visual HGraph
4. **`src/pages/DashboardPage.tsx`** - Página completa del Dashboard

### Paso 3: Modificar App.tsx

Agrega la importación y ruta del Dashboard:

```tsx
// En src/App.tsx

// Agregar esta importación
import { DashboardPage } from './pages/DashboardPage';

// Dentro de tus <Routes>, agregar:
<Route 
  path="/dashboard" 
  element={
    <RequireAuth>
      <DashboardPage />
    </RequireAuth>
  } 
/>
```

### Paso 4: Agregar enlace en navegación

En tu componente de navegación (Header/Navbar), agrega:

```tsx
<Link 
  to="/dashboard" 
  className="text-gray-700 hover:text-pink-600 transition-colors font-semibold"
>
  Dashboard
</Link>
```

### Paso 5: Verificar configuración de Medplum

Asegúrate de que tu `MedplumClient` esté configurado correctamente:

```tsx
const medplum = new MedplumClient({
  baseUrl: 'https://api.epa-bienestar.com.ar/fhir/r4',
  clientId: 'TU_CLIENT_ID',
  // ... otras configuraciones
});
```

## 🎨 Personalización de Colores

Los colores están definidos en `le8.types.ts` y pueden personalizarse:

```typescript
export const LE8_COLORS = {
  diet: '#10b981',        // Verde - Dieta
  activity: '#3b82f6',    // Azul - Actividad
  nicotine: '#8b5cf6',    // Púrpura - Nicotina
  sleep: '#6366f1',       // Índigo - Sueño
  bmi: '#f59e0b',         // Ámbar - IMC
  lipids: '#ef4444',      // Rojo - Lípidos
  glucose: '#ec4899',     // Rosa - Glucosa
  bloodPressure: '#14b8a6', // Teal - Presión Arterial
};
```

## 📊 Códigos LOINC Utilizados

| Métrica | Código LOINC | Descripción |
|---------|--------------|-------------|
| Dieta | 8689-2 | Mediterranean Diet Score (MEPA) |
| Actividad | 82290-8 | Physical Activity Score |
| Nicotina | 72166-2 | Tobacco Use Score |
| Sueño | 93832-4 | Sleep Health Score |
| IMC | 39156-5 | Body Mass Index |
| Lípidos | 43396-1 | Non-HDL Cholesterol |
| Glucosa | 2339-0 | Glucose |
| PA Sistólica | 8480-6 | Systolic Blood Pressure |
| PA Diastólica | 8462-4 | Diastolic Blood Pressure |

## 🔄 Flujo de Datos

```
Usuario → DashboardPage
         ↓
         le8Service.getLifeEssential8Data()
         ↓
         Medplum FHIR API (searchResources)
         ↓
         Obtiene Observations con códigos LOINC
         ↓
         Calcula scores y categorías
         ↓
         convertToHGraphData()
         ↓
         HGraphVisualization (SVG)
         ↓
         Renderiza Dashboard completo
```

## 🧪 Testing

Para probar el Dashboard, necesitas tener en Medplum:

1. **Un recurso Patient** con `birthDate` para calcular el grupo
2. **Observations** con los códigos LOINC correspondientes
3. **valueQuantity** entre 0-100 para cada métrica

### Ejemplo de Observation FHIR R4:

```json
{
  "resourceType": "Observation",
  "status": "final",
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "8689-2",
      "display": "Mediterranean Diet Score"
    }]
  },
  "subject": {
    "reference": "Patient/PATIENT_ID"
  },
  "effectiveDateTime": "2025-01-05T10:00:00Z",
  "valueQuantity": {
    "value": 75,
    "unit": "score",
    "system": "http://unitsofmeasure.org"
  }
}
```

## 🎯 Grupos de Vida

El Dashboard calcula automáticamente el grupo según edad:

- **Grupo A** (18-29 años): Jóvenes en crecimiento personal
- **Grupo B** (30-44 años): Programando maternidad
- **Grupo C** (45-64 años): Menopausia y desarrollo profesional
- **Grupo D** (65+ años): Adultas mayores

## 📱 Responsividad

El Dashboard es completamente responsivo:

- **Desktop**: Grid de 4 columnas para métricas
- **Tablet**: Grid de 2 columnas
- **Mobile**: Grid de 1 columna

## 🐛 Troubleshooting

### Error: "No se encontró perfil de usuario"

**Solución**: Verifica que el usuario esté autenticado correctamente con Medplum.

### Error: "No se pudo determinar el ID del paciente"

**Solución**: Implementa la función `getPatientIdFromProfile()` en `DashboardPage.tsx` según tu modelo de datos.

### El HGraph no se muestra correctamente

**Solución**: Verifica que TailwindCSS esté configurado correctamente y que los estilos se estén aplicando.

### Las Observations no se encuentran

**Solución**: Verifica que:
1. Las Observations tengan los códigos LOINC correctos
2. El `patient` reference sea correcto
3. Tengan `status: "final"`
4. Tengan `valueQuantity` con valor numérico

## 🚀 Próximos Pasos (Fase 2)

- [ ] Interactividad en HGraph (click en métricas)
- [ ] Modal con histórico de cada métrica
- [ ] Gráficos de evolución temporal
- [ ] Comparación con promedios del grupo
- [ ] Recomendaciones personalizadas
- [ ] Integración con wearables en tiempo real

## 📞 Soporte

Para dudas o problemas:
- Email: [tu-email]
- GitHub Issues: [tu-repo]

## 📄 Licencia

[Definir licencia según proyecto EPA Bienestar]

---

**Desarrollado con ❤️ para EPA Bienestar - Programa Mujer**
