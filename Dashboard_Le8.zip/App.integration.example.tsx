/**
 * EJEMPLO DE INTEGRACIÓN DEL DASHBOARD
 * EPA Bienestar - Programa Mujer
 * 
 * Este archivo muestra cómo integrar el nuevo Dashboard en tu App.tsx existente
 * 
 * INSTRUCCIONES:
 * 1. Importa DashboardPage en tu App.tsx
 * 2. Agrega la ruta '/dashboard' en tu Router
 * 3. Agrega el enlace en tu componente de navegación
 */

// ============================================================================
// PASO 1: Importaciones necesarias en App.tsx
// ============================================================================

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { MedplumClient } from '@medplum/core';
import { MedplumProvider } from '@medplum/react';

// Páginas existentes
import { SignInPage } from './pages/SignInPage';
import { LandingPage } from './pages/LandingPage';
// ... otras páginas existentes

// ✨ NUEVA IMPORTACIÓN - Dashboard
import { DashboardPage } from './pages/DashboardPage';

// ============================================================================
// PASO 2: Configuración de Medplum Client (ya existente)
// ============================================================================

const medplum = new MedplumClient({
  baseUrl: 'https://api.epa-bienestar.com.ar/fhir/r4',
  clientId: 'TU_CLIENT_ID', // Reemplazar con tu CLIENT_ID real
  // Otras configuraciones según tu implementación actual
});

// ============================================================================
// PASO 3: Estructura de rutas con Dashboard incluido
// ============================================================================

function App() {
  return (
    <MedplumProvider medplum={medplum}>
      <Router>
        <Routes>
          {/* Ruta de login */}
          <Route path="/signin" element={<SignInPage />} />

          {/* Ruta principal/landing */}
          <Route path="/" element={<LandingPage />} />

          {/* ✨ NUEVA RUTA - Dashboard */}
          <Route 
            path="/dashboard" 
            element={
              <RequireAuth>
                <DashboardPage />
              </RequireAuth>
            } 
          />

          {/* Otras rutas existentes */}
          {/* <Route path="/perfil" element={<PerfilPage />} /> */}
          {/* <Route path="/mediciones" element={<MedicionesPage />} /> */}

          {/* Ruta por defecto - redirect a landing */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </MedplumProvider>
  );
}

// ============================================================================
// PASO 4: Componente de protección de rutas (si no lo tienes ya)
// ============================================================================

interface RequireAuthProps {
  children: React.ReactElement;
}

const RequireAuth: React.FC<RequireAuthProps> = ({ children }) => {
  const medplum = useMedplum();
  const profile = medplum.getProfile();

  if (!profile) {
    return <Navigate to="/signin" replace />;
  }

  return children;
};

// ============================================================================
// PASO 5: Agregar enlace al Dashboard en tu componente de navegación
// ============================================================================

/**
 * Ejemplo de componente de navegación con enlace al Dashboard
 * Integrar esto en tu Header/Navbar existente
 */
const NavigationExample: React.FC = () => {
  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <div className="text-xl font-bold text-pink-600">
            EPA Bienestar - Programa Mujer
          </div>

          {/* Links de navegación */}
          <div className="flex space-x-6">
            <a 
              href="/" 
              className="text-gray-700 hover:text-pink-600 transition-colors"
            >
              Inicio
            </a>

            {/* ✨ NUEVO ENLACE - Dashboard */}
            <a 
              href="/dashboard" 
              className="text-gray-700 hover:text-pink-600 transition-colors font-semibold"
            >
              Dashboard
            </a>

            <a 
              href="/perfil" 
              className="text-gray-700 hover:text-pink-600 transition-colors"
            >
              Mi Perfil
            </a>

            <a 
              href="/mediciones" 
              className="text-gray-700 hover:text-pink-600 transition-colors"
            >
              Mis Mediciones
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
};

// ============================================================================
// ALTERNATIVA: Si usas React Router Link en lugar de <a>
// ============================================================================

import { Link } from 'react-router-dom';

const NavigationWithRouterLinks: React.FC = () => {
  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="text-xl font-bold text-pink-600">
            EPA Bienestar - Programa Mujer
          </div>

          <div className="flex space-x-6">
            <Link 
              to="/" 
              className="text-gray-700 hover:text-pink-600 transition-colors"
            >
              Inicio
            </Link>

            {/* ✨ NUEVO ENLACE - Dashboard con React Router */}
            <Link 
              to="/dashboard" 
              className="text-gray-700 hover:text-pink-600 transition-colors font-semibold"
            >
              Dashboard
            </Link>

            <Link 
              to="/perfil" 
              className="text-gray-700 hover:text-pink-600 transition-colors"
            >
              Mi Perfil
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default App;

// ============================================================================
// NOTAS IMPORTANTES
// ============================================================================

/**
 * 1. Asegúrate de tener instaladas las dependencias necesarias:
 *    - @medplum/core
 *    - @medplum/react
 *    - @medplum/fhirtypes
 *    - react-router-dom
 * 
 * 2. Estructura de carpetas sugerida:
 *    src/
 *    ├── components/
 *    │   └── HGraphVisualization.tsx  ⬅️ Crear aquí
 *    ├── pages/
 *    │   ├── DashboardPage.tsx        ⬅️ Crear aquí
 *    │   ├── SignInPage.tsx           (existente)
 *    │   └── LandingPage.tsx          (existente)
 *    ├── services/
 *    │   └── le8Service.ts            ⬅️ Crear aquí
 *    ├── types/
 *    │   └── le8.types.ts             ⬅️ Crear aquí
 *    └── App.tsx                      (modificar)
 * 
 * 3. El Dashboard está protegido por autenticación mediante RequireAuth
 * 
 * 4. Los datos se obtienen automáticamente del paciente autenticado
 * 
 * 5. El HGraph se renderiza usando SVG nativo con TailwindCSS
 */
