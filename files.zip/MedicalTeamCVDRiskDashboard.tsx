/**
 * Dashboard de Riesgo Cardiovascular - Vista Médicos
 * EPA Bienestar IA - Equipo de Cardiología
 */

import React, { useEffect, useState } from 'react';
import { useMedplum } from '@medplum/react';
import {
  Patient,
  RiskAssessment,
  Task,
  Group
} from '@medplum/fhirtypes';

interface PatientRiskSummary {
  patient: Patient;
  currentRisk: number;
  category: string;
  categoryDisplay: string;
  color: string;
  lastUpdate: string;
  trend: 'up' | 'down' | 'stable';
  trendValue: number;
  hasPendingTask: boolean;
  age: number;
}

export function MedicalTeamCVDRiskDashboard() {
  const medplum = useMedplum();
  const [loading, setLoading] = useState(true);
  const [patients, setPatients] = useState<PatientRiskSummary[]>([]);
  const [filteredPatients, setFilteredPatients] = useState<PatientRiskSummary[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<PatientRiskSummary | null>(null);
  const [stats, setStats] = useState({
    total: 0,
    low: 0,
    moderate: 0,
    high: 0,
    veryHigh: 0,
    pendingTasks: 0
  });

  useEffect(() => {
    loadPatientsData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [patients, selectedCategory, searchQuery]);

  async function loadPatientsData() {
    try {
      // 1. Obtener pacientes del Grupo C
      const group = await medplum.readResource('Group', 'grupo-c-menopausia');
      
      if (!group.member || group.member.length === 0) {
        setLoading(false);
        return;
      }

      // 2. Procesar cada paciente
      const summaries: PatientRiskSummary[] = [];
      let pendingTasksCount = 0;

      for (const member of group.member) {
        if (!member.entity?.reference?.startsWith('Patient/')) continue;
        
        const patientId = member.entity.reference.split('/')[1];
        
        try {
          // Obtener paciente
          const patient = await medplum.readResource('Patient', patientId);
          
          // Obtener evaluaciones (actual + anterior para tendencia)
          const assessments = await medplum.searchResources('RiskAssessment', {
            subject: `Patient/${patientId}`,
            _sort: '-occurrence-date',
            _count: '2'
          });

          if (assessments.length === 0) continue;

          const current = assessments[0];
          const previous = assessments.length > 1 ? assessments[1] : null;

          const currentRisk = (current.prediction?.[0]?.probabilityDecimal || 0) * 100;
          const previousRisk = previous
            ? (previous.prediction?.[0]?.probabilityDecimal || 0) * 100
            : currentRisk;

          const trendValue = currentRisk - previousRisk;
          let trend: 'up' | 'down' | 'stable' = 'stable';
          if (Math.abs(trendValue) >= 1) {
            trend = trendValue > 0 ? 'up' : 'down';
          }

          const category = current.prediction?.[0]?.qualitativeRisk?.coding?.[0]?.code || 'unknown';
          const categoryDisplay = current.prediction?.[0]?.qualitativeRisk?.coding?.[0]?.display || 'Desconocido';

          // Verificar tasks pendientes
          const tasks = await medplum.searchResources('Task', {
            for: `Patient/${patientId}`,
            status: 'requested',
            _count: '1'
          });

          const hasPendingTask = tasks.length > 0;
          if (hasPendingTask) pendingTasksCount++;

          summaries.push({
            patient,
            currentRisk,
            category,
            categoryDisplay,
            color: getCategoryColor(category),
            lastUpdate: current.occurrenceDateTime || '',
            trend,
            trendValue,
            hasPendingTask,
            age: calculateAge(patient.birthDate!)
          });

        } catch (error) {
          console.error(`Error procesando paciente ${patientId}:`, error);
        }
      }

      // 3. Ordenar por riesgo descendente
      summaries.sort((a, b) => b.currentRisk - a.currentRisk);

      // 4. Calcular estadísticas
      const stats = {
        total: summaries.length,
        low: summaries.filter(p => p.category === 'low').length,
        moderate: summaries.filter(p => p.category === 'moderate').length,
        high: summaries.filter(p => p.category === 'high').length,
        veryHigh: summaries.filter(p => p.category === 'very-high').length,
        pendingTasks: pendingTasksCount
      };

      setPatients(summaries);
      setStats(stats);
      setLoading(false);
    } catch (error) {
      console.error('Error cargando datos:', error);
      setLoading(false);
    }
  }

  function applyFilters() {
    let filtered = [...patients];

    // Filtro por categoría
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(p => p.category === selectedCategory);
    }

    // Filtro por búsqueda
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(p => {
        const name = p.patient.name?.[0]?.text?.toLowerCase() || '';
        const id = p.patient.id?.toLowerCase() || '';
        return name.includes(query) || id.includes(query);
      });
    }

    setFilteredPatients(filtered);
  }

  function getCategoryColor(category: string): string {
    switch (category) {
      case 'low': return '#4CAF50';
      case 'moderate': return '#FF9800';
      case 'high': return '#F44336';
      case 'very-high': return '#B71C1C';
      default: return '#9E9E9E';
    }
  }

  function calculateAge(birthDate: string): number {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  }

  if (loading) {
    return (
      <div style={styles.loadingContainer}>
        <div style={styles.spinner}></div>
        <p>Cargando datos de pacientes...</p>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>👥 Panel de Riesgo Cardiovascular</h1>
          <p style={styles.subtitle}>Grupo C - Menopausia | {stats.total} pacientes</p>
        </div>
        <button style={styles.refreshButton} onClick={loadPatientsData}>
          🔄 Actualizar
        </button>
      </div>

      {/* Estadísticas Generales */}
      <div style={styles.statsGrid}>
        <div style={styles.statCard}>
          <div style={styles.statValue}>{stats.total}</div>
          <div style={styles.statLabel}>Total Pacientes</div>
        </div>
        
        <div style={{...styles.statCard, borderColor: '#B71C1C'}}>
          <div style={{...styles.statValue, color: '#B71C1C'}}>{stats.veryHigh}</div>
          <div style={styles.statLabel}>Riesgo Muy Alto</div>
          <div style={styles.statBadge}>🚨</div>
        </div>
        
        <div style={{...styles.statCard, borderColor: '#F44336'}}>
          <div style={{...styles.statValue, color: '#F44336'}}>{stats.high}</div>
          <div style={styles.statLabel}>Riesgo Alto</div>
          <div style={styles.statBadge}>🔴</div>
        </div>
        
        <div style={{...styles.statCard, borderColor: '#FF9800'}}>
          <div style={{...styles.statValue, color: '#FF9800'}}>{stats.moderate}</div>
          <div style={styles.statLabel}>Riesgo Moderado</div>
          <div style={styles.statBadge}>⚠️</div>
        </div>
        
        <div style={{...styles.statCard, borderColor: '#4CAF50'}}>
          <div style={{...styles.statValue, color: '#4CAF50'}}>{stats.low}</div>
          <div style={styles.statLabel}>Riesgo Bajo</div>
          <div style={styles.statBadge}>✅</div>
        </div>
        
        <div style={{...styles.statCard, borderColor: '#764ba2'}}>
          <div style={{...styles.statValue, color: '#764ba2'}}>{stats.pendingTasks}</div>
          <div style={styles.statLabel}>Tareas Pendientes</div>
          <div style={styles.statBadge}>📋</div>
        </div>
      </div>

      {/* Filtros */}
      <div style={styles.filtersCard}>
        <div style={styles.filtersContainer}>
          <input
            type="text"
            placeholder="🔍 Buscar paciente por nombre o ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={styles.searchInput}
          />
          
          <div style={styles.categoryFilters}>
            <button
              style={selectedCategory === 'all' ? styles.filterButtonActive : styles.filterButton}
              onClick={() => setSelectedCategory('all')}
            >
              Todas ({patients.length})
            </button>
            <button
              style={selectedCategory === 'very-high' ? {...styles.filterButtonActive, borderColor: '#B71C1C'} : styles.filterButton}
              onClick={() => setSelectedCategory('very-high')}
            >
              Muy Alto ({stats.veryHigh})
            </button>
            <button
              style={selectedCategory === 'high' ? {...styles.filterButtonActive, borderColor: '#F44336'} : styles.filterButton}
              onClick={() => setSelectedCategory('high')}
            >
              Alto ({stats.high})
            </button>
            <button
              style={selectedCategory === 'moderate' ? {...styles.filterButtonActive, borderColor: '#FF9800'} : styles.filterButton}
              onClick={() => setSelectedCategory('moderate')}
            >
              Moderado ({stats.moderate})
            </button>
            <button
              style={selectedCategory === 'low' ? {...styles.filterButtonActive, borderColor: '#4CAF50'} : styles.filterButton}
              onClick={() => setSelectedCategory('low')}
            >
              Bajo ({stats.low})
            </button>
          </div>
        </div>
      </div>

      {/* Tabla de Pacientes */}
      <div style={styles.tableCard}>
        <div style={styles.tableHeader}>
          <div style={styles.tableHeaderCell}>Paciente</div>
          <div style={styles.tableHeaderCell}>Edad</div>
          <div style={styles.tableHeaderCell}>Riesgo</div>
          <div style={styles.tableHeaderCell}>Categoría</div>
          <div style={styles.tableHeaderCell}>Tendencia</div>
          <div style={styles.tableHeaderCell}>Última Actualización</div>
          <div style={styles.tableHeaderCell}>Estado</div>
          <div style={styles.tableHeaderCell}>Acciones</div>
        </div>
        
        <div style={styles.tableBody}>
          {filteredPatients.length === 0 ? (
            <div style={styles.emptyState}>
              <p>No se encontraron pacientes con los filtros seleccionados</p>
            </div>
          ) : (
            filteredPatients.map((patient) => (
              <div 
                key={patient.patient.id} 
                style={{
                  ...styles.tableRow,
                  borderLeft: `4px solid ${patient.color}`
                }}
              >
                <div style={styles.tableCell}>
                  <div style={styles.patientName}>
                    {patient.patient.name?.[0]?.text || 'Sin nombre'}
                  </div>
                  <div style={styles.patientId}>
                    ID: {patient.patient.id}
                  </div>
                </div>
                
                <div style={styles.tableCell}>
                  {patient.age} años
                </div>
                
                <div style={styles.tableCell}>
                  <div style={{...styles.riskValue, color: patient.color}}>
                    {patient.currentRisk.toFixed(1)}%
                  </div>
                </div>
                
                <div style={styles.tableCell}>
                  <span style={{
                    ...styles.categoryBadge,
                    background: patient.color,
                    color: 'white'
                  }}>
                    {patient.categoryDisplay}
                  </span>
                </div>
                
                <div style={styles.tableCell}>
                  {patient.trend === 'up' && (
                    <span style={styles.trendUp}>
                      ⬆️ +{patient.trendValue.toFixed(1)}
                    </span>
                  )}
                  {patient.trend === 'down' && (
                    <span style={styles.trendDown}>
                      ⬇️ {patient.trendValue.toFixed(1)}
                    </span>
                  )}
                  {patient.trend === 'stable' && (
                    <span style={styles.trendStable}>
                      ➡️ Estable
                    </span>
                  )}
                </div>
                
                <div style={styles.tableCell}>
                  {new Date(patient.lastUpdate).toLocaleDateString('es-AR')}
                </div>
                
                <div style={styles.tableCell}>
                  {patient.hasPendingTask ? (
                    <span style={styles.taskPending}>📋 Tarea pendiente</span>
                  ) : (
                    <span style={styles.taskNone}>✓ Sin tareas</span>
                  )}
                </div>
                
                <div style={styles.tableCell}>
                  <button
                    style={styles.viewButton}
                    onClick={() => setSelectedPatient(patient)}
                  >
                    Ver detalles
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Modal de Detalles de Paciente */}
      {selectedPatient && (
        <div style={styles.modalOverlay} onClick={() => setSelectedPatient(null)}>
          <div style={styles.modal} onClick={(e) => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <h2 style={styles.modalTitle}>
                {selectedPatient.patient.name?.[0]?.text}
              </h2>
              <button
                style={styles.modalClose}
                onClick={() => setSelectedPatient(null)}
              >
                ✕
              </button>
            </div>
            
            <div style={styles.modalContent}>
              <div style={styles.modalSection}>
                <h3>Información General</h3>
                <div style={styles.infoGrid}>
                  <div>
                    <strong>Edad:</strong> {selectedPatient.age} años
                  </div>
                  <div>
                    <strong>ID:</strong> {selectedPatient.patient.id}
                  </div>
                  <div>
                    <strong>Email:</strong> {
                      selectedPatient.patient.telecom?.find(t => t.system === 'email')?.value || 'No registrado'
                    }
                  </div>
                  <div>
                    <strong>Teléfono:</strong> {
                      selectedPatient.patient.telecom?.find(t => t.system === 'phone')?.value || 'No registrado'
                    }
                  </div>
                </div>
              </div>
              
              <div style={styles.modalSection}>
                <h3>Riesgo Cardiovascular</h3>
                <div style={{
                  ...styles.modalRiskCard,
                  borderColor: selectedPatient.color
                }}>
                  <div style={{...styles.modalRiskValue, color: selectedPatient.color}}>
                    {selectedPatient.currentRisk.toFixed(1)}%
                  </div>
                  <div style={styles.modalRiskLabel}>
                    {selectedPatient.categoryDisplay}
                  </div>
                  <div style={styles.modalRiskDescription}>
                    Probabilidad de evento cardiovascular a 10 años
                  </div>
                </div>
              </div>
              
              <div style={styles.modalSection}>
                <h3>Acciones Recomendadas</h3>
                <div style={styles.modalActions}>
                  <button style={styles.modalActionButton}>
                    📊 Ver Historial Completo
                  </button>
                  <button style={styles.modalActionButton}>
                    📝 Actualizar CarePlan
                  </button>
                  <button style={styles.modalActionButton}>
                    📧 Enviar Mensaje
                  </button>
                  <button style={styles.modalActionButton}>
                    📅 Agendar Consulta
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// ESTILOS
// ============================================================================

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: '1400px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
  },
  
  loadingContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '400px'
  },
  
  spinner: {
    width: '50px',
    height: '50px',
    border: '5px solid #f3f3f3',
    borderTop: '5px solid #667eea',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite'
  },
  
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '30px'
  },
  
  title: {
    fontSize: '32px',
    fontWeight: 'bold',
    margin: '0 0 5px 0',
    color: '#1a1a1a'
  },
  
  subtitle: {
    fontSize: '16px',
    color: '#666',
    margin: 0
  },
  
  refreshButton: {
    background: '#667eea',
    color: 'white',
    border: 'none',
    padding: '12px 24px',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'background 0.2s'
  },
  
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
    gap: '15px',
    marginBottom: '30px'
  },
  
  statCard: {
    background: 'white',
    padding: '20px',
    borderRadius: '12px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    borderLeft: '4px solid #667eea',
    position: 'relative'
  },
  
  statValue: {
    fontSize: '36px',
    fontWeight: 'bold',
    color: '#1a1a1a',
    marginBottom: '5px'
  },
  
  statLabel: {
    fontSize: '13px',
    color: '#666',
    textTransform: 'uppercase',
    letterSpacing: '0.5px'
  },
  
  statBadge: {
    position: 'absolute',
    top: '15px',
    right: '15px',
    fontSize: '24px'
  },
  
  filtersCard: {
    background: 'white',
    padding: '20px',
    borderRadius: '12px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    marginBottom: '20px'
  },
  
  filtersContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px'
  },
  
  searchInput: {
    width: '100%',
    padding: '12px 16px',
    fontSize: '15px',
    border: '2px solid #e0e0e0',
    borderRadius: '8px',
    outline: 'none',
    transition: 'border-color 0.2s'
  },
  
  categoryFilters: {
    display: 'flex',
    gap: '10px',
    flexWrap: 'wrap'
  },
  
  filterButton: {
    background: 'white',
    color: '#666',
    border: '2px solid #e0e0e0',
    padding: '8px 16px',
    borderRadius: '20px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s'
  },
  
  filterButtonActive: {
    background: '#667eea',
    color: 'white',
    border: '2px solid #667eea',
    padding: '8px 16px',
    borderRadius: '20px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer'
  },
  
  tableCard: {
    background: 'white',
    borderRadius: '12px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    overflow: 'hidden'
  },
  
  tableHeader: {
    display: 'grid',
    gridTemplateColumns: '2fr 0.8fr 1fr 1.2fr 1.2fr 1.5fr 1.2fr 1fr',
    background: '#f5f5f5',
    padding: '15px 20px',
    fontWeight: '600',
    fontSize: '13px',
    color: '#666',
    textTransform: 'uppercase',
    letterSpacing: '0.5px'
  },
  
  tableHeaderCell: {
    padding: '0 10px'
  },
  
  tableBody: {
    maxHeight: '600px',
    overflowY: 'auto'
  },
  
  tableRow: {
    display: 'grid',
    gridTemplateColumns: '2fr 0.8fr 1fr 1.2fr 1.2fr 1.5fr 1.2fr 1fr',
    padding: '20px',
    borderBottom: '1px solid #f0f0f0',
    transition: 'background 0.2s',
    cursor: 'pointer'
  },
  
  tableCell: {
    padding: '0 10px',
    display: 'flex',
    alignItems: 'center'
  },
  
  patientName: {
    fontSize: '15px',
    fontWeight: '600',
    color: '#1a1a1a'
  },
  
  patientId: {
    fontSize: '12px',
    color: '#999',
    marginTop: '2px'
  },
  
  riskValue: {
    fontSize: '20px',
    fontWeight: 'bold'
  },
  
  categoryBadge: {
    padding: '6px 12px',
    borderRadius: '12px',
    fontSize: '12px',
    fontWeight: '600'
  },
  
  trendUp: {
    color: '#d32f2f',
    fontSize: '14px',
    fontWeight: '600'
  },
  
  trendDown: {
    color: '#388e3c',
    fontSize: '14px',
    fontWeight: '600'
  },
  
  trendStable: {
    color: '#666',
    fontSize: '14px'
  },
  
  taskPending: {
    color: '#FF9800',
    fontSize: '13px',
    fontWeight: '600'
  },
  
  taskNone: {
    color: '#4CAF50',
    fontSize: '13px'
  },
  
  viewButton: {
    background: '#667eea',
    color: 'white',
    border: 'none',
    padding: '8px 16px',
    borderRadius: '6px',
    fontSize: '13px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'background 0.2s'
  },
  
  emptyState: {
    textAlign: 'center',
    padding: '40px',
    color: '#999'
  },
  
  modalOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000
  },
  
  modal: {
    background: 'white',
    borderRadius: '16px',
    width: '90%',
    maxWidth: '700px',
    maxHeight: '90vh',
    overflow: 'auto',
    boxShadow: '0 10px 40px rgba(0,0,0,0.3)'
  },
  
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '30px',
    borderBottom: '1px solid #f0f0f0'
  },
  
  modalTitle: {
    fontSize: '24px',
    fontWeight: 'bold',
    margin: 0
  },
  
  modalClose: {
    background: 'none',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#666',
    padding: '5px 10px'
  },
  
  modalContent: {
    padding: '30px'
  },
  
  modalSection: {
    marginBottom: '30px'
  },
  
  infoGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '15px',
    marginTop: '15px'
  },
  
  modalRiskCard: {
    borderLeft: '6px solid',
    background: '#f9f9f9',
    padding: '30px',
    borderRadius: '12px',
    textAlign: 'center',
    marginTop: '15px'
  },
  
  modalRiskValue: {
    fontSize: '64px',
    fontWeight: 'bold',
    lineHeight: 1
  },
  
  modalRiskLabel: {
    fontSize: '20px',
    fontWeight: '600',
    marginTop: '10px',
    color: '#333'
  },
  
  modalRiskDescription: {
    fontSize: '14px',
    color: '#666',
    marginTop: '10px'
  },
  
  modalActions: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
    gap: '15px',
    marginTop: '15px'
  },
  
  modalActionButton: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    border: 'none',
    padding: '14px 20px',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'transform 0.2s'
  }
};
