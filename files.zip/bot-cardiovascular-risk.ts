/**
 * Bot de Evaluación de Riesgo Cardiovascular - Grupo C Menopausia
 * EPA Bienestar IA
 * 
 * Ejecuta cada lunes a las 6:00 AM
 * Calcula HEARTS Score (WHO 2019) + Modificadores de Menopausia
 * Genera RiskAssessment y notifica vía AWS SES
 */

import { BotEvent, MedplumClient } from '@medplum/core';
import {
  Patient,
  Observation,
  RiskAssessment,
  Group,
  QuestionnaireResponse,
  Task,
  CarePlan,
  Condition
} from '@medplum/fhirtypes';
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';

// ============================================================================
// CONFIGURACIÓN
// ============================================================================

const CONFIG = {
  REGION: 'AMR-D', // Southern Latin America (Argentina)
  GROUP_C_ID: 'grupo-c-menopausia', // ID del Group resource
  SES_FROM_EMAIL: 'notificaciones@epa-bienestar.com.ar',
  SES_REGION: 'us-east-1',
  
  // Umbrales de riesgo (%)
  RISK_THRESHOLDS: {
    LOW: 10,
    MODERATE: 20,
    HIGH: 30
  },
  
  // Cambio significativo para notificar (puntos porcentuales)
  SIGNIFICANT_CHANGE: 5
};

// ============================================================================
// TIPOS
// ============================================================================

interface CVDRiskData {
  baseRisk: number;
  adjustedRisk: number;
  category: RiskCategory;
  modifiers: MenopauseModifiers;
  components: RiskComponents;
  calculatedAt: string;
}

interface RiskCategory {
  level: 'low' | 'moderate' | 'high' | 'very-high';
  display: string;
  color: string;
  action: string;
}

interface MenopauseModifiers {
  earlyMenopause: boolean; // <45 años
  pcos: boolean;
  preeclampsia: boolean;
  gestationalDiabetes: boolean;
  hypothyroidism: boolean;
  elevatedLDL: boolean;
  familyHistory: boolean;
  modifierScore: number;
}

interface RiskComponents {
  age: number;
  sex: string;
  sbp: number;
  cholesterol: number;
  ldl?: number;
  hdl?: number;
  smoking: boolean;
  diabetes: boolean;
}

interface LatestObservations {
  systolicBP?: Observation;
  totalCholesterol?: Observation;
  ldlCholesterol?: Observation;
  hdlCholesterol?: Observation;
  glucose?: Observation;
  bmi?: Observation;
  tsh?: Observation;
}

// ============================================================================
// HANDLER PRINCIPAL
// ============================================================================

export async function handler(
  medplum: MedplumClient,
  event: BotEvent
): Promise<void> {
  console.log('🚀 Iniciando cálculo semanal de Riesgo Cardiovascular - Grupo C');
  console.log(`⏰ Ejecutado: ${new Date().toISOString()}`);

  const sesClient = new SESClient({ region: CONFIG.SES_REGION });

  try {
    // 1. Obtener todas las pacientes del Grupo C
    const groupCPatients = await getGroupCPatients(medplum);
    console.log(`👥 Pacientes Grupo C encontradas: ${groupCPatients.length}`);

    let processed = 0;
    let withNewData = 0;
    let risksCalculated = 0;
    let alertsSent = 0;

    // 2. Procesar cada paciente
    for (const patient of groupCPatients) {
      try {
        console.log(`\n📋 Procesando: ${patient.name?.[0]?.text || patient.id}`);

        // 3. Verificar datos recientes (última semana)
        const hasRecentData = await checkRecentObservations(medplum, patient.id!);
        
        if (!hasRecentData) {
          console.log(`  ⏭️  Sin datos nuevos, saltando...`);
          processed++;
          continue;
        }

        withNewData++;

        // 4. Calcular riesgo cardiovascular
        const riskData = await calculateCVDRisk(medplum, patient);
        console.log(`  📊 Riesgo calculado: ${riskData.adjustedRisk.toFixed(1)}% (${riskData.category.display})`);

        // 5. Crear/Actualizar RiskAssessment
        const riskAssessment = await createRiskAssessment(medplum, patient, riskData);
        risksCalculated++;

        // 6. Detectar cambios significativos
        const changeDetected = await detectSignificantChange(
          medplum,
          patient.id!,
          riskData
        );

        // 7. Manejar cambios y notificaciones
        if (changeDetected) {
          console.log(`  🔔 Cambio significativo detectado: ${changeDetected.description}`);
          await handleRiskChange(medplum, sesClient, patient, riskData, changeDetected);
          alertsSent++;
        }

        // 8. Actualizar CarePlan si necesario
        await updateCarePlanIfNeeded(medplum, patient, riskData);

        processed++;
      } catch (error) {
        console.error(`❌ Error procesando paciente ${patient.id}:`, error);
        // Continuar con la siguiente paciente
      }
    }

    // Resumen final
    console.log('\n' + '='.repeat(60));
    console.log('✅ RESUMEN DE EJECUCIÓN');
    console.log('='.repeat(60));
    console.log(`Total pacientes procesadas: ${processed}`);
    console.log(`Con datos nuevos: ${withNewData}`);
    console.log(`Riesgos calculados: ${risksCalculated}`);
    console.log(`Alertas enviadas: ${alertsSent}`);
    console.log('='.repeat(60));

  } catch (error) {
    console.error('❌ Error fatal en la ejecución del bot:', error);
    throw error;
  }
}

// ============================================================================
// FUNCIONES DE OBTENCIÓN DE DATOS
// ============================================================================

async function getGroupCPatients(medplum: MedplumClient): Promise<Patient[]> {
  try {
    // Obtener el Group resource
    const group = await medplum.readResource('Group', CONFIG.GROUP_C_ID);
    
    if (!group.member || group.member.length === 0) {
      console.warn('⚠️  Grupo C no tiene miembros');
      return [];
    }

    // Obtener todos los Patient resources
    const patients: Patient[] = [];
    for (const member of group.member) {
      if (member.entity?.reference?.startsWith('Patient/')) {
        const patientId = member.entity.reference.split('/')[1];
        try {
          const patient = await medplum.readResource('Patient', patientId);
          patients.push(patient);
        } catch (error) {
          console.error(`Error obteniendo paciente ${patientId}:`, error);
        }
      }
    }

    return patients;
  } catch (error) {
    console.error('Error obteniendo pacientes del Grupo C:', error);
    return [];
  }
}

async function checkRecentObservations(
  medplum: MedplumClient,
  patientId: string
): Promise<boolean> {
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  const dateFilter = sevenDaysAgo.toISOString().split('T')[0];

  try {
    const observations = await medplum.searchResources('Observation', {
      subject: `Patient/${patientId}`,
      date: `ge${dateFilter}`,
      _count: '1'
    });

    return observations.length > 0;
  } catch (error) {
    console.error('Error verificando observaciones recientes:', error);
    return false;
  }
}

async function getLatestObservations(
  medplum: MedplumClient,
  patientId: string
): Promise<LatestObservations> {
  const observations: LatestObservations = {};

  // Definir códigos LOINC para cada observación
  const codes = {
    systolicBP: '8480-6',
    totalCholesterol: '2093-3',
    ldlCholesterol: '2089-1',
    hdlCholesterol: '2085-9',
    glucose: '41653-7',
    bmi: '39156-5',
    tsh: '3016-3'
  };

  // Obtener la última de cada tipo
  for (const [key, code] of Object.entries(codes)) {
    try {
      const results = await medplum.searchResources('Observation', {
        subject: `Patient/${patientId}`,
        code: code,
        _sort: '-date',
        _count: '1'
      });

      if (results.length > 0) {
        observations[key as keyof LatestObservations] = results[0];
      }
    } catch (error) {
      console.error(`Error obteniendo ${key}:`, error);
    }
  }

  return observations;
}

async function getQuestionnaireResponse(
  medplum: MedplumClient,
  patientId: string
): Promise<QuestionnaireResponse | null> {
  try {
    const responses = await medplum.searchResources('QuestionnaireResponse', {
      subject: `Patient/${patientId}`,
      questionnaire: 'cardiovascular-risk-factors-women',
      _sort: '-authored',
      _count: '1'
    });

    return responses.length > 0 ? responses[0] : null;
  } catch (error) {
    console.error('Error obteniendo QuestionnaireResponse:', error);
    return null;
  }
}

async function hasCondition(
  medplum: MedplumClient,
  patientId: string,
  snomedCode: string
): Promise<boolean> {
  try {
    const conditions = await medplum.searchResources('Condition', {
      subject: `Patient/${patientId}`,
      code: snomedCode,
      'clinical-status': 'active',
      _count: '1'
    });

    return conditions.length > 0;
  } catch (error) {
    console.error(`Error verificando condición ${snomedCode}:`, error);
    return false;
  }
}

// ============================================================================
// CÁLCULO DE RIESGO CARDIOVASCULAR
// ============================================================================

async function calculateCVDRisk(
  medplum: MedplumClient,
  patient: Patient
): Promise<CVDRiskData> {
  // A. Obtener componentes base
  const age = calculateAge(patient.birthDate!);
  const sex = patient.gender || 'female';

  const latestObs = await getLatestObservations(medplum, patient.id!);

  const sbp = latestObs.systolicBP?.valueQuantity?.value || 120;
  const cholesterol = latestObs.totalCholesterol?.valueQuantity?.value || 200;
  const ldl = latestObs.ldlCholesterol?.valueQuantity?.value;
  const hdl = latestObs.hdlCholesterol?.valueQuantity?.value;
  const glucose = latestObs.glucose?.valueQuantity?.value;

  // B. Obtener factores de riesgo del Questionnaire
  const qResponse = await getQuestionnaireResponse(medplum, patient.id!);
  const smoking = getAnswerBoolean(qResponse, '4.1') || false;
  
  // C. Verificar diabetes
  const hasDiabetes = await hasCondition(medplum, patient.id!, '73211009') ||
                     (glucose !== undefined && glucose >= 126);

  // D. Calcular HEARTS Score base (WHO 2019)
  const baseRisk = calculateWHOHeartsScore({
    age,
    sex,
    sbp,
    cholesterol,
    smoking,
    diabetes: hasDiabetes,
    region: CONFIG.REGION
  });

  // E. Obtener modificadores de menopausia
  const modifiers = await getMenopauseRiskModifiers(
    medplum,
    patient,
    qResponse,
    latestObs
  );

  // F. Aplicar modificadores
  let adjustedRisk = baseRisk;
  
  if (modifiers.earlyMenopause) adjustedRisk *= 1.5;
  if (modifiers.pcos) adjustedRisk *= 1.4;
  if (modifiers.preeclampsia) adjustedRisk *= 1.7;
  if (modifiers.gestationalDiabetes) adjustedRisk *= 1.5;
  if (modifiers.hypothyroidism && modifiers.elevatedLDL) adjustedRisk *= 1.2;
  if (modifiers.familyHistory) adjustedRisk *= 1.6;

  // G. Limitar a 100%
  adjustedRisk = Math.min(adjustedRisk, 100);

  // H. Categorizar
  const category = getRiskCategory(adjustedRisk);

  return {
    baseRisk,
    adjustedRisk,
    category,
    modifiers,
    components: {
      age,
      sex,
      sbp,
      cholesterol,
      ldl,
      hdl,
      smoking,
      diabetes: hasDiabetes
    },
    calculatedAt: new Date().toISOString()
  };
}

function calculateWHOHeartsScore(params: {
  age: number;
  sex: string;
  sbp: number;
  cholesterol: number;
  smoking: boolean;
  diabetes: boolean;
  region: string;
}): number {
  /**
   * Simplificación del algoritmo WHO HEARTS 2019
   * Para implementación completa, usar tablas oficiales WHO
   * Este es un modelo aproximado basado en Framingham adaptado
   */
  
  const { age, sex, sbp, cholesterol, smoking, diabetes } = params;
  
  // Base de edad (mujer)
  let score = 0;
  if (age >= 40 && age < 50) score = 3;
  else if (age >= 50 && age < 60) score = 8;
  else if (age >= 60 && age < 70) score = 15;
  else if (age >= 70) score = 20;
  
  // Presión sistólica
  if (sbp >= 120 && sbp < 140) score += 2;
  else if (sbp >= 140 && sbp < 160) score += 5;
  else if (sbp >= 160) score += 8;
  
  // Colesterol (mg/dL)
  if (cholesterol >= 200 && cholesterol < 240) score += 2;
  else if (cholesterol >= 240 && cholesterol < 280) score += 4;
  else if (cholesterol >= 280) score += 6;
  
  // Tabaquismo
  if (smoking) score += 5;
  
  // Diabetes
  if (diabetes) score += 6;
  
  // Ajuste regional para Argentina (AMR-D)
  const regionalFactor = 0.9; // Southern Latin America tiene menor incidencia
  
  return score * regionalFactor;
}

async function getMenopauseRiskModifiers(
  medplum: MedplumClient,
  patient: Patient,
  qResponse: QuestionnaireResponse | null,
  observations: LatestObservations
): Promise<MenopauseModifiers> {
  const modifiers: MenopauseModifiers = {
    earlyMenopause: false,
    pcos: false,
    preeclampsia: false,
    gestationalDiabetes: false,
    hypothyroidism: false,
    elevatedLDL: false,
    familyHistory: false,
    modifierScore: 0
  };

  if (!qResponse) {
    console.warn('  ⚠️  No hay QuestionnaireResponse, usando solo Conditions');
    
    // Fallback a Conditions
    modifiers.pcos = await hasCondition(medplum, patient.id!, '237055002');
    modifiers.hypothyroidism = await hasCondition(medplum, patient.id!, '40930008');
    
    return modifiers;
  }

  // Menopausia temprana (<45 años)
  const menopauseAge = getAnswerInteger(qResponse, '1.4');
  if (menopauseAge && menopauseAge < 45) {
    modifiers.earlyMenopause = true;
    modifiers.modifierScore += 1.5;
  }

  // PCOS
  if (getAnswerBoolean(qResponse, '2.1')) {
    modifiers.pcos = true;
    modifiers.modifierScore += 1.4;
  }

  // Preeclampsia
  if (getAnswerBoolean(qResponse, '1.2')) {
    modifiers.preeclampsia = true;
    modifiers.modifierScore += 1.7;
  }

  // Diabetes gestacional
  if (getAnswerBoolean(qResponse, '1.3')) {
    modifiers.gestationalDiabetes = true;
    modifiers.modifierScore += 1.5;
  }

  // Hipotiroidismo
  if (getAnswerBoolean(qResponse, '2.2')) {
    modifiers.hypothyroidism = true;
    
    // Verificar LDL elevado
    const ldl = observations.ldlCholesterol?.valueQuantity?.value;
    if (ldl && ldl > 130) {
      modifiers.elevatedLDL = true;
      modifiers.modifierScore += 1.2;
    }
  }

  // Historia familiar
  if (getAnswerBoolean(qResponse, '3.1')) {
    modifiers.familyHistory = true;
    modifiers.modifierScore += 1.6;
  }

  return modifiers;
}

function getRiskCategory(risk: number): RiskCategory {
  if (risk < CONFIG.RISK_THRESHOLDS.LOW) {
    return {
      level: 'low',
      display: 'Riesgo Bajo',
      color: '#4CAF50',
      action: 'lifestyle-only'
    };
  }
  
  if (risk < CONFIG.RISK_THRESHOLDS.MODERATE) {
    return {
      level: 'moderate',
      display: 'Riesgo Moderado',
      color: '#FF9800',
      action: 'intensive-lifestyle-consider-meds'
    };
  }
  
  if (risk < CONFIG.RISK_THRESHOLDS.HIGH) {
    return {
      level: 'high',
      display: 'Riesgo Alto',
      color: '#F44336',
      action: 'medications-recommended'
    };
  }
  
  return {
    level: 'very-high',
    display: 'Riesgo Muy Alto',
    color: '#B71C1C',
    action: 'urgent-medical-review'
  };
}

// ============================================================================
// CREACIÓN DE RISKASSESSMENT
// ============================================================================

async function createRiskAssessment(
  medplum: MedplumClient,
  patient: Patient,
  riskData: CVDRiskData
): Promise<RiskAssessment> {
  const riskAssessment: RiskAssessment = {
    resourceType: 'RiskAssessment',
    status: 'final',
    subject: { reference: `Patient/${patient.id}` },
    occurrenceDateTime: riskData.calculatedAt,
    
    method: {
      coding: [{
        system: 'http://epa-bienestar.com.ar/fhir/CodeSystem/risk-calculation-method',
        code: 'hearts-menopause-adapted',
        display: 'HEARTS Score WHO 2019 Adaptado para Menopausia'
      }]
    },
    
    prediction: [{
      outcome: {
        coding: [{
          system: 'http://snomed.info/sct',
          code: '266894000',
          display: 'Evento Cardiovascular'
        }],
        text: 'Infarto de Miocardio, ACV o Muerte Cardiovascular'
      },
      probabilityDecimal: riskData.adjustedRisk / 100,
      qualitativeRisk: {
        coding: [{
          system: 'http://terminology.hl7.org/CodeSystem/risk-probability',
          code: riskData.category.level,
          display: riskData.category.display
        }]
      },
      whenRange: {
        high: {
          value: 10,
          unit: 'años',
          system: 'http://unitsofmeasure.org',
          code: 'a'
        }
      }
    }],
    
    note: [{
      text: `Riesgo base HEARTS: ${riskData.baseRisk.toFixed(1)}%. ` +
            `Riesgo ajustado con modificadores: ${riskData.adjustedRisk.toFixed(1)}%. ` +
            `Modificadores aplicados: ${formatModifiers(riskData.modifiers)}`
    }],
    
    extension: [
      {
        url: 'http://epa-bienestar.com.ar/fhir/StructureDefinition/base-risk',
        valueDecimal: riskData.baseRisk
      },
      {
        url: 'http://epa-bienestar.com.ar/fhir/StructureDefinition/modifier-score',
        valueDecimal: riskData.modifiers.modifierScore
      },
      {
        url: 'http://epa-bienestar.com.ar/fhir/StructureDefinition/risk-components',
        valueString: JSON.stringify(riskData.components)
      }
    ]
  };

  return await medplum.createResource(riskAssessment);
}

// ============================================================================
// DETECCIÓN DE CAMBIOS
// ============================================================================

async function detectSignificantChange(
  medplum: MedplumClient,
  patientId: string,
  currentRisk: CVDRiskData
): Promise<RiskChange | null> {
  try {
    // Obtener la evaluación anterior (penúltima)
    const previousAssessments = await medplum.searchResources('RiskAssessment', {
      subject: `Patient/${patientId}`,
      _sort: '-occurrence-date',
      _count: '2'
    });

    if (previousAssessments.length < 2) {
      console.log('  ℹ️  Primera evaluación o sin histórico');
      return null;
    }

    const previous = previousAssessments[1]; // La anterior
    const previousRisk = previous.prediction?.[0]?.probabilityDecimal
      ? previous.prediction[0].probabilityDecimal * 100
      : 0;

    const delta = currentRisk.adjustedRisk - previousRisk;
    const absDelta = Math.abs(delta);

    // Verificar cambio de categoría
    const previousCategory = previous.prediction?.[0]?.qualitativeRisk?.coding?.[0]?.code;
    const categoryChanged = previousCategory !== currentRisk.category.level;

    // Cambio significativo: >5 puntos O cambio de categoría
    if (absDelta >= CONFIG.SIGNIFICANT_CHANGE || categoryChanged) {
      return {
        delta,
        previousRisk,
        currentRisk: currentRisk.adjustedRisk,
        categoryChanged,
        previousCategory: previousCategory || 'unknown',
        currentCategory: currentRisk.category.level,
        description: delta > 0
          ? `Aumento de ${absDelta.toFixed(1)} puntos`
          : `Reducción de ${absDelta.toFixed(1)} puntos`,
        sustained: false // TODO: implementar lógica de tendencia sostenida
      };
    }

    return null;
  } catch (error) {
    console.error('Error detectando cambios:', error);
    return null;
  }
}

interface RiskChange {
  delta: number;
  previousRisk: number;
  currentRisk: number;
  categoryChanged: boolean;
  previousCategory: string;
  currentCategory: string;
  description: string;
  sustained: boolean;
}

// ============================================================================
// MANEJO DE CAMBIOS Y NOTIFICACIONES
// ============================================================================

async function handleRiskChange(
  medplum: MedplumClient,
  sesClient: SESClient,
  patient: Patient,
  riskData: CVDRiskData,
  change: RiskChange
): Promise<void> {
  // 1. Crear Task para el equipo médico
  await createMedicalReviewTask(medplum, patient, riskData, change);

  // 2. Enviar notificación por email
  await sendEmailNotification(sesClient, patient, riskData, change);
}

async function createMedicalReviewTask(
  medplum: MedplumClient,
  patient: Patient,
  riskData: CVDRiskData,
  change: RiskChange
): Promise<void> {
  const priority = change.delta > 10 || riskData.category.level === 'very-high'
    ? 'urgent'
    : riskData.category.level === 'high'
    ? 'asap'
    : 'routine';

  const dueDate = new Date();
  dueDate.setDate(dueDate.getDate() + (priority === 'urgent' ? 3 : 7));

  const task: Task = {
    resourceType: 'Task',
    status: 'requested',
    intent: 'order',
    priority,
    code: {
      coding: [{
        system: 'http://epa-bienestar.com.ar/fhir/CodeSystem/task-type',
        code: 'cardiovascular-risk-review',
        display: 'Revisión de Riesgo Cardiovascular'
      }]
    },
    description: `Revisar cambio significativo en riesgo CV: ${change.description}. ` +
                `Riesgo actual: ${riskData.adjustedRisk.toFixed(1)}% (${riskData.category.display})`,
    for: { reference: `Patient/${patient.id}` },
    authoredOn: new Date().toISOString(),
    restriction: {
      period: {
        end: dueDate.toISOString()
      }
    },
    note: [{
      text: `Componentes: PA ${riskData.components.sbp} mmHg, ` +
            `Colesterol ${riskData.components.cholesterol} mg/dL, ` +
            `${riskData.components.smoking ? 'Fumadora' : 'No fumadora'}, ` +
            `${riskData.components.diabetes ? 'Diabética' : 'Sin diabetes'}`
    }]
  };

  await medplum.createResource(task);
  console.log(`  ✅ Task creada con prioridad: ${priority}`);
}

async function sendEmailNotification(
  sesClient: SESClient,
  patient: Patient,
  riskData: CVDRiskData,
  change: RiskChange
): Promise<void> {
  const patientName = patient.name?.[0]?.text || 'Paciente';
  const patientEmail = patient.telecom?.find(t => t.system === 'email')?.value;

  if (!patientEmail) {
    console.log('  ⚠️  Paciente sin email, notificación omitida');
    return;
  }

  const subject = `EPA Bienestar - Actualización de Riesgo Cardiovascular`;
  
  const htmlBody = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .risk-card { background: white; border-left: 5px solid ${riskData.category.color}; padding: 20px; margin: 20px 0; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .risk-value { font-size: 48px; font-weight: bold; color: ${riskData.category.color}; margin: 10px 0; }
        .change { padding: 15px; background: ${change.delta > 0 ? '#ffebee' : '#e8f5e9'}; border-radius: 5px; margin: 20px 0; }
        .recommendation { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; border-radius: 5px; }
        .footer { text-align: center; color: #666; font-size: 12px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; }
        ul { padding-left: 20px; }
        li { margin: 10px 0; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🫀 Evaluación de Riesgo Cardiovascular</h1>
          <p>Programa Mujer - Grupo C Menopausia</p>
        </div>
        
        <div class="content">
          <p>Estimada ${patientName},</p>
          
          <p>Hemos completado su evaluación semanal de riesgo cardiovascular con los datos más recientes.</p>
          
          <div class="risk-card">
            <h2 style="margin-top: 0; color: ${riskData.category.color};">${riskData.category.display}</h2>
            <div class="risk-value">${riskData.adjustedRisk.toFixed(1)}%</div>
            <p style="color: #666; margin-bottom: 0;">Riesgo de evento cardiovascular a 10 años</p>
          </div>
          
          <div class="change">
            <h3 style="margin-top: 0;">📊 Cambio desde última evaluación:</h3>
            <p style="font-size: 18px; font-weight: bold; color: ${change.delta > 0 ? '#d32f2f' : '#388e3c'};">
              ${change.delta > 0 ? '↑' : '↓'} ${Math.abs(change.delta).toFixed(1)} puntos porcentuales
            </p>
            <p>${change.description}</p>
          </div>
          
          ${generateRecommendationsHTML(riskData)}
          
          <div class="recommendation">
            <h3 style="margin-top: 0;">💡 Próximos pasos:</h3>
            <ul>
              ${getPriorityActions(riskData).map(action => `<li>${action}</li>`).join('')}
            </ul>
          </div>
          
          <p>Para ver más detalles y acceder a su Plan Bienestar 100 Días personalizado, ingrese a su cuenta en <a href="https://app.epa-bienestar.com.ar">EPA Bienestar</a>.</p>
          
          <p>Si tiene alguna pregunta o inquietud, no dude en contactar a su equipo de cardiología.</p>
          
          <p>Saludos cordiales,<br>
          <strong>Equipo EPA Bienestar IA</strong></p>
        </div>
        
        <div class="footer">
          <p>Este mensaje fue generado automáticamente por el sistema de evaluación de riesgo cardiovascular.</p>
          <p>© 2024 EPA Bienestar IA - Todos los derechos reservados</p>
        </div>
      </div>
    </body>
    </html>
  `;

  const command = new SendEmailCommand({
    Source: CONFIG.SES_FROM_EMAIL,
    Destination: {
      ToAddresses: [patientEmail],
      BccAddresses: [CONFIG.SES_FROM_EMAIL] // Copia al equipo
    },
    Message: {
      Subject: { Data: subject },
      Body: {
        Html: { Data: htmlBody }
      }
    }
  });

  try {
    await sesClient.send(command);
    console.log(`  📧 Email enviado a: ${patientEmail}`);
  } catch (error) {
    console.error('  ❌ Error enviando email:', error);
  }
}

function generateRecommendationsHTML(riskData: CVDRiskData): string {
  const recs: string[] = [];

  if (riskData.components.smoking) {
    recs.push('<li><strong>Cesación tabáquica:</strong> Eliminar el tabaquismo podría reducir su riesgo en hasta 5-7 puntos.</li>');
  }

  if (riskData.components.sbp >= 140) {
    recs.push('<li><strong>Control de presión arterial:</strong> Mantener PA <130/80 mmHg mediante medicación y cambios de estilo de vida.</li>');
  }

  if (riskData.components.cholesterol >= 200) {
    recs.push('<li><strong>Manejo de colesterol:</strong> Dieta mediterránea y considerar estatinas según indicación médica.</li>');
  }

  if (riskData.modifiers.hypothyroidism && riskData.modifiers.elevatedLDL) {
    recs.push('<li><strong>Optimización tiroidea:</strong> Ajustar dosis de levotiroxina para normalizar TSH y reducir LDL.</li>');
  }

  if (riskData.modifiers.pcos) {
    recs.push('<li><strong>Manejo de PCOS:</strong> Metformina o myo-inositol para mejorar resistencia insulínica.</li>');
  }

  if (recs.length === 0) {
    return '<div class="recommendation"><h3 style="margin-top: 0;">✅ Recomendaciones:</h3><p>Continúe con sus hábitos saludables actuales.</p></div>';
  }

  return `<div class="recommendation"><h3 style="margin-top: 0;">📋 Recomendaciones específicas:</h3><ul>${recs.join('')}</ul></div>`;
}

function getPriorityActions(riskData: CVDRiskData): string[] {
  const actions: string[] = [];

  if (riskData.category.level === 'very-high' || riskData.category.level === 'high') {
    actions.push('Agendar consulta con cardiología en los próximos 7 días');
    actions.push('Revisión de su Plan Bienestar 100 Días con ajustes intensivos');
  } else if (riskData.category.level === 'moderate') {
    actions.push('Implementar MoveMicro: 4-6 sesiones de ejercicio acumulado por día');
    actions.push('Seguimiento con nutrición para optimización de dieta');
  } else {
    actions.push('Mantener estilo de vida saludable actual');
    actions.push('Control anual de factores de riesgo');
  }

  return actions;
}

// ============================================================================
// ACTUALIZACIÓN DE CAREPLAN
// ============================================================================

async function updateCarePlanIfNeeded(
  medplum: MedplumClient,
  patient: Patient,
  riskData: CVDRiskData
): Promise<void> {
  // TODO: Implementar lógica de actualización de CarePlan
  // basado en cambios de categoría de riesgo
  
  console.log('  📋 Actualización de CarePlan pendiente de implementación');
}

// ============================================================================
// FUNCIONES AUXILIARES
// ============================================================================

function calculateAge(birthDate: string): number {
  const today = new Date();
  const birth = new Date(birthDate);
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  
  return age;
}

function getAnswerBoolean(
  qr: QuestionnaireResponse | null,
  linkId: string
): boolean {
  if (!qr || !qr.item) return false;
  
  const findAnswer = (items: any[]): boolean => {
    for (const item of items) {
      if (item.linkId === linkId && item.answer?.[0]?.valueBoolean !== undefined) {
        return item.answer[0].valueBoolean;
      }
      if (item.item) {
        const result = findAnswer(item.item);
        if (result !== false) return result;
      }
    }
    return false;
  };
  
  return findAnswer(qr.item);
}

function getAnswerInteger(
  qr: QuestionnaireResponse | null,
  linkId: string
): number | undefined {
  if (!qr || !qr.item) return undefined;
  
  const findAnswer = (items: any[]): number | undefined => {
    for (const item of items) {
      if (item.linkId === linkId && item.answer?.[0]?.valueInteger !== undefined) {
        return item.answer[0].valueInteger;
      }
      if (item.item) {
        const result = findAnswer(item.item);
        if (result !== undefined) return result;
      }
    }
    return undefined;
  };
  
  return findAnswer(qr.item);
}

function formatModifiers(modifiers: MenopauseModifiers): string {
  const active: string[] = [];
  
  if (modifiers.earlyMenopause) active.push('Menopausia temprana');
  if (modifiers.pcos) active.push('PCOS');
  if (modifiers.preeclampsia) active.push('Historia de preeclampsia');
  if (modifiers.gestationalDiabetes) active.push('Diabetes gestacional');
  if (modifiers.hypothyroidism) active.push('Hipotiroidismo');
  if (modifiers.familyHistory) active.push('Historia familiar CV');
  
  return active.length > 0 ? active.join(', ') : 'Ninguno';
}
