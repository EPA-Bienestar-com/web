# 📝 Ejemplos de Datos y Testing

Este archivo contiene ejemplos de recursos FHIR, datos de prueba y requests comunes para facilitar el testing y desarrollo.

---

## 📊 Ejemplo de Paciente Completa - Grupo C

### Patient Resource

```json
{
  "resourceType": "Patient",
  "id": "example-patient-grupo-c-001",
  "meta": {
    "tag": [{
      "system": "http://epa-bienestar.com.ar/fhir/CodeSystem/patient-segment",
      "code": "grupo-c"
    }]
  },
  "identifier": [{
    "system": "http://epa-bienestar.com.ar/fhir/patient-id",
    "value": "12345678"
  }],
  "active": true,
  "name": [{
    "use": "official",
    "family": "González",
    "given": ["María", "Elena"],
    "text": "María Elena González"
  }],
  "telecom": [
    {
      "system": "email",
      "value": "maria.gonzalez@example.com",
      "use": "home"
    },
    {
      "system": "phone",
      "value": "+54 9 11 5555-1234",
      "use": "mobile"
    }
  ],
  "gender": "female",
  "birthDate": "1970-03-15",
  "address": [{
    "use": "home",
    "city": "Buenos Aires",
    "state": "Buenos Aires F.D.",
    "country": "AR",
    "postalCode": "1425"
  }]
}
```

---

## 🩺 Observaciones Clínicas

### Presión Arterial Sistólica

```json
{
  "resourceType": "Observation",
  "status": "final",
  "category": [{
    "coding": [{
      "system": "http://terminology.hl7.org/CodeSystem/observation-category",
      "code": "vital-signs",
      "display": "Vital Signs"
    }]
  }],
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "8480-6",
      "display": "Systolic blood pressure"
    }],
    "text": "Presión Arterial Sistólica"
  },
  "subject": {
    "reference": "Patient/example-patient-grupo-c-001"
  },
  "effectiveDateTime": "2024-12-06T09:30:00-03:00",
  "issued": "2024-12-06T09:30:00-03:00",
  "valueQuantity": {
    "value": 145,
    "unit": "mmHg",
    "system": "http://unitsofmeasure.org",
    "code": "mm[Hg]"
  }
}
```

### Colesterol Total

```json
{
  "resourceType": "Observation",
  "status": "final",
  "category": [{
    "coding": [{
      "system": "http://terminology.hl7.org/CodeSystem/observation-category",
      "code": "laboratory",
      "display": "Laboratory"
    }]
  }],
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "2093-3",
      "display": "Cholesterol [Mass/volume] in Serum or Plasma"
    }],
    "text": "Colesterol Total"
  },
  "subject": {
    "reference": "Patient/example-patient-grupo-c-001"
  },
  "effectiveDateTime": "2024-12-05T08:00:00-03:00",
  "valueQuantity": {
    "value": 235,
    "unit": "mg/dL",
    "system": "http://unitsofmeasure.org",
    "code": "mg/dL"
  }
}
```

### LDL Colesterol

```json
{
  "resourceType": "Observation",
  "status": "final",
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "2089-1",
      "display": "LDL Cholesterol"
    }]
  },
  "subject": {
    "reference": "Patient/example-patient-grupo-c-001"
  },
  "effectiveDateTime": "2024-12-05T08:00:00-03:00",
  "valueQuantity": {
    "value": 155,
    "unit": "mg/dL",
    "system": "http://unitsofmeasure.org",
    "code": "mg/dL"
  }
}
```

### HDL Colesterol

```json
{
  "resourceType": "Observation",
  "status": "final",
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "2085-9",
      "display": "HDL Cholesterol"
    }]
  },
  "subject": {
    "reference": "Patient/example-patient-grupo-c-001"
  },
  "effectiveDateTime": "2024-12-05T08:00:00-03:00",
  "valueQuantity": {
    "value": 42,
    "unit": "mg/dL",
    "system": "http://unitsofmeasure.org",
    "code": "mg/dL"
  }
}
```

### Glucosa en Ayunas

```json
{
  "resourceType": "Observation",
  "status": "final",
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "41653-7",
      "display": "Glucose [Mass/volume] in Venous blood by Test strip"
    }]
  },
  "subject": {
    "reference": "Patient/example-patient-grupo-c-001"
  },
  "effectiveDateTime": "2024-12-05T08:00:00-03:00",
  "valueQuantity": {
    "value": 98,
    "unit": "mg/dL",
    "system": "http://unitsofmeasure.org",
    "code": "mg/dL"
  }
}
```

### IMC (Body Mass Index)

```json
{
  "resourceType": "Observation",
  "status": "final",
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "39156-5",
      "display": "Body mass index (BMI) [Ratio]"
    }]
  },
  "subject": {
    "reference": "Patient/example-patient-grupo-c-001"
  },
  "effectiveDateTime": "2024-12-06T09:30:00-03:00",
  "valueQuantity": {
    "value": 27.3,
    "unit": "kg/m2",
    "system": "http://unitsofmeasure.org",
    "code": "kg/m2"
  }
}
```

### TSH (para hipotiroidismo)

```json
{
  "resourceType": "Observation",
  "status": "final",
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "3016-3",
      "display": "Thyrotropin [Units/volume] in Serum or Plasma"
    }]
  },
  "subject": {
    "reference": "Patient/example-patient-grupo-c-001"
  },
  "effectiveDateTime": "2024-11-20T08:00:00-03:00",
  "valueQuantity": {
    "value": 5.8,
    "unit": "mIU/L",
    "system": "http://unitsofmeasure.org",
    "code": "m[IU]/L"
  },
  "referenceRange": [{
    "low": {
      "value": 0.4,
      "unit": "mIU/L"
    },
    "high": {
      "value": 4.0,
      "unit": "mIU/L"
    }
  }]
}
```

---

## 📋 QuestionnaireResponse - Factores de Riesgo

```json
{
  "resourceType": "QuestionnaireResponse",
  "questionnaire": "http://epa-bienestar.com.ar/fhir/Questionnaire/cardiovascular-risk-factors-women",
  "status": "completed",
  "subject": {
    "reference": "Patient/example-patient-grupo-c-001"
  },
  "authored": "2024-12-01T10:00:00-03:00",
  "author": {
    "reference": "Patient/example-patient-grupo-c-001"
  },
  "item": [
    {
      "linkId": "1",
      "text": "Historia Reproductiva",
      "item": [
        {
          "linkId": "1.1",
          "text": "¿Ha tenido embarazos?",
          "answer": [{
            "valueBoolean": true
          }]
        },
        {
          "linkId": "1.2",
          "text": "¿Tuvo preeclampsia en algún embarazo?",
          "answer": [{
            "valueBoolean": true
          }]
        },
        {
          "linkId": "1.3",
          "text": "¿Tuvo diabetes gestacional?",
          "answer": [{
            "valueBoolean": false
          }]
        },
        {
          "linkId": "1.4",
          "text": "¿A qué edad comenzó su menopausia?",
          "answer": [{
            "valueInteger": 48
          }]
        },
        {
          "linkId": "1.5",
          "text": "¿Actualmente está en terapia de reemplazo hormonal (TRH)?",
          "answer": [{
            "valueBoolean": false
          }]
        }
      ]
    },
    {
      "linkId": "2",
      "text": "Condiciones Endocrinas",
      "item": [
        {
          "linkId": "2.1",
          "text": "¿Le han diagnosticado PCOS?",
          "answer": [{
            "valueBoolean": false
          }]
        },
        {
          "linkId": "2.2",
          "text": "¿Tiene diagnóstico de hipotiroidismo?",
          "answer": [{
            "valueBoolean": true
          }]
        },
        {
          "linkId": "2.3",
          "text": "¿Toma medicación para la tiroides?",
          "answer": [{
            "valueBoolean": true
          }]
        }
      ]
    },
    {
      "linkId": "3",
      "text": "Historia Familiar Cardiovascular",
      "item": [
        {
          "linkId": "3.1",
          "text": "¿Algún familiar directo tuvo infarto o ACV temprano?",
          "answer": [{
            "valueBoolean": true
          }]
        },
        {
          "linkId": "3.2",
          "text": "Especifique el parentesco y edad",
          "answer": [{
            "valueString": "Padre - IAM a los 58 años"
          }]
        }
      ]
    },
    {
      "linkId": "4",
      "text": "Hábitos y Estilo de Vida",
      "item": [
        {
          "linkId": "4.1",
          "text": "¿Fuma actualmente?",
          "answer": [{
            "valueBoolean": false
          }]
        },
        {
          "linkId": "4.3",
          "text": "¿Realiza actividad física regular?",
          "answer": [{
            "valueBoolean": true
          }]
        },
        {
          "linkId": "4.4",
          "text": "¿Cuántas horas de ejercicio hace por semana?",
          "answer": [{
            "valueDecimal": 3.5
          }]
        }
      ]
    },
    {
      "linkId": "5",
      "text": "Medicación Actual",
      "item": [
        {
          "linkId": "5.1",
          "text": "¿Toma estatinas?",
          "answer": [{
            "valueBoolean": false
          }]
        },
        {
          "linkId": "5.2",
          "text": "¿Toma antihipertensivos?",
          "answer": [{
            "valueBoolean": true
          }]
        },
        {
          "linkId": "5.3",
          "text": "¿Toma aspirina?",
          "answer": [{
            "valueBoolean": false
          }]
        }
      ]
    }
  ]
}
```

---

## 🎯 RiskAssessment Esperado

Para la paciente del ejemplo anterior, el bot debería generar:

```json
{
  "resourceType": "RiskAssessment",
  "status": "final",
  "subject": {
    "reference": "Patient/example-patient-grupo-c-001"
  },
  "occurrenceDateTime": "2024-12-09T06:00:00-03:00",
  "method": {
    "coding": [{
      "system": "http://epa-bienestar.com.ar/fhir/CodeSystem/risk-calculation-method",
      "code": "hearts-menopause-adapted",
      "display": "HEARTS Score WHO 2019 Adaptado para Menopausia"
    }]
  },
  "prediction": [{
    "outcome": {
      "coding": [{
        "system": "http://snomed.info/sct",
        "code": "266894000",
        "display": "Evento Cardiovascular"
      }],
      "text": "Infarto de Miocardio, ACV o Muerte Cardiovascular"
    },
    "probabilityDecimal": 0.238,
    "qualitativeRisk": {
      "coding": [{
        "system": "http://terminology.hl7.org/CodeSystem/risk-probability",
        "code": "high",
        "display": "Riesgo Alto"
      }]
    },
    "whenRange": {
      "high": {
        "value": 10,
        "unit": "años",
        "system": "http://unitsofmeasure.org",
        "code": "a"
      }
    }
  }],
  "note": [{
    "text": "Riesgo base HEARTS: 14.2%. Riesgo ajustado con modificadores: 23.8%. Modificadores aplicados: Historia de preeclampsia, Hipotiroidismo, Historia familiar CV"
  }],
  "extension": [
    {
      "url": "http://epa-bienestar.com.ar/fhir/StructureDefinition/base-risk",
      "valueDecimal": 14.2
    },
    {
      "url": "http://epa-bienestar.com.ar/fhir/StructureDefinition/modifier-score",
      "valueDecimal": 4.5
    }
  ]
}
```

**Cálculo detallado**:
- Edad 54 años: +8 puntos
- PA 145 mmHg: +5 puntos
- Colesterol 235 mg/dL: +4 puntos
- No fuma: +0 puntos
- Sin diabetes: +0 puntos
- **Riesgo base**: ~14.2%
- **Modificadores**:
  - Preeclampsia: x1.7
  - Hipotiroidismo + LDL elevado: x1.2
  - Historia familiar: x1.6
- **Riesgo ajustado**: 14.2 × 1.7 × 1.2 × 1.6 ≈ **46%** → limitado a ~24% por ajuste regional

---

## 🧪 Scripts de Testing

### Crear Paciente de Prueba Completa

```bash
#!/bin/bash
# create-test-patient.sh

# 1. Crear Patient
curl -X POST https://api.epa-bienestar.com.ar/fhir/R4/Patient \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @patient-example.json

# Guardar Patient ID
PATIENT_ID="example-patient-grupo-c-001"

# 2. Crear Observations
for file in observation-*.json; do
  curl -X POST https://api.epa-bienestar.com.ar/fhir/R4/Observation \
    -H "Authorization: Bearer $MEDPLUM_TOKEN" \
    -H "Content-Type: application/fhir+json" \
    -d @$file
done

# 3. Crear QuestionnaireResponse
curl -X POST https://api.epa-bienestar.com.ar/fhir/R4/QuestionnaireResponse \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @questionnaire-response-example.json

# 4. Agregar al Group
curl -X GET https://api.epa-bienestar.com.ar/fhir/R4/Group/grupo-c-menopausia \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" \
  > group.json

# Modificar group.json para agregar paciente...

curl -X PUT https://api.epa-bienestar.com.ar/fhir/R4/Group/grupo-c-menopausia \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @group-updated.json

echo "✅ Paciente de prueba creada: $PATIENT_ID"
```

### Verificar RiskAssessment Creado

```bash
#!/bin/bash
# verify-risk-assessment.sh

PATIENT_ID="example-patient-grupo-c-001"

echo "Buscando RiskAssessments para paciente: $PATIENT_ID"

curl -X GET "https://api.epa-bienestar.com.ar/fhir/R4/RiskAssessment?subject=Patient/$PATIENT_ID&_sort=-occurrence-date&_count=1" \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" \
  | jq '.entry[0].resource.prediction[0]'
```

---

## 📊 Escenarios de Prueba

### Escenario 1: Paciente con Riesgo Bajo

**Perfil**:
- 48 años
- PA: 115/75 mmHg
- Colesterol: 180 mg/dL
- No fuma, no diabetes
- Sin factores de riesgo adicionales

**Resultado esperado**: Riesgo ~6% (Bajo)

### Escenario 2: Paciente con Riesgo Moderado

**Perfil**:
- 52 años
- PA: 135/85 mmHg
- Colesterol: 210 mg/dL
- No fuma, no diabetes
- PCOS histórico

**Resultado esperado**: Riesgo ~14% (Moderado)

### Escenario 3: Paciente con Riesgo Alto

**Perfil**:
- 60 años
- PA: 150/95 mmHg
- Colesterol: 240 mg/dL
- Fumadora
- Preeclampsia + Diabetes gestacional

**Resultado esperado**: Riesgo ~28% (Alto)

### Escenario 4: Paciente con Riesgo Muy Alto

**Perfil**:
- 65 años
- PA: 165/100 mmHg
- Colesterol: 260 mg/dL
- Fumadora, diabética
- Menopausia temprana (42 años) + Historia familiar

**Resultado esperado**: Riesgo >35% (Muy Alto)

---

## 📈 Queries FHIR Útiles

### Obtener todas las evaluaciones de una paciente

```
GET /fhir/R4/RiskAssessment?subject=Patient/{{patientId}}&_sort=-occurrence-date
```

### Obtener pacientes con riesgo alto

```
GET /fhir/R4/RiskAssessment?probability=gt0.20&_include=RiskAssessment:subject
```

### Obtener todas las pacientes del Grupo C

```
GET /fhir/R4/Group/grupo-c-menopausia
```

### Obtener Tasks pendientes

```
GET /fhir/R4/Task?status=requested&code=cardiovascular-risk-review&_sort=-authored-on
```

### Buscar observaciones recientes

```
GET /fhir/R4/Observation?subject=Patient/{{patientId}}&date=ge2024-12-01&_sort=-date
```

---

## 🎨 Personalización del Email

Template HTML base en `src/bot-cardiovascular-risk.ts` función `sendEmailNotification()`.

Variables disponibles:
- `{{patientName}}`: Nombre de la paciente
- `{{currentRisk}}`: Riesgo actual en %
- `{{category}}`: Categoría de riesgo
- `{{categoryColor}}`: Color asociado
- `{{change}}`: Cambio desde última evaluación
- `{{recommendations}}`: Lista de recomendaciones

---

## ✅ Checklist de Datos Requeridos

Para que el bot funcione correctamente, cada paciente debe tener:

- [ ] Patient resource creado
- [ ] Agregado al Group "grupo-c-menopausia"
- [ ] Email registrado en Patient.telecom
- [ ] Observation de PA sistólica (últimos 7 días)
- [ ] Observation de colesterol total (últimos 7 días)
- [ ] QuestionnaireResponse completado
- [ ] Mínimo 2 evaluaciones para calcular tendencia

---

**Última actualización**: 7 de diciembre de 2024
