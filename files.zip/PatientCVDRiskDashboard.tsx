/**
 * Dashboard de Riesgo Cardiovascular - Vista Paciente
 * EPA Bienestar IA
 */

import React, { useEffect, useState } from 'react';
import { useMedplum } from '@medplum/react';
import {
  Patient,
  RiskAssessment,
  Observation,
  QuestionnaireResponse
} from '@medplum/fhirtypes';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart
} from 'recharts';

interface RiskHistoryPoint {
  date: string;
  risk: number;
  category: string;
  color: string;
}

export function PatientCVDRiskDashboard() {
  const medplum = useMedplum();
  const [loading, setLoading] = useState(true);
  const [patient, setPatient] = useState<Patient | null>(null);
  const [currentRisk, setCurrentRisk] = useState<RiskAssessment | null>(null);
  const [riskHistory, setRiskHistory] = useState<RiskHistoryPoint[]>([]);
  const [latestObservations, setLatestObservations] = useState<any>({});

  useEffect(() => {
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    try {
      // 1. Obtener paciente actual (usando el contexto de sesión)
      const currentPatient = await medplum.getProfile();
      setPatient(currentPatient as Patient);

      // 2. Obtener evaluación más reciente
      const assessments = await medplum.searchResources('RiskAssessment', {
        subject: `Patient/${currentPatient.id}`,
        _sort: '-occurrence-date',
        _count: '1'
      });

      if (assessments.length > 0) {
        setCurrentRisk(assessments[0]);
      }

      // 3. Obtener histórico (últimos 12 meses)
      const twelveMonthsAgo = new Date();
      twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12);

      const historicalAssessments = await medplum.searchResources('RiskAssessment', {
        subject: `Patient/${currentPatient.id}`,
        'occurrence-date': `ge${twelveMonthsAgo.toISOString().split('T')[0]}`,
        _sort: 'occurrence-date',
        _count: '100'
      });

      const history: RiskHistoryPoint[] = historicalAssessments.map(assessment => ({
        date: assessment.occurrenceDateTime?.split('T')[0] || '',
        risk: (assessment.prediction?.[0]?.probabilityDecimal || 0) * 100,
        category: assessment.prediction?.[0]?.qualitativeRisk?.coding?.[0]?.display || '',
        color: getCategoryColor(assessment.prediction?.[0]?.qualitativeRisk?.coding?.[0]?.code || '')
      }));

      setRiskHistory(history);

      // 4. Obtener últimas observaciones
      const obs = await getLatestObservations(currentPatient.id!);
      setLatestObservations(obs);

      setLoading(false);
    } catch (error) {
      console.error('Error cargando datos:', error);
      setLoading(false);
    }
  }

  async function getLatestObservations(patientId: string) {
    const codes = {
      sbp: '8480-6',
      cholesterol: '2093-3',
      ldl: '2089-1',
      hdl: '2085-9',
      glucose: '41653-7',
      bmi: '39156-5',
      weight: '29463-7',
      activity: '55411-3'
    };

    const results: any = {};

    for (const [key, code] of Object.entries(codes)) {
      try {
        const obs = await medplum.searchResources('Observation', {
          subject: `Patient/${patientId}`,
          code: code,
          _sort: '-date',
          _count: '1'
        });

        if (obs.length > 0) {
          results[key] = obs[0];
        }
      } catch (error) {
        console.error(`Error obteniendo ${key}:`, error);
      }
    }

    return results;
  }

  function getCategoryColor(category: string): string {
    switch (category) {
      case 'low': return '#4CAF50';
      case 'moderate': return '#FF9800';
      case 'high': return '#F44336';
      case 'very-high': return '#B71C1C';
      default: return '#9E9E9E';
    }
  }

  if (loading) {
    return (
      <div style={styles.loadingContainer}>
        <div style={styles.spinner}></div>
        <p>Cargando su información...</p>
      </div>
    );
  }

  if (!currentRisk) {
    return (
      <div style={styles.container}>
        <div style={styles.emptyState}>
          <h2>👋 Bienvenida al Programa Mujer</h2>
          <p>Aún no tenemos suficientes datos para calcular su riesgo cardiovascular.</p>
          <p>Por favor, complete su evaluación inicial y asegúrese de tener registrados:</p>
          <ul>
            <li>Presión arterial</li>
            <li>Valores de colesterol</li>
            <li>Cuestionario de factores de riesgo</li>
          </ul>
          <button style={styles.primaryButton}>Completar Evaluación</button>
        </div>
      </div>
    );
  }

  const currentRiskValue = (currentRisk.prediction?.[0]?.probabilityDecimal || 0) * 100;
  const currentCategory = currentRisk.prediction?.[0]?.qualitativeRisk?.coding?.[0]?.code || 'unknown';
  const currentCategoryDisplay = currentRisk.prediction?.[0]?.qualitativeRisk?.coding?.[0]?.display || '';
  const categoryColor = getCategoryColor(currentCategory);

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <h1 style={styles.title}>🫀 Mi Riesgo Cardiovascular</h1>
        <p style={styles.subtitle}>
          Actualizado: {new Date(currentRisk.occurrenceDateTime!).toLocaleDateString('es-AR')}
        </p>
      </div>

      {/* Tarjeta Principal de Riesgo */}
      <div style={{...styles.riskCard, borderColor: categoryColor}}>
        <div style={styles.riskCardHeader}>
          <h2 style={styles.riskCategoryLabel}>{currentCategoryDisplay}</h2>
          <div style={{...styles.riskBadge, backgroundColor: categoryColor}}>
            {getRiskIcon(currentCategory)}
          </div>
        </div>
        
        <div style={styles.riskValueContainer}>
          <span style={{...styles.riskValue, color: categoryColor}}>
            {currentRiskValue.toFixed(1)}%
          </span>
          <span style={styles.riskValueLabel}>
            Probabilidad de evento cardiovascular en 10 años
          </span>
        </div>

        {riskHistory.length > 1 && (
          <div style={styles.trendIndicator}>
            {getTrendIndicator(riskHistory)}
          </div>
        )}
      </div>

      {/* Gráfico de Tendencia */}
      {riskHistory.length > 1 && (
        <div style={styles.chartCard}>
          <h3 style={styles.cardTitle}>📈 Evolución de su Riesgo</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={riskHistory}>
              <defs>
                <linearGradient id="colorRisk" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={categoryColor} stopOpacity={0.8}/>
                  <stop offset="95%" stopColor={categoryColor} stopOpacity={0.1}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(date) => new Date(date).toLocaleDateString('es-AR', { month: 'short', day: 'numeric' })}
              />
              <YAxis 
                label={{ value: 'Riesgo (%)', angle: -90, position: 'insideLeft' }}
                domain={[0, 50]}
              />
              <Tooltip 
                formatter={(value: number) => `${value.toFixed(1)}%`}
                labelFormatter={(date) => new Date(date).toLocaleDateString('es-AR')}
              />
              <Area 
                type="monotone" 
                dataKey="risk" 
                stroke={categoryColor} 
                strokeWidth={3}
                fillOpacity={1} 
                fill="url(#colorRisk)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Factores de Riesgo Actuales */}
      <div style={styles.factorsCard}>
        <h3 style={styles.cardTitle}>🔍 Sus Factores de Riesgo</h3>
        <div style={styles.factorsGrid}>
          {renderFactorCard('Presión Arterial', latestObservations.sbp, 'mmHg', '8480-6')}
          {renderFactorCard('Colesterol Total', latestObservations.cholesterol, 'mg/dL', '2093-3')}
          {renderFactorCard('LDL', latestObservations.ldl, 'mg/dL', '2089-1')}
          {renderFactorCard('HDL', latestObservations.hdl, 'mg/dL', '2085-9')}
          {renderFactorCard('Glucosa', latestObservations.glucose, 'mg/dL', '41653-7')}
          {renderFactorCard('IMC', latestObservations.bmi, 'kg/m²', '39156-5')}
        </div>
      </div>

      {/* Recomendaciones Personalizadas */}
      <div style={styles.recommendationsCard}>
        <h3 style={styles.cardTitle}>💡 Recomendaciones Personalizadas</h3>
        {getPersonalizedRecommendations(currentRisk, latestObservations)}
      </div>

      {/* Acciones Rápidas */}
      <div style={styles.actionsCard}>
        <h3 style={styles.cardTitle}>🎯 Próximos Pasos</h3>
        <div style={styles.actionsGrid}>
          <button style={styles.actionButton}>
            📊 Registrar Mediciones
          </button>
          <button style={styles.actionButton}>
            🏃‍♀️ Iniciar MoveMicro
          </button>
          <button style={styles.actionButton}>
            🍎 Ver Plan Nutricional
          </button>
          <button style={styles.actionButton}>
            📅 Agendar Consulta
          </button>
        </div>
      </div>
    </div>
  );

  function renderFactorCard(label: string, observation: Observation | undefined, unit: string, code: string) {
    if (!observation) {
      return (
        <div style={styles.factorCard}>
          <div style={styles.factorLabel}>{label}</div>
          <div style={styles.factorValueMissing}>Sin datos</div>
          <div style={styles.factorDate}>-</div>
        </div>
      );
    }

    const value = observation.valueQuantity?.value || 0;
    const isNormal = isFactorNormal(code, value);
    
    return (
      <div style={styles.factorCard}>
        <div style={styles.factorLabel}>{label}</div>
        <div style={{
          ...styles.factorValue,
          color: isNormal ? '#4CAF50' : '#F44336'
        }}>
          {value} <span style={styles.factorUnit}>{unit}</span>
        </div>
        <div style={styles.factorDate}>
          {new Date(observation.effectiveDateTime!).toLocaleDateString('es-AR')}
        </div>
        {!isNormal && <div style={styles.factorAlert}>⚠️</div>}
      </div>
    );
  }

  function isFactorNormal(code: string, value: number): boolean {
    const ranges: Record<string, [number, number]> = {
      '8480-6': [90, 130],    // PA sistólica
      '2093-3': [0, 200],     // Colesterol total
      '2089-1': [0, 130],     // LDL
      '2085-9': [40, 200],    // HDL (min 40)
      '41653-7': [70, 100],   // Glucosa
      '39156-5': [18.5, 25]   // IMC
    };

    const range = ranges[code];
    if (!range) return true;

    return value >= range[0] && value <= range[1];
  }

  function getTrendIndicator(history: RiskHistoryPoint[]) {
    if (history.length < 2) return null;

    const recent = history.slice(-2);
    const change = recent[1].risk - recent[0].risk;

    if (Math.abs(change) < 1) {
      return (
        <div style={styles.trendStable}>
          ➡️ Estable (sin cambios significativos)
        </div>
      );
    }

    if (change > 0) {
      return (
        <div style={styles.trendUp}>
          ⬆️ Aumentó {Math.abs(change).toFixed(1)} puntos desde la última evaluación
        </div>
      );
    }

    return (
      <div style={styles.trendDown}>
        ⬇️ Disminuyó {Math.abs(change).toFixed(1)} puntos - ¡Excelente progreso!
      </div>
    );
  }

  function getRiskIcon(category: string): string {
    switch (category) {
      case 'low': return '✅';
      case 'moderate': return '⚠️';
      case 'high': return '🔴';
      case 'very-high': return '🚨';
      default: return '❓';
    }
  }

  function getPersonalizedRecommendations(risk: RiskAssessment, observations: any) {
    const recommendations = [];

    // Extraer componentes del riesgo desde la nota
    const note = risk.note?.[0]?.text || '';
    
    if (observations.sbp?.valueQuantity?.value >= 140) {
      recommendations.push({
        icon: '🩺',
        title: 'Control de Presión Arterial',
        description: 'Su presión arterial está elevada. Reducirla a <130/80 mmHg puede disminuir significativamente su riesgo.',
        action: 'Ver plan de reducción de PA'
      });
    }

    if (observations.cholesterol?.valueQuantity?.value >= 200) {
      recommendations.push({
        icon: '🥗',
        title: 'Optimización de Colesterol',
        description: 'Una dieta mediterránea rica en omega-3 puede reducir su colesterol naturalmente.',
        action: 'Ver plan nutricional'
      });
    }

    if (note.includes('Fumadora')) {
      recommendations.push({
        icon: '🚭',
        title: 'Cesación Tabáquica',
        description: 'Dejar de fumar podría reducir su riesgo en 5-7 puntos porcentuales.',
        action: 'Programa para dejar de fumar'
      });
    }

    if (recommendations.length === 0) {
      recommendations.push({
        icon: '✨',
        title: '¡Excelente!',
        description: 'Está manejando muy bien sus factores de riesgo. Continúe con sus hábitos saludables.',
        action: 'Ver Plan Bienestar 100 Días'
      });
    }

    return (
      <div style={styles.recommendationsList}>
        {recommendations.map((rec, index) => (
          <div key={index} style={styles.recommendationItem}>
            <div style={styles.recommendationIcon}>{rec.icon}</div>
            <div style={styles.recommendationContent}>
              <h4 style={styles.recommendationTitle}>{rec.title}</h4>
              <p style={styles.recommendationDescription}>{rec.description}</p>
              <button style={styles.recommendationAction}>{rec.action} →</button>
            </div>
          </div>
        ))}
      </div>
    );
  }
}

// ============================================================================
// ESTILOS
// ============================================================================

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
  },
  
  loadingContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '400px'
  },
  
  spinner: {
    width: '50px',
    height: '50px',
    border: '5px solid #f3f3f3',
    borderTop: '5px solid #667eea',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite'
  },
  
  header: {
    marginBottom: '30px'
  },
  
  title: {
    fontSize: '32px',
    fontWeight: 'bold',
    margin: '0 0 10px 0',
    color: '#1a1a1a'
  },
  
  subtitle: {
    fontSize: '14px',
    color: '#666',
    margin: 0
  },
  
  riskCard: {
    background: 'white',
    borderRadius: '16px',
    padding: '30px',
    marginBottom: '20px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
    borderLeft: '8px solid',
    borderLeftColor: '#667eea'
  },
  
  riskCardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px'
  },
  
  riskCategoryLabel: {
    fontSize: '24px',
    fontWeight: 'bold',
    margin: 0
  },
  
  riskBadge: {
    width: '60px',
    height: '60px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '32px'
  },
  
  riskValueContainer: {
    textAlign: 'center',
    padding: '20px 0'
  },
  
  riskValue: {
    fontSize: '72px',
    fontWeight: 'bold',
    display: 'block',
    lineHeight: 1
  },
  
  riskValueLabel: {
    fontSize: '16px',
    color: '#666',
    display: 'block',
    marginTop: '10px'
  },
  
  trendIndicator: {
    marginTop: '20px',
    paddingTop: '20px',
    borderTop: '1px solid #eee'
  },
  
  trendStable: {
    padding: '10px',
    background: '#f5f5f5',
    borderRadius: '8px',
    fontSize: '14px'
  },
  
  trendUp: {
    padding: '10px',
    background: '#ffebee',
    borderRadius: '8px',
    fontSize: '14px',
    color: '#c62828'
  },
  
  trendDown: {
    padding: '10px',
    background: '#e8f5e9',
    borderRadius: '8px',
    fontSize: '14px',
    color: '#2e7d32'
  },
  
  chartCard: {
    background: 'white',
    borderRadius: '16px',
    padding: '30px',
    marginBottom: '20px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
  },
  
  cardTitle: {
    fontSize: '20px',
    fontWeight: 'bold',
    marginTop: 0,
    marginBottom: '20px'
  },
  
  factorsCard: {
    background: 'white',
    borderRadius: '16px',
    padding: '30px',
    marginBottom: '20px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
  },
  
  factorsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
    gap: '15px'
  },
  
  factorCard: {
    background: '#f9f9f9',
    padding: '20px',
    borderRadius: '12px',
    position: 'relative'
  },
  
  factorLabel: {
    fontSize: '12px',
    color: '#666',
    marginBottom: '8px',
    textTransform: 'uppercase',
    fontWeight: '600',
    letterSpacing: '0.5px'
  },
  
  factorValue: {
    fontSize: '28px',
    fontWeight: 'bold',
    marginBottom: '5px'
  },
  
  factorValueMissing: {
    fontSize: '16px',
    color: '#999',
    fontStyle: 'italic'
  },
  
  factorUnit: {
    fontSize: '16px',
    fontWeight: 'normal',
    color: '#666'
  },
  
  factorDate: {
    fontSize: '11px',
    color: '#999'
  },
  
  factorAlert: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    fontSize: '20px'
  },
  
  recommendationsCard: {
    background: 'white',
    borderRadius: '16px',
    padding: '30px',
    marginBottom: '20px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
  },
  
  recommendationsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px'
  },
  
  recommendationItem: {
    display: 'flex',
    gap: '20px',
    padding: '20px',
    background: '#f9f9f9',
    borderRadius: '12px',
    alignItems: 'flex-start'
  },
  
  recommendationIcon: {
    fontSize: '40px',
    minWidth: '60px',
    textAlign: 'center'
  },
  
  recommendationContent: {
    flex: 1
  },
  
  recommendationTitle: {
    fontSize: '18px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  },
  
  recommendationDescription: {
    fontSize: '14px',
    color: '#666',
    margin: '0 0 12px 0',
    lineHeight: '1.5'
  },
  
  recommendationAction: {
    background: '#667eea',
    color: 'white',
    border: 'none',
    padding: '8px 16px',
    borderRadius: '6px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'background 0.2s'
  },
  
  actionsCard: {
    background: 'white',
    borderRadius: '16px',
    padding: '30px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
  },
  
  actionsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '15px'
  },
  
  actionButton: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    border: 'none',
    padding: '16px 24px',
    borderRadius: '10px',
    fontSize: '15px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'transform 0.2s, box-shadow 0.2s',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  },
  
  emptyState: {
    textAlign: 'center',
    padding: '60px 20px',
    background: 'white',
    borderRadius: '16px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
  },
  
  primaryButton: {
    background: '#667eea',
    color: 'white',
    border: 'none',
    padding: '14px 28px',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    marginTop: '20px'
  }
};
