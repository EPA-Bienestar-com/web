/**
 * EPA Bienestar IA — Curated ValueSets for Life's Essential 8
 * LOINC + SNOMED CT codes aligned with AHA LE8 framework
 * Segmented by determinant of health and life-stage group (A/B/C/D)
 */

export interface ConceptEntry {
  code: string;
  display: string;
  display_es: string;
  grupo?: string[]; // A | B | C | D
  determinante?: string; // behavioral | social | genetic | medical | environmental
}

// ─────────────────────────────────────────────────────────────────────────────
// LOINC — LE8 Component Panels
// ─────────────────────────────────────────────────────────────────────────────

export const LOINC_LE8_DIET: ConceptEntry[] = [
  { code: "75303-8",  display: "Dietary assessment panel",                          display_es: "Panel evaluación dietaria",              grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "61852-5",  display: "Dietary recall 24 hour",                            display_es: "Recordatorio 24 horas dieta",            grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "62944-9",  display: "PhenX - dietary intake 30d - fruits vegetables",    display_es: "Ingesta frutas y verduras 30 días",      grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "89561-5",  display: "How many servings of fish/seafood per week",        display_es: "Porciones pescado/mariscos por semana", grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "88056-7",  display: "Sodium intake 24 hour",                             display_es: "Ingesta sodio 24 horas",                 grupo: ["C","D"],         determinante: "behavioral" },
  { code: "94962-5",  display: "Mediterranean diet score",                          display_es: "Puntaje dieta mediterránea (MEPA)",      grupo: ["A","B","C","D"], determinante: "behavioral" },
];

export const LOINC_LE8_ACTIVITY: ConceptEntry[] = [
  { code: "68516-4",  display: "On those days that you engage in moderate to strenuous exercise, how many minutes, on average, do you exercise", display_es: "Minutos de actividad moderada-intensa", grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "89555-7",  display: "How many days per week did you engage in moderate to strenuous physical activity in the last 30 days",          display_es: "Días por semana actividad moderada",    grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "82290-8",  display: "Frequency of moderate to vigorous aerobic physical activity",                                                   display_es: "Frecuencia actividad aeróbica",          grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "55423-8",  display: "Number of steps in unspecified time Pedometer",                                                                 display_es: "Número de pasos (podómetro)",             grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "77593-3",  display: "Muscle-strengthening physical activity in the last 30 days",                                                    display_es: "Ejercicio de fortalecimiento muscular",  grupo: ["C","D"],         determinante: "behavioral" },
];

export const LOINC_LE8_NICOTINE: ConceptEntry[] = [
  { code: "72166-2",  display: "Tobacco smoking status",                              display_es: "Estado tabaquismo",                      grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "81229-7",  display: "Current tobacco - smokeless tobacco use",              display_es: "Uso tabaco sin humo actual",             grupo: ["A","B"],         determinante: "behavioral" },
  { code: "63638-6",  display: "Secondhand tobacco smoke exposure",                    display_es: "Exposición humo de segunda mano",        grupo: ["A","B","C","D"], determinante: "environmental" },
  { code: "96103-3",  display: "Electronic cigarettes or vaping use status",           display_es: "Uso cigarrillos electrónicos/vapeo",     grupo: ["A","B"],         determinante: "behavioral" },
  { code: "64234-3",  display: "How many packs of cigarettes per day",                 display_es: "Paquetes cigarrillos por día",           grupo: ["A","B","C","D"], determinante: "behavioral" },
];

export const LOINC_LE8_SLEEP: ConceptEntry[] = [
  { code: "93832-4",  display: "Sleep duration",                                       display_es: "Duración del sueño",                    grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "65545-4",  display: "Sleep hours - reported",                               display_es: "Horas sueño reportadas",                 grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "28323-4",  display: "Sleep study panel",                                    display_es: "Panel estudio sueño",                    grupo: ["C","D"],         determinante: "behavioral" },
  { code: "93036-2",  display: "Presence of sleep difficulties",                       display_es: "Presencia dificultades para dormir",     grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "89243-0",  display: "PROMIS - Sleep disturbance",                           display_es: "PROMIS - Trastornos del sueño",          grupo: ["C","D"],         determinante: "behavioral" },
];

export const LOINC_LE8_BMI: ConceptEntry[] = [
  { code: "39156-5",  display: "Body mass index (BMI) [Ratio]",                        display_es: "Índice de masa corporal (IMC)",          grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "8302-2",   display: "Body height",                                           display_es: "Talla corporal",                         grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "29463-7",  display: "Body weight",                                           display_es: "Peso corporal",                          grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "56086-2",  display: "Waist circumference at umbilicus",                      display_es: "Circunferencia cintura a nivel ombligo", grupo: ["B","C","D"],     determinante: "medical" },
  { code: "8280-0",   display: "Waist circumference at umbilicus by Tape measure",      display_es: "Cintura abdominal (cinta métrica)",      grupo: ["B","C","D"],     determinante: "medical" },
];

export const LOINC_LE8_LIPIDS: ConceptEntry[] = [
  { code: "2093-3",   display: "Cholesterol [Mass/volume] in Serum or Plasma",                      display_es: "Colesterol total",                       grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "18262-6",  display: "Cholesterol in LDL [Mass/volume] in Serum or Plasma by Direct assay",display_es: "LDL colesterol (método directo)",        grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "2085-9",   display: "Cholesterol in HDL [Mass/volume] in Serum or Plasma",               display_es: "HDL colesterol",                          grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "2571-8",   display: "Triglycerides [Mass/volume] in Serum or Plasma",                    display_es: "Triglicéridos",                            grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "13457-7",  display: "Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation", display_es: "LDL colesterol (calculado Friedewald)",  grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "55440-2",  display: "Cholesterol.non HDL [Mass/volume] in Serum or Plasma",              display_es: "Colesterol no-HDL",                        grupo: ["C","D"],          determinante: "medical" },
  { code: "35200-5",  display: "Cholesterol panel with total:chol/HDL ratio",                       display_es: "Panel colesterol + ratio CT/HDL",          grupo: ["B","C","D"],      determinante: "medical" },
];

export const LOINC_LE8_GLUCOSE: ConceptEntry[] = [
  { code: "4548-4",   display: "Hemoglobin A1c/Hemoglobin.total in Blood",             display_es: "Hemoglobina glicosilada HbA1c",          grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "2339-0",   display: "Glucose [Mass/volume] in Blood",                       display_es: "Glucemia en sangre",                     grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "14749-6",  display: "Glucose [Moles/volume] in Serum or Plasma",            display_es: "Glucosa en suero/plasma",                grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "1558-3",   display: "Fasting glucose [Mass/volume] in Serum or Plasma",     display_es: "Glucosa en ayunas",                      grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "25330-3",  display: "Glucose [Mass/volume] in Urine",                       display_es: "Glucosa en orina",                       grupo: ["B","C","D"],     determinante: "medical" },
  { code: "14743-9",  display: "Glucose post meal",                                    display_es: "Glucemia postprandial",                  grupo: ["B","C","D"],     determinante: "medical" },
];

export const LOINC_LE8_BP: ConceptEntry[] = [
  { code: "55284-4",  display: "Blood pressure systolic and diastolic",                display_es: "Presión arterial sistólica y diastólica",grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "8480-6",   display: "Systolic blood pressure",                              display_es: "Presión arterial sistólica",              grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "8462-4",   display: "Diastolic blood pressure",                             display_es: "Presión arterial diastólica",             grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "8478-0",   display: "Mean blood pressure",                                  display_es: "Presión arterial media",                  grupo: ["B","C","D"],     determinante: "medical" },
  { code: "59408-5",  display: "Oxygen saturation in Arterial blood by Pulse oximetry",display_es: "Saturación O2 (oximetría)",               grupo: ["C","D"],         determinante: "medical" },
  { code: "8867-4",   display: "Heart rate",                                           display_es: "Frecuencia cardíaca",                    grupo: ["A","B","C","D"], determinante: "medical" },
];

// Panel de score LE8 compuesto
export const LOINC_LE8_SCORES: ConceptEntry[] = [
  { code: "96108-2",  display: "Cardiovascular health score [AHA Life Essential 8]",  display_es: "Score salud cardiovascular LE8 (AHA)",   grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "96107-4",  display: "Cardiovascular health category [AHA Life Essential 8]",display_es: "Categoría salud CV LE8 (AHA)",           grupo: ["A","B","C","D"], determinante: "medical" },
];

// ─────────────────────────────────────────────────────────────────────────────
// SNOMED CT — Condiciones Cardiovasculares & Factores de Riesgo (Mujeres)
// ─────────────────────────────────────────────────────────────────────────────

export const SNOMED_CV_CONDITIONS: ConceptEntry[] = [
  // Hipertensión
  { code: "38341003",  display: "Hypertensive disorder, systemic arterial",               display_es: "Hipertensión arterial sistémica",          grupo: ["A","B","C","D"], determinante: "medical" },
  { code: "73410007",  display: "Benign essential hypertension",                          display_es: "Hipertensión esencial benigna",             grupo: ["C","D"],         determinante: "medical" },
  { code: "48552006",  display: "Hypertension secondary to renal disease",                display_es: "Hipertensión secundaria a enfermedad renal",grupo: ["C","D"],         determinante: "medical" },
  { code: "48194001",  display: "Pregnancy-induced hypertension",                         display_es: "Hipertensión inducida por embarazo",        grupo: ["B"],             determinante: "medical" },

  // Diabetes
  { code: "73211009",  display: "Diabetes mellitus",                                      display_es: "Diabetes mellitus",                         grupo: ["A","B","C","D"], determinante: "genetic" },
  { code: "44054006",  display: "Diabetes mellitus type 2",                               display_es: "Diabetes mellitus tipo 2",                  grupo: ["B","C","D"],     determinante: "genetic" },
  { code: "46635009",  display: "Diabetes mellitus type 1",                               display_es: "Diabetes mellitus tipo 1",                  grupo: ["A","B","C","D"], determinante: "genetic" },
  { code: "11687002",  display: "Gestational diabetes mellitus",                          display_es: "Diabetes gestacional",                      grupo: ["B"],             determinante: "medical" },

  // Cardiopatía isquémica
  { code: "53741008",  display: "Coronary arteriosclerosis",                              display_es: "Arteriosclerosis coronaria",                 grupo: ["C","D"],         determinante: "medical" },
  { code: "22298006",  display: "Myocardial infarction",                                  display_es: "Infarto agudo de miocardio",                 grupo: ["C","D"],         determinante: "medical" },
  { code: "413444003", display: "Acute myocardial infarction of anterior wall",           display_es: "IAM pared anterior",                        grupo: ["C","D"],         determinante: "medical" },
  { code: "194828000", display: "Angina pectoris",                                        display_es: "Angina de pecho",                           grupo: ["C","D"],         determinante: "medical" },

  // Insuficiencia cardíaca
  { code: "84114007",  display: "Heart failure",                                          display_es: "Insuficiencia cardíaca",                    grupo: ["C","D"],         determinante: "medical" },
  { code: "134401001", display: "Left heart failure",                                     display_es: "Insuficiencia cardíaca izquierda",          grupo: ["C","D"],         determinante: "medical" },

  // Enfermedad cerebrovascular
  { code: "230690007", display: "Cerebrovascular accident",                               display_es: "Accidente cerebrovascular (ACV)",           grupo: ["C","D"],         determinante: "medical" },
  { code: "266257000", display: "Transient ischemic attack",                              display_es: "Ataque isquémico transitorio (AIT)",        grupo: ["C","D"],         determinante: "medical" },

  // Dislipidemia
  { code: "55822004",  display: "Hyperlipidemia",                                         display_es: "Hiperlipidemia",                            grupo: ["A","B","C","D"], determinante: "genetic" },
  { code: "44054006",  display: "Hypercholesterolemia",                                   display_es: "Hipercolesterolemia",                       grupo: ["A","B","C","D"], determinante: "genetic" },
  { code: "302870006", display: "Hypertriglyceridaemia",                                  display_es: "Hipertrigliceridemia",                      grupo: ["B","C","D"],     determinante: "genetic" },
];

export const SNOMED_CV_RISK_FACTORS: ConceptEntry[] = [
  // Obesidad y peso
  { code: "414916001", display: "Obesity (BMI 30+)",                                     display_es: "Obesidad (IMC ≥ 30)",                       grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "238136002", display: "Morbid obesity",                                         display_es: "Obesidad mórbida",                          grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "248342006", display: "Overweight",                                             display_es: "Sobrepeso (IMC 25-29.9)",                    grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "248342006", display: "Abdominal obesity",                                      display_es: "Obesidad abdominal",                        grupo: ["B","C","D"],     determinante: "behavioral" },

  // Tabaquismo
  { code: "77176002",  display: "Smoker",                                                 display_es: "Fumadora activa",                           grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "8392000",   display: "Non-smoker",                                             display_es: "No fumadora",                               grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "160617001", display: "Stopped smoking",                                        display_es: "Ex fumadora",                               grupo: ["A","B","C","D"], determinante: "behavioral" },
  { code: "230058008", display: "Passive smoking",                                        display_es: "Fumadora pasiva (humo de segunda mano)",    grupo: ["A","B","C","D"], determinante: "environmental" },

  // Sedentarismo
  { code: "415510000", display: "Physically inactive",                                    display_es: "Sedentarismo",                              grupo: ["A","B","C","D"], determinante: "behavioral" },

  // Estrés y salud mental
  { code: "73595000",  display: "Stress",                                                 display_es: "Estrés",                                    grupo: ["A","B","C","D"], determinante: "social" },
  { code: "35489007",  display: "Depressive disorder",                                    display_es: "Trastorno depresivo",                       grupo: ["B","C","D"],     determinante: "social" },
  { code: "197480006", display: "Anxiety disorder",                                       display_es: "Trastorno de ansiedad",                     grupo: ["A","B","C","D"], determinante: "social" },
];

export const SNOMED_WOMENS_HEALTH: ConceptEntry[] = [
  // Grupo B — Maternidad
  { code: "77386006",  display: "Pregnancy",                                              display_es: "Embarazo",                                  grupo: ["B"],             determinante: "medical" },
  { code: "47200007",  display: "High risk pregnancy",                                    display_es: "Embarazo de alto riesgo",                   grupo: ["B"],             determinante: "medical" },
  { code: "44390003",  display: "Preeclampsia",                                           display_es: "Preeclampsia",                              grupo: ["B"],             determinante: "medical" },
  { code: "41114007",  display: "Mild preeclampsia",                                      display_es: "Preeclampsia leve",                         grupo: ["B"],             determinante: "medical" },
  { code: "15628003",  display: "Gonorrhea",                                              display_es: "PCOS - Síndrome de ovario poliquístico",    grupo: ["A","B"],         determinante: "medical" },
  { code: "237055002", display: "Polycystic ovary syndrome",                              display_es: "Síndrome de ovario poliquístico (SOP)",     grupo: ["A","B"],         determinante: "genetic" },

  // Grupo C — Menopausia
  { code: "289903006", display: "Menopause",                                              display_es: "Menopausia",                                grupo: ["C"],             determinante: "medical" },
  { code: "76498008",  display: "Premature menopause",                                    display_es: "Menopausia prematura",                      grupo: ["B","C"],         determinante: "medical" },
  { code: "73211009",  display: "Menopause-related metabolic syndrome",                   display_es: "Sd. metabólico post-menopausia",            grupo: ["C"],             determinante: "medical" },
  { code: "64859006",  display: "Osteoporosis",                                           display_es: "Osteoporosis",                              grupo: ["C","D"],         determinante: "medical" },
  { code: "34649000",  display: "Hypothyroidism",                                         display_es: "Hipotiroidismo",                            grupo: ["C","D"],         determinante: "medical" },
  { code: "34020007",  display: "Hyperthyroidism",                                        display_es: "Hipertiroidismo",                           grupo: ["C","D"],         determinante: "medical" },
];

export const SNOMED_DETERMINANTS_SOCIAL: ConceptEntry[] = [
  { code: "160695008", display: "Transport problems",                                     display_es: "Problemas de transporte / acceso",          grupo: ["A","B","C","D"], determinante: "social" },
  { code: "105568001", display: "Educational achievement",                                display_es: "Nivel educativo alcanzado",                 grupo: ["A","B","C","D"], determinante: "social" },
  { code: "224352007", display: "Unemployed",                                             display_es: "Desocupación / desempleo",                  grupo: ["A","B","C","D"], determinante: "social" },
  { code: "160695008", display: "Food insecurity",                                        display_es: "Inseguridad alimentaria",                   grupo: ["A","B","C","D"], determinante: "social" },
  { code: "413542001", display: "Inadequate social support",                              display_es: "Falta de apoyo social",                     grupo: ["C","D"],         determinante: "social" },
];
