/**
 * EPA Bienestar IA — ValueSet Loader
 * Carga ValueSets curados LOINC + SNOMED para LE8 en Medplum FHIR R4
 *
 * Uso:
 *   npm install
 *   MEDPLUM_CLIENT_ID=xxx MEDPLUM_CLIENT_SECRET=xxx npx ts-node src/load-valuesets.ts
 *
 * O con archivo .env:
 *   cp .env.example .env  # completar credenciales
 *   npx ts-node src/load-valuesets.ts
 */

import { MedplumClient } from "@medplum/core";
import fetch from "node-fetch";
import * as dotenv from "dotenv";
import {
  LOINC_LE8_DIET, LOINC_LE8_ACTIVITY, LOINC_LE8_NICOTINE,
  LOINC_LE8_SLEEP, LOINC_LE8_BMI, LOINC_LE8_LIPIDS,
  LOINC_LE8_GLUCOSE, LOINC_LE8_BP, LOINC_LE8_SCORES,
  SNOMED_CV_CONDITIONS, SNOMED_CV_RISK_FACTORS,
  SNOMED_WOMENS_HEALTH, SNOMED_DETERMINANTS_SOCIAL,
  type ConceptEntry,
} from "./valuesets-data";

dotenv.config();

// ─────────────────────────────────────────────────────────────────────────────
// Configuración
// ─────────────────────────────────────────────────────────────────────────────

const MEDPLUM_BASE_URL   = process.env.MEDPLUM_BASE_URL   || "https://api.epa-bienestar.com.ar";
const MEDPLUM_CLIENT_ID  = process.env.MEDPLUM_CLIENT_ID!;
const MEDPLUM_CLIENT_SECRET = process.env.MEDPLUM_CLIENT_SECRET!;

const EPA_BASE_URL = "https://epa-bienestar.com.ar/fhir";

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function buildConcepts(entries: ConceptEntry[]): fhir4.ValueSetComposeIncludeConcept[] {
  return entries.map(e => ({
    code:        e.code,
    display:     e.display,
    designation: [
      {
        language: "es-AR",
        use: {
          system:  "http://snomed.info/sct",
          code:    "900000000000013009",
          display: "Synonym",
        },
        value: e.display_es,
      },
    ],
    extension: [
      ...(e.grupo ? [{
        url:         `${EPA_BASE_URL}/StructureDefinition/life-stage-group`,
        valueString: e.grupo.join(","),
      }] : []),
      ...(e.determinante ? [{
        url:         `${EPA_BASE_URL}/StructureDefinition/health-determinant`,
        valueString: e.determinante,
      }] : []),
    ],
  }));
}

function buildLoincInclude(entries: ConceptEntry[]): fhir4.ValueSetComposeInclude {
  return {
    system:   "http://loinc.org",
    version:  "2.78",
    concept:  buildConcepts(entries),
  };
}

function buildSnomedInclude(entries: ConceptEntry[]): fhir4.ValueSetComposeInclude {
  // Deduplicar por code (algunos códigos aparecen en múltiples arrays)
  const unique = entries.filter((e, i, arr) => arr.findIndex(x => x.code === e.code) === i);
  return {
    system:  "http://snomed.info/sct",
    version: "http://snomed.info/sct/900000000000207008",
    concept: buildConcepts(unique),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Definición de ValueSets a cargar
// ─────────────────────────────────────────────────────────────────────────────

interface ValueSetDef {
  url:         string;
  name:        string;
  title:       string;
  description: string;
  resource:    fhir4.ValueSet;
}

function makeValueSets(): ValueSetDef[] {
  return [

    // ── 1. Panel LOINC LE8 completo ──────────────────────────────────────────
    {
      url:  `${EPA_BASE_URL}/ValueSet/le8-loinc-complete-panel`,
      name: "LE8LoincCompletePanel",
      title: "LE8 — Panel LOINC completo (8 componentes)",
      description: "Todos los códigos LOINC para los 8 componentes del Life's Essential 8 (AHA 2022), curados para EPA Bienestar IA con anotaciones en español argentino.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/le8-loinc-complete-panel`,
        version: "1.0.0",
        name:   "LE8LoincCompletePanel",
        title:  "LE8 — Panel LOINC completo (8 componentes)",
        status: "active",
        experimental: false,
        publisher: "EPA Bienestar IA",
        contact: [{ name: "Dr. Alejandro D'Alessandro", telecom: [{ system: "email", value: "alejandro@epa-bienestar.com.ar" }] }],
        description: "Códigos LOINC curados para los 8 componentes del Life's Essential 8 (AHA 2022). Incluye designaciones en español (es-AR) y anotaciones por grupo etario (A/B/C/D) y determinante de salud (GoInvo model).",
        useContext: [
          { code: { system: "http://terminology.hl7.org/CodeSystem/usage-context-type", code: "focus" }, valueCodeableConcept: { text: "Salud cardiovascular femenina" } },
          { code: { system: "http://terminology.hl7.org/CodeSystem/usage-context-type", code: "program" }, valueCodeableConcept: { text: "Plan Bienestar 100 Días" } },
        ],
        purpose: "Estandarización semántica del scoring LE8 en el servidor FHIR R4 de EPA Bienestar. Soporta interoperabilidad con sistemas de laboratorio, wearables y plataformas de obras sociales.",
        copyright: "LOINC® is copyright 1995-2024 Regenstrief Institute, Inc. Licensed under CC BY 4.0.",
        compose: {
          include: [
            buildLoincInclude([
              ...LOINC_LE8_DIET,
              ...LOINC_LE8_ACTIVITY,
              ...LOINC_LE8_NICOTINE,
              ...LOINC_LE8_SLEEP,
              ...LOINC_LE8_BMI,
              ...LOINC_LE8_LIPIDS,
              ...LOINC_LE8_GLUCOSE,
              ...LOINC_LE8_BP,
              ...LOINC_LE8_SCORES,
            ]),
          ],
        },
      },
    },

    // ── 2–9. ValueSets por componente LE8 ────────────────────────────────────
    {
      url:  `${EPA_BASE_URL}/ValueSet/le8-loinc-diet`,
      name: "LE8LoincDiet",
      title: "LE8 — Dieta (LOINC)",
      description: "Códigos LOINC para evaluación de dieta/nutrición en el componente Diet Quality del LE8, incluyendo puntaje MEPA.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/le8-loinc-diet`,
        version: "1.0.0", name: "LE8LoincDiet",
        title:  "LE8 — Dieta (LOINC)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Códigos LOINC para evaluación de dieta/nutrición en el componente Diet Quality del LE8, incluyendo puntaje MEPA (Mediterranean Eating Pattern for Americans, adaptado para Argentina).",
        compose: { include: [buildLoincInclude(LOINC_LE8_DIET)] },
      },
    },
    {
      url:  `${EPA_BASE_URL}/ValueSet/le8-loinc-physical-activity`,
      name: "LE8LoincPhysicalActivity",
      title: "LE8 — Actividad Física (LOINC)",
      description: "Códigos LOINC para evaluación de actividad física en el componente Physical Activity del LE8.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/le8-loinc-physical-activity`,
        version: "1.0.0", name: "LE8LoincPhysicalActivity",
        title:  "LE8 — Actividad Física (LOINC)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Códigos LOINC para minutos/días de actividad física moderada-intensa y ejercicio de fortalecimiento muscular. Meta: ≥150 min/semana actividad moderada.",
        compose: { include: [buildLoincInclude(LOINC_LE8_ACTIVITY)] },
      },
    },
    {
      url:  `${EPA_BASE_URL}/ValueSet/le8-loinc-nicotine`,
      name: "LE8LoincNicotine",
      title: "LE8 — Exposición a Nicotina (LOINC)",
      description: "Códigos LOINC para evaluación de tabaquismo y exposición a nicotina.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/le8-loinc-nicotine`,
        version: "1.0.0", name: "LE8LoincNicotine",
        title:  "LE8 — Exposición a Nicotina (LOINC)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Códigos LOINC para tabaquismo, vapeo y exposición a humo de segunda mano. Score LE8 óptimo: cero exposición.",
        compose: { include: [buildLoincInclude(LOINC_LE8_NICOTINE)] },
      },
    },
    {
      url:  `${EPA_BASE_URL}/ValueSet/le8-loinc-sleep`,
      name: "LE8LoincSleep",
      title: "LE8 — Sueño (LOINC)",
      description: "Códigos LOINC para evaluación de duración y calidad del sueño.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/le8-loinc-sleep`,
        version: "1.0.0", name: "LE8LoincSleep",
        title:  "LE8 — Sueño (LOINC)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Códigos LOINC para duración del sueño (meta: 7-9 horas/noche adultos) y trastornos del sueño. Especialmente relevante para Grupo C (menopausia) y Grupo B (embarazo).",
        compose: { include: [buildLoincInclude(LOINC_LE8_SLEEP)] },
      },
    },
    {
      url:  `${EPA_BASE_URL}/ValueSet/le8-loinc-bmi`,
      name: "LE8LoincBMI",
      title: "LE8 — IMC y Composición Corporal (LOINC)",
      description: "Códigos LOINC para IMC, peso, talla y circunferencia abdominal.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/le8-loinc-bmi`,
        version: "1.0.0", name: "LE8LoincBMI",
        title:  "LE8 — IMC y Composición Corporal (LOINC)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Códigos LOINC para IMC (meta: <25 kg/m²), peso corporal, talla y circunferencia de cintura. La circunferencia abdominal es clave en evaluación metabólica para Grupos B, C y D.",
        compose: { include: [buildLoincInclude(LOINC_LE8_BMI)] },
      },
    },
    {
      url:  `${EPA_BASE_URL}/ValueSet/le8-loinc-lipids`,
      name: "LE8LoincLipids",
      title: "LE8 — Lípidos en Sangre (LOINC)",
      description: "Códigos LOINC para perfil lipídico completo.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/le8-loinc-lipids`,
        version: "1.0.0", name: "LE8LoincLipids",
        title:  "LE8 — Lípidos en Sangre (LOINC)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Códigos LOINC para colesterol total, LDL, HDL, triglicéridos y colesterol no-HDL. Umbrales LE8: LDL <100 mg/dL, HDL >50 mg/dL mujeres, TG <150 mg/dL.",
        compose: { include: [buildLoincInclude(LOINC_LE8_LIPIDS)] },
      },
    },
    {
      url:  `${EPA_BASE_URL}/ValueSet/le8-loinc-glucose`,
      name: "LE8LoincGlucose",
      title: "LE8 — Glucosa en Sangre (LOINC)",
      description: "Códigos LOINC para glucemia en ayunas, postprandial y HbA1c.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/le8-loinc-glucose`,
        version: "1.0.0", name: "LE8LoincGlucose",
        title:  "LE8 — Glucosa en Sangre (LOINC)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Códigos LOINC para monitoreo glucémico. Umbrales LE8: glucosa en ayunas <100 mg/dL, HbA1c <5.7%. Peso ×1.30 para Grupo B (riesgo diabetes gestacional).",
        compose: { include: [buildLoincInclude(LOINC_LE8_GLUCOSE)] },
      },
    },
    {
      url:  `${EPA_BASE_URL}/ValueSet/le8-loinc-blood-pressure`,
      name: "LE8LoincBloodPressure",
      title: "LE8 — Presión Arterial (LOINC)",
      description: "Códigos LOINC para presión arterial sistólica, diastólica y media.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/le8-loinc-blood-pressure`,
        version: "1.0.0", name: "LE8LoincBloodPressure",
        title:  "LE8 — Presión Arterial (LOINC)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Códigos LOINC para presión arterial y frecuencia cardíaca. Meta LE8: PA <120/80 mmHg sin medicación. Umbral alerta embarazo Grupo B: ≥140/90 (ver Bot hipertensión SAC).",
        compose: { include: [buildLoincInclude(LOINC_LE8_BP)] },
      },
    },

    // ── 10. SNOMED — Condiciones cardiovasculares ──────────────────────────
    {
      url:  `${EPA_BASE_URL}/ValueSet/snomed-cv-conditions-women`,
      name: "SnomedCVConditionsWomen",
      title: "Condiciones Cardiovasculares en Mujeres (SNOMED CT)",
      description: "Códigos SNOMED CT para diagnósticos cardiovasculares prevalentes en mujeres, segmentados por grupo etario.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/snomed-cv-conditions-women`,
        version: "1.0.0", name: "SnomedCVConditionsWomen",
        title:  "Condiciones Cardiovasculares en Mujeres (SNOMED CT)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Diagnósticos cardiovasculares, metabólicos y cerebrovasculares prevalentes en mujeres. Curado con especificidad por grupo etario A/B/C/D del Programa Mujer. Referencia: SAC/FAC Guías de Enfermedades CV en la Mujer 2024.",
        copyright: "SNOMED CT® is the intellectual property of SNOMED International. This file is released under the Creative Commons Attribution 4.0 International License (CC BY 4.0).",
        compose: {
          include: [buildSnomedInclude(SNOMED_CV_CONDITIONS)],
        },
      },
    },

    // ── 11. SNOMED — Factores de riesgo ──────────────────────────────────────
    {
      url:  `${EPA_BASE_URL}/ValueSet/snomed-cv-risk-factors-women`,
      name: "SnomedCVRiskFactorsWomen",
      title: "Factores de Riesgo Cardiovascular en Mujeres (SNOMED CT)",
      description: "Códigos SNOMED CT para factores de riesgo cardiovascular modificables y no modificables en mujeres.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/snomed-cv-risk-factors-women`,
        version: "1.0.0", name: "SnomedCVRiskFactorsWomen",
        title:  "Factores de Riesgo CV en Mujeres (SNOMED CT)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Factores de riesgo cardiovascular modificables (tabaquismo, obesidad, sedentarismo, estrés) y no modificables relevantes para el scoring LE8. Alineado con el modelo GoInvo de Determinantes de Salud.",
        compose: {
          include: [buildSnomedInclude(SNOMED_CV_RISK_FACTORS)],
        },
      },
    },

    // ── 12. SNOMED — Salud de la mujer (grupos B y C) ──────────────────────
    {
      url:  `${EPA_BASE_URL}/ValueSet/snomed-womens-health-cv`,
      name: "SnomedWomensHealthCV",
      title: "Salud de la Mujer — Condiciones CV Específicas (SNOMED CT)",
      description: "Códigos SNOMED CT para condiciones específicas de la mujer con impacto cardiovascular: embarazo, menopausia, PCOS, tiroides.",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/snomed-womens-health-cv`,
        version: "1.0.0", name: "SnomedWomensHealthCV",
        title:  "Salud de la Mujer — Condiciones CV Específicas (SNOMED CT)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Condiciones de salud exclusivas o predominantes en mujeres con impacto en riesgo cardiovascular: hipertensión gestacional, preeclampsia, diabetes gestacional, PCOS, menopausia, osteoporosis y disfunción tiroidea. Clave para Grupos B (maternidad) y C (menopausia).",
        compose: {
          include: [buildSnomedInclude(SNOMED_WOMENS_HEALTH)],
        },
      },
    },

    // ── 13. SNOMED — Determinantes sociales ────────────────────────────────
    {
      url:  `${EPA_BASE_URL}/ValueSet/snomed-social-determinants`,
      name: "SnomedSocialDeterminants",
      title: "Determinantes Sociales de Salud Cardiovascular (SNOMED CT)",
      description: "Códigos SNOMED CT para factores sociales que impactan la salud cardiovascular (modelo GoInvo 23%).",
      resource: {
        resourceType: "ValueSet",
        url:    `${EPA_BASE_URL}/ValueSet/snomed-social-determinants`,
        version: "1.0.0", name: "SnomedSocialDeterminants",
        title:  "Determinantes Sociales de Salud CV (SNOMED CT)", status: "active", experimental: false,
        publisher: "EPA Bienestar IA",
        description: "Factores sociales con impacto en salud cardiovascular según el modelo GoInvo (social determinants: 23%). Incluye acceso a transporte, nivel educativo, desempleo, inseguridad alimentaria y falta de apoyo social.",
        compose: {
          include: [buildSnomedInclude(SNOMED_DETERMINANTS_SOCIAL)],
        },
      },
    },

  ];
}

// ─────────────────────────────────────────────────────────────────────────────
// Loader principal
// ─────────────────────────────────────────────────────────────────────────────

async function loadValueSets(): Promise<void> {
  console.log("\n╔══════════════════════════════════════════════════════════╗");
  console.log("║   EPA Bienestar IA — ValueSet Loader v1.0                ║");
  console.log("║   LOINC + SNOMED CT para Life's Essential 8              ║");
  console.log("╚══════════════════════════════════════════════════════════╝\n");

  if (!MEDPLUM_CLIENT_ID || !MEDPLUM_CLIENT_SECRET) {
    console.error("❌  Variables de entorno faltantes: MEDPLUM_CLIENT_ID y MEDPLUM_CLIENT_SECRET");
    process.exit(1);
  }

  // Inicializar cliente Medplum con OAuth2 client credentials
  const medplum = new MedplumClient({
    baseUrl: MEDPLUM_BASE_URL,
    fetch:   fetch as unknown as typeof globalThis.fetch,
  });

  console.log(`🔐 Autenticando en ${MEDPLUM_BASE_URL}...`);
  await medplum.startClientLogin(MEDPLUM_CLIENT_ID, MEDPLUM_CLIENT_SECRET);
  console.log("✅  Autenticación exitosa\n");

  const valueSets = makeValueSets();
  console.log(`📦 ValueSets a cargar: ${valueSets.length}\n`);

  const results: { name: string; status: "created" | "updated" | "error"; id?: string; error?: string }[] = [];

  for (const vs of valueSets) {
    const { name, title, resource } = vs;
    process.stdout.write(`  ⟳  ${title.padEnd(50)}`);

    try {
      // Buscar si ya existe por URL
      const existing = await medplum.searchOne("ValueSet", { url: vs.url });

      let result: fhir4.ValueSet;

      if (existing) {
        // Actualizar — preservar ID y meta
        result = await medplum.updateResource<fhir4.ValueSet>({
          ...resource,
          id:   existing.id,
          meta: existing.meta,
        });
        process.stdout.write(` 🔄 actualizado  [${result.id}]\n`);
        results.push({ name, status: "updated", id: result.id });
      } else {
        // Crear nuevo
        result = await medplum.createResource<fhir4.ValueSet>(resource);
        process.stdout.write(` ✅ creado       [${result.id}]\n`);
        results.push({ name, status: "created", id: result.id });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      process.stdout.write(` ❌ ERROR: ${msg}\n`);
      results.push({ name, status: "error", error: msg });
    }
  }

  // ── Resumen ────────────────────────────────────────────────────────────────
  const created  = results.filter(r => r.status === "created").length;
  const updated  = results.filter(r => r.status === "updated").length;
  const errors   = results.filter(r => r.status === "error").length;

  console.log("\n─────────────────────────────────────────────────────────────");
  console.log(`📊 Resumen:`);
  console.log(`   ✅ Creados:     ${created}`);
  console.log(`   🔄 Actualizados: ${updated}`);
  console.log(`   ❌ Errores:     ${errors}`);
  console.log(`   📁 Total:       ${results.length}`);

  if (errors > 0) {
    console.log("\n⚠️  Errores detallados:");
    results.filter(r => r.status === "error").forEach(r => {
      console.log(`   • ${r.name}: ${r.error}`);
    });
  }

  // ── Verificación rápida ────────────────────────────────────────────────────
  console.log("\n🔍 Verificando carga en servidor...");
  const bundle = await medplum.search("ValueSet", {
    publisher: "EPA Bienestar IA",
    _count: "50",
    _summary: "true",
  });

  const total = bundle.entry?.length ?? 0;
  console.log(`   Recursos ValueSet EPA encontrados: ${total}`);

  if (bundle.entry) {
    bundle.entry.forEach((e: fhir4.BundleEntry) => {
      const v = e.resource as fhir4.ValueSet;
      console.log(`   • ${v.name?.padEnd(35)} [${v.id}]  status: ${v.status}`);
    });
  }

  console.log("\n✨ Carga completada.\n");
}

// ─────────────────────────────────────────────────────────────────────────────
// Entrypoint
// ─────────────────────────────────────────────────────────────────────────────

loadValueSets().catch(err => {
  console.error("\n💥 Error fatal:", err);
  process.exit(1);
});
