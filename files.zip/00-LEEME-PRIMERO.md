# 🚀 BOT DE RIESGO CARDIOVASCULAR - GRUPO C MENOPAUSIA

**EPA Bienestar IA - Programa Mujer**  
**Entrega**: 7 de diciembre de 2024

---

## ✅ ARCHIVOS ENTREGADOS

### 📁 Código Fuente

1. **bot-cardiovascular-risk.ts** - Bot principal (1200 líneas)
   - Cálculo HEARTS Score + modificadores menopausia
   - Detección de cambios
   - Notificaciones SES

2. **PatientCVDRiskDashboard.tsx** - Dashboard pacientes (650 líneas)
   - Visualización de riesgo
   - Gráficos de tendencia
   - Recomendaciones personalizadas

3. **MedicalTeamCVDRiskDashboard.tsx** - Dashboard médicos (700 líneas)
   - Vista consolidada
   - Alertas y filtros
   - Gestión de tasks

### 📋 Configuración

4. **questionnaire-risk-factors-women.json** - Cuestionario FHIR
5. **medplum-bot-config.json** - Config del bot
6. **package.json** - Dependencias NPM
7. **tsconfig.json** - Config TypeScript

### 📚 Documentación

8. **README.md** - Documentación principal
9. **DEPLOYMENT.md** - Guía de deployment (15 páginas)
10. **EXAMPLES.md** - Ejemplos y testing

---

## 🎯 CARACTERÍSTICAS PRINCIPALES

✅ **Bot Automatizado**
- Ejecuta cada lunes 6:00 AM (hora Argentina)
- Procesa todas las pacientes del Grupo C
- Genera RiskAssessments FHIR R4

✅ **Cálculo de Riesgo**
- HEARTS Score (WHO 2019)
- Calibrado para Argentina (Southern Latin America)
- Modificadores específicos de menopausia:
  - Menopausia temprana: +50%
  - PCOS: +40%
  - Preeclampsia: +70%
  - Diabetes gestacional: +50%
  - Hipotiroidismo + LDL elevado: +20%
  - Historia familiar: +60%

✅ **Notificaciones Inteligentes**
- Emails personalizados vía AWS SES
- Alertas solo con cambios significativos (≥5 puntos)
- Tasks automáticas para equipo médico

✅ **Dashboards Interactivos**
- Dashboard paciente: riesgo, tendencia, recomendaciones
- Dashboard médico: vista consolidada, filtros, alertas

---

## 🚀 IMPLEMENTACIÓN RÁPIDA

### Paso 1: Instalar Dependencias (5 min)
```bash
npm install
```

### Paso 2: Configurar AWS SES (30 min)
```bash
# Verificar dominio
aws ses verify-domain-identity --domain epa-bienestar.com.ar

# Verificar email
aws ses verify-email-identity \
  --email-address notificaciones@epa-bienestar.com.ar
```

### Paso 3: Subir Questionnaire (5 min)
```bash
medplum create Questionnaire questionnaire-risk-factors-women.json
```

### Paso 4: Deploy Bot (10 min)
```bash
npm run build
npm run deploy:prod
```

### Paso 5: Configurar Schedule (5 min)
En Medplum Console:
- Cron: `cron(0 6 ? * MON *)`
- Timezone: `America/Argentina/Buenos_Aires`

---

## 📊 FÓRMULA DE RIESGO

```
Riesgo Base = HEARTS_Score × 0.9  (ajuste regional Argentina)

Riesgo Ajustado = Riesgo_Base × Modificadores_Menopausia

Categorías:
- <10%: Bajo (verde)
- 10-20%: Moderado (naranja)
- 20-30%: Alto (rojo)
- >30%: Muy Alto (rojo oscuro)
```

---

## 📧 SISTEMA DE NOTIFICACIONES

### Triggers
- Cambio ≥5 puntos en el riesgo
- Cambio de categoría
- Primera evaluación

### Contenido Email Paciente
- Riesgo actual con color
- Cambio vs última evaluación
- Recomendaciones específicas
- Links a dashboard

### Contenido Email Médico
- Tasks pendientes
- Pacientes que requieren atención

---

## 🧪 TESTING

### Paciente de Prueba

```bash
# Ver EXAMPLES.md para datos completos

Perfil:
- 54 años, menopausia a los 48
- PA: 145/90 mmHg
- Colesterol: 235 mg/dL
- Historia de preeclampsia
- Hipotiroidismo con LDL elevado
- Historia familiar (padre IAM a 58 años)

Resultado Esperado:
- Riesgo base: ~14%
- Con modificadores: ~24%
- Categoría: ALTO
```

---

## 📱 DASHBOARDS

### Dashboard Paciente
- 📊 Riesgo actual con indicador visual
- 📈 Gráfico de tendencia (últimos 12 meses)
- 🔍 Factores de riesgo individuales
- 💡 Recomendaciones personalizadas
- 🎯 Acciones sugeridas

### Dashboard Médico
- 👥 Lista de todas las pacientes Grupo C
- 📊 Estadísticas por categoría
- 🔍 Filtros y búsqueda
- 🚨 Alertas de cambios significativos
- 📋 Tasks pendientes

---

## ⚠️ REQUISITOS CRÍTICOS

Para que el bot funcione:

✅ Cada paciente debe tener:
- Patient resource
- Agregada al Group "grupo-c-menopausia"
- Email en Patient.telecom
- Observations de PA y colesterol (últimos 7 días)
- QuestionnaireResponse completado

✅ AWS SES:
- Dominio verificado
- Fuera de sandbox mode (para emails a cualquier paciente)

---

## 📚 DOCUMENTACIÓN COMPLETA

- **README.md**: Arquitectura y overview
- **DEPLOYMENT.md**: Guía paso a paso de deployment
- **EXAMPLES.md**: Ejemplos de datos FHIR y testing

---

## 🎓 CAPACITACIÓN

Material disponible:
- Videos demostrativos (pendiente)
- Manual de usuario (pendiente)
- Sesiones de Q&A (a coordinar)

---

## 📞 SOPORTE

**Email**: tech@epa-bienestar.com.ar  
**Horario**: Lun-Vie 9-18hs (GMT-3)

---

## ✅ CHECKLIST DE GO-LIVE

- [ ] AWS SES configurado y fuera de sandbox
- [ ] Bot desplegado en Medplum
- [ ] Schedule configurado (Lunes 6 AM)
- [ ] Questionnaire subido
- [ ] Group "grupo-c-menopausia" creado
- [ ] 5+ pacientes de prueba con datos completos
- [ ] Bot ejecutado manualmente con éxito
- [ ] Emails recibidos correctamente
- [ ] Dashboards integrados en webapp
- [ ] Equipo médico capacitado

---

**¡Sistema listo para producción! 🎉**

*Ver README.md para más detalles*
