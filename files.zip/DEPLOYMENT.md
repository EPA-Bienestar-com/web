# 🚀 Guía de Deployment - Bot de Riesgo Cardiovascular

## 📋 Tabla de Contenidos

1. [Pre-requisitos](#pre-requisitos)
2. [Configuración AWS SES](#configuración-aws-ses)
3. [Configuración Medplum](#configuración-medplum)
4. [Deployment del Bot](#deployment-del-bot)
5. [Configuración del Questionnaire](#configuración-del-questionnaire)
6. [Configuración del Group](#configuración-del-group)
7. [Deployment de Dashboards](#deployment-de-dashboards)
8. [Testing](#testing)
9. [Monitoreo](#monitoreo)
10. [Troubleshooting](#troubleshooting)

---

## 🔧 Pre-requisitos

### Software Requerido
- Node.js >= 18.0.0
- npm >= 9.0.0
- AWS CLI configurado
- Cuenta Medplum activa
- Acceso a AWS SES

### Credenciales Necesarias
- Medplum API Key y Secret
- AWS Access Key ID y Secret Access Key
- Dominio verificado en AWS SES

---

## 📧 Configuración AWS SES

### 1. Verificar Dominio

```bash
# Verificar dominio epa-bienestar.com.ar en SES
aws ses verify-domain-identity --domain epa-bienestar.com.ar
```

### 2. Verificar Email de Notificaciones

```bash
# Verificar email notificaciones@epa-bienestar.com.ar
aws ses verify-email-identity --email-address notificaciones@epa-bienestar.com.ar
```

### 3. Configurar IAM Policy

Crear política IAM para envío de emails:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ses:SendEmail",
        "ses:SendRawEmail"
      ],
      "Resource": "*",
      "Condition": {
        "StringLike": {
          "ses:FromAddress": "notificaciones@epa-bienestar.com.ar"
        }
      }
    }
  ]
}
```

### 4. Salir del Sandbox

⚠️ **IMPORTANTE**: Por defecto, SES está en sandbox mode (solo puede enviar a emails verificados).

Para producción:
1. Ir a AWS Console → SES → Account Dashboard
2. Click en "Request production access"
3. Completar formulario justificando uso médico/salud
4. Esperar aprobación (24-48 horas)

---

## ⚙️ Configuración Medplum

### 1. Crear Proyecto en Medplum

```bash
# Instalar Medplum CLI
npm install -g @medplum/cli

# Login
medplum login

# Crear proyecto
medplum project create --name "EPA Bienestar - Programa Mujer"
```

### 2. Configurar Base URL

En `medplum.config.json`:

```json
{
  "baseUrl": "https://api.epa-bienestar.com.ar",
  "clientId": "YOUR_CLIENT_ID",
  "clientSecret": "YOUR_CLIENT_SECRET",
  "projectId": "YOUR_PROJECT_ID"
}
```

### 3. Configurar CORS

En Medplum Console → Settings → CORS:

```json
{
  "allowedOrigins": [
    "https://app.epa-bienestar.com.ar",
    "http://localhost:3000"
  ],
  "allowedMethods": ["GET", "POST", "PUT", "PATCH", "DELETE"],
  "allowedHeaders": ["Authorization", "Content-Type"],
  "maxAge": 86400
}
```

---

## 🤖 Deployment del Bot

### 1. Instalar Dependencias

```bash
cd bot-cardiovascular-risk
npm install
```

### 2. Compilar TypeScript

```bash
npm run build
```

### 3. Subir Bot a Medplum

```bash
# Desarrollo
npm run deploy:dev

# Producción
npm run deploy:prod
```

### 4. Configurar Schedule (Manual desde Medplum Console)

1. Ir a Medplum Console → Bots
2. Seleccionar "bot-cardiovascular-risk-grupo-c"
3. En la pestaña "Schedule", configurar:
   - **Cron Expression**: `cron(0 6 ? * MON *)`
   - **Timezone**: `America/Argentina/Buenos_Aires`
   - **Enabled**: ✅

### 5. Configurar Variables de Entorno

En Medplum Console → Bots → bot-cardiovascular-risk-grupo-c → Environment:

```
AWS_REGION=us-east-1
SES_FROM_EMAIL=notificaciones@epa-bienestar.com.ar
GROUP_C_ID=grupo-c-menopausia
RISK_THRESHOLD_LOW=10
RISK_THRESHOLD_MODERATE=20
RISK_THRESHOLD_HIGH=30
SIGNIFICANT_CHANGE_THRESHOLD=5
HEARTS_REGION=AMR-D
```

---

## 📝 Configuración del Questionnaire

### 1. Subir Questionnaire a Medplum

```bash
# Usando Medplum CLI
medplum create Questionnaire questionnaire-risk-factors-women.json
```

O mediante API:

```bash
curl -X POST https://api.epa-bienestar.com.ar/fhir/R4/Questionnaire \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @questionnaire-risk-factors-women.json
```

### 2. Verificar Creación

```bash
medplum get Questionnaire/cardiovascular-risk-factors-women
```

### 3. Integrar en WebApp

En tu aplicación web, usar el Questionnaire:

```typescript
import { useMedplum } from '@medplum/react';

const questionnaire = await medplum.readResource(
  'Questionnaire',
  'cardiovascular-risk-factors-women'
);

// Renderizar con QuestionnaireForm component
<QuestionnaireForm
  questionnaire={questionnaire}
  onSubmit={handleSubmit}
/>
```

---

## 👥 Configuración del Group

### 1. Crear Group Resource para Grupo C

```bash
medplum create Group grupo-c-menopausia.json
```

Donde `grupo-c-menopausia.json` contiene:

```json
{
  "resourceType": "Group",
  "id": "grupo-c-menopausia",
  "active": true,
  "type": "person",
  "actual": true,
  "name": "Grupo C - Mujeres en Menopausia",
  "managingEntity": {
    "reference": "Organization/epa-bienestar"
  },
  "characteristic": [
    {
      "code": {
        "coding": [{
          "system": "http://epa-bienestar.com.ar/fhir/CodeSystem/patient-segment",
          "code": "grupo-c",
          "display": "Grupo C - Menopausia"
        }]
      },
      "valueBoolean": true,
      "exclude": false
    }
  ]
}
```

### 2. Agregar Pacientes al Group

```typescript
// Agregar paciente al grupo
await medplum.updateResource({
  ...group,
  member: [
    ...group.member,
    {
      entity: { reference: `Patient/${patientId}` },
      period: { start: new Date().toISOString() }
    }
  ]
});
```

---

## 🖥️ Deployment de Dashboards

### Dashboard de Paciente

1. Integrar componente en tu aplicación React:

```typescript
import { PatientCVDRiskDashboard } from './PatientCVDRiskDashboard';

// En tu router
<Route path="/mi-riesgo-cardiovascular" element={<PatientCVDRiskDashboard />} />
```

### Dashboard de Médicos

```typescript
import { MedicalTeamCVDRiskDashboard } from './MedicalTeamCVDRiskDashboard';

// En tu router (solo para rol médico)
<Route 
  path="/admin/riesgo-cardiovascular" 
  element={
    <ProtectedRoute role="practitioner">
      <MedicalTeamCVDRiskDashboard />
    </ProtectedRoute>
  } 
/>
```

### Configurar Recharts

Instalar dependencias de visualización:

```bash
npm install recharts
```

---

## 🧪 Testing

### 1. Test Manual del Bot

Ejecutar el bot manualmente desde Medplum Console:

1. Ir a Bots → bot-cardiovascular-risk-grupo-c
2. Click en "Execute"
3. Revisar logs en CloudWatch

### 2. Test de Cálculo de Riesgo

Crear paciente de prueba con datos conocidos:

```bash
# Crear script de test
node test-risk-calculation.js
```

```javascript
// test-risk-calculation.js
const { MedplumClient } = require('@medplum/core');

const medplum = new MedplumClient({
  baseUrl: 'https://api.epa-bienestar.com.ar',
  clientId: 'YOUR_CLIENT_ID',
  clientSecret: 'YOUR_CLIENT_SECRET'
});

async function testRiskCalculation() {
  // Crear paciente de prueba
  const patient = await medplum.createResource({
    resourceType: 'Patient',
    name: [{ text: 'Test Paciente' }],
    gender: 'female',
    birthDate: '1975-01-01' // 49 años
  });

  // Crear observaciones
  await medplum.createResource({
    resourceType: 'Observation',
    status: 'final',
    code: { coding: [{ code: '8480-6', display: 'Presión Arterial Sistólica' }] },
    subject: { reference: `Patient/${patient.id}` },
    valueQuantity: { value: 150, unit: 'mmHg' },
    effectiveDateTime: new Date().toISOString()
  });

  await medplum.createResource({
    resourceType: 'Observation',
    status: 'final',
    code: { coding: [{ code: '2093-3', display: 'Colesterol Total' }] },
    subject: { reference: `Patient/${patient.id}` },
    valueQuantity: { value: 220, unit: 'mg/dL' },
    effectiveDateTime: new Date().toISOString()
  });

  // Agregar al Grupo C
  const group = await medplum.readResource('Group', 'grupo-c-menopausia');
  await medplum.updateResource({
    ...group,
    member: [
      ...group.member,
      { entity: { reference: `Patient/${patient.id}` } }
    ]
  });

  console.log('✅ Paciente de prueba creada:', patient.id);
  console.log('Ejecutar bot manualmente y verificar RiskAssessment creado');
}

testRiskCalculation();
```

### 3. Verificar Notificaciones

1. Revisar email recibido en notificaciones@epa-bienestar.com.ar
2. Verificar formato HTML
3. Verificar links funcionando

### 4. Test de Dashboards

```bash
# En tu aplicación React
npm run test

# Test específico de componentes
npm run test -- PatientCVDRiskDashboard.test.tsx
```

---

## 📊 Monitoreo

### 1. CloudWatch Logs

Ver logs del bot:

```bash
aws logs tail /aws/lambda/medplum-bot-cardiovascular-risk --follow
```

### 2. Métricas Clave a Monitorear

- **Ejecuciones del bot**: debe ejecutar cada lunes 6 AM
- **Duración**: < 300 segundos
- **Errores**: = 0
- **Emails enviados**: verificar tasa de entrega en SES
- **RiskAssessments creados**: debe coincidir con pacientes con datos nuevos

### 3. Alertas CloudWatch

Configurar alertas para:

```yaml
Alerta 1: Ejecución fallida del bot
  Métrica: Errors
  Threshold: > 0
  Acción: SNS → notificaciones@epa-bienestar.com.ar

Alerta 2: Duración excesiva
  Métrica: Duration
  Threshold: > 240000 ms
  Acción: SNS → notificaciones@epa-bienestar.com.ar

Alerta 3: SES Bounce Rate
  Métrica: Reputation.BounceRate
  Threshold: > 0.05
  Acción: SNS → notificaciones@epa-bienestar.com.ar
```

### 4. Dashboard de Métricas

Crear dashboard en CloudWatch con:

- Gráfico de ejecuciones semanales
- Distribución de pacientes por categoría de riesgo
- Tendencia de riesgo promedio del grupo
- Tasa de emails entregados vs rebotados

---

## 🔍 Troubleshooting

### Bot no ejecuta automáticamente

**Problema**: El bot no se ejecuta los lunes a las 6 AM

**Solución**:
1. Verificar que el schedule esté habilitado en Medplum Console
2. Verificar timezone: `America/Argentina/Buenos_Aires`
3. Revisar CloudWatch Events Rules
4. Verificar permisos de Lambda Execution Role

### Emails no se envían

**Problema**: Pacientes no reciben notificaciones

**Solución**:
1. Verificar que SES esté fuera de sandbox mode
2. Verificar dominio verificado: `aws ses get-identity-verification-attributes --identities epa-bienestar.com.ar`
3. Revisar logs de SES: `aws ses get-send-statistics`
4. Verificar IAM policy del bot tiene permisos SES
5. Verificar emails de pacientes en Patient resources

### RiskAssessments no se crean

**Problema**: El bot ejecuta pero no crea RiskAssessments

**Solución**:
1. Verificar que existan Observations recientes (última semana)
2. Verificar que pacientes estén en el Group correcto
3. Revisar logs detallados del bot
4. Verificar permisos de escritura en RiskAssessment

### Datos faltantes en cálculo

**Problema**: El bot no encuentra suficientes datos para calcular riesgo

**Solución**:
1. Verificar códigos LOINC en Observations:
   - `8480-6`: PA Sistólica
   - `2093-3`: Colesterol Total
2. Verificar formato de valores: `valueQuantity.value` debe ser número
3. Verificar fechas: `effectiveDateTime` debe estar en formato ISO
4. Asegurarse que QuestionnaireResponse existe para cada paciente

### Dashboard no carga datos

**Problema**: Dashboard muestra "cargando" indefinidamente

**Solución**:
1. Verificar permisos de lectura del usuario
2. Abrir Developer Console y revisar errores de red
3. Verificar autenticación de Medplum
4. Verificar CORS configurado correctamente
5. Verificar que Group ID es correcto: `grupo-c-menopausia`

---

## 📚 Recursos Adicionales

### Documentación Oficial

- [Medplum Bots Documentation](https://www.medplum.com/docs/bots)
- [AWS SES Developer Guide](https://docs.aws.amazon.com/ses/)
- [FHIR R4 Specification](https://hl7.org/fhir/R4/)
- [HEARTS Technical Package (OPS/WHO)](https://www.paho.org/en/hearts-americas)

### Contacto Soporte

- **Equipo Técnico**: tech@epa-bienestar.com.ar
- **Equipo Médico**: cardiologia@epa-bienestar.com.ar
- **Emergencias**: +54 9 11 XXXX-XXXX

---

## 📝 Changelog

### v1.0.0 - 2024-12-07
- ✅ Implementación inicial del bot de riesgo cardiovascular
- ✅ Cálculo HEARTS Score (WHO 2019) + modificadores menopausia
- ✅ Notificaciones automáticas vía SES
- ✅ Dashboards para pacientes y equipo médico
- ✅ Questionnaire de factores de riesgo femeninos
- ✅ Integración con Grupo C

---

## ✅ Checklist de Deployment

Antes de ir a producción, verificar:

- [ ] AWS SES fuera de sandbox mode
- [ ] Dominio epa-bienestar.com.ar verificado en SES
- [ ] Bot desplegado y schedule configurado
- [ ] Questionnaire subido a Medplum
- [ ] Group "grupo-c-menopausia" creado
- [ ] Al menos 5 pacientes de prueba con datos completos
- [ ] Test manual del bot ejecutado exitosamente
- [ ] Emails de notificación recibidos correctamente
- [ ] Dashboards funcionando en producción
- [ ] CloudWatch alertas configuradas
- [ ] Documentación entregada al equipo médico
- [ ] Capacitación realizada

---

**Última actualización**: 7 de diciembre de 2024  
**Versión**: 1.0.0  
**Responsable**: EPA Bienestar IA - Equipo de Producto
