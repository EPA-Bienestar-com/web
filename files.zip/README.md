# 🫀 Bot de Riesgo Cardiovascular - EPA Bienestar IA

Sistema automatizado de evaluación de riesgo cardiovascular para el **Grupo C - Menopausia** del Programa Mujer, utilizando HEARTS Score (WHO 2019) adaptado con factores específicos de mujeres menopáusicas.

---

## 📊 Visión General

Este sistema implementa un bot que se ejecuta **cada lunes a las 6 AM** para:

1. ✅ Calcular el riesgo cardiovascular a 10 años de todas las pacientes del Grupo C
2. ✅ Aplicar modificadores específicos de menopausia (PCOS, preeclampsia, hipotiroidismo, etc.)
3. ✅ Detectar cambios significativos en el riesgo
4. ✅ Generar alertas automáticas para el equipo médico
5. ✅ Enviar notificaciones personalizadas a las pacientes vía email
6. ✅ Actualizar CarePlans según la evolución del riesgo

---

## 🏗️ Arquitectura

```
┌─────────────────────────────────────────────────────────────┐
│                         WEBAPP                              │
│  ┌────────────────┐              ┌──────────────────────┐  │
│  │   Paciente     │              │   Equipo Médico      │  │
│  │   Dashboard    │              │   Dashboard          │  │
│  └────────────────┘              └──────────────────────┘  │
└────────────┬──────────────────────────────┬────────────────┘
             │                              │
             │         Medplum FHIR API     │
             │    (api.epa-bienestar.com.ar)│
             ▼                              ▼
┌────────────────────────────────────────────────────────────┐
│                      MEDPLUM SERVER                        │
│  ┌──────────────────────────────────────────────────────┐ │
│  │  FHIR R4 Resources                                   │ │
│  │  ├─ Patient                                          │ │
│  │  ├─ Observation (PA, Colesterol, Glucosa, etc.)     │ │
│  │  ├─ QuestionnaireResponse (Factores de riesgo)      │ │
│  │  ├─ RiskAssessment (Evaluaciones de riesgo)         │ │
│  │  ├─ Group (grupo-c-menopausia)                      │ │
│  │  ├─ Task (Tareas para equipo médico)                │ │
│  │  └─ CarePlan (Plan Bienestar 100 Días)              │ │
│  └──────────────────────────────────────────────────────┘ │
└────────────┬───────────────────────────────────────────────┘
             │
             │ Trigger: Lunes 6:00 AM
             ▼
┌────────────────────────────────────────────────────────────┐
│              BOT CARDIOVASCULAR RISK                       │
│                                                            │
│  1. Obtener pacientes Grupo C                             │
│  2. Verificar datos nuevos (última semana)                │
│  3. Calcular HEARTS Score base                            │
│  4. Aplicar modificadores menopausia                      │
│  5. Crear/Actualizar RiskAssessment                       │
│  6. Detectar cambios significativos                       │
│  7. Generar Tasks para equipo médico                      │
│  8. Enviar notificaciones vía SES                         │
│  9. Actualizar CarePlans                                  │
└────────────┬───────────────────────────────────────────────┘
             │
             │ Email Notifications
             ▼
┌────────────────────────────────────────────────────────────┐
│                      AWS SES                               │
│  notificaciones@epa-bienestar.com.ar                       │
│                                                            │
│  ┌──────────────────┐    ┌──────────────────────────┐    │
│  │   Pacientes      │    │   Equipo Médico          │    │
│  │   Alertas        │    │   Tasks Pendientes       │    │
│  └──────────────────┘    └──────────────────────────┘    │
└────────────────────────────────────────────────────────────┘
```

---

## ✨ Características Principales

### 🎯 Cálculo de Riesgo Cardiovascular

- **Algoritmo**: HEARTS Score (WHO 2019) calibrado para Southern Latin America (Argentina)
- **Variables base**:
  - Edad
  - Sexo
  - Presión arterial sistólica
  - Colesterol total
  - Tabaquismo
  - Diabetes

### 🌸 Modificadores Específicos de Menopausia

El bot aplica multiplicadores adicionales basados en factores de riesgo femeninos:

| Factor de Riesgo | Multiplicador | Evidencia |
|-----------------|--------------|-----------|
| Menopausia temprana (<45 años) | 1.5x | Riesgo CV 50% mayor |
| PCOS | 1.4x | Riesgo CV 40% mayor |
| Historia de preeclampsia | 1.7x | Riesgo CV 70% mayor |
| Diabetes gestacional | 1.5x | Riesgo CV 50% mayor |
| Hipotiroidismo + LDL elevado | 1.2x | Riesgo CV 20% mayor |
| Historia familiar temprana | 1.6x | Riesgo CV 60% mayor |

### 📈 Detección de Cambios

El bot detecta automáticamente:
- ✅ Cambios ≥5 puntos porcentuales en el riesgo
- ✅ Cambios de categoría (Bajo → Moderado → Alto → Muy Alto)
- ✅ Tendencias sostenidas (mejora o empeoramiento en múltiples evaluaciones)

### 🔔 Sistema de Notificaciones

**Para Pacientes**:
- Email personalizado con riesgo actual
- Visualización de tendencia
- Recomendaciones específicas según factores de riesgo
- Enlaces a Plan Bienestar 100 Días

**Para Equipo Médico**:
- Task resources en Medplum con prioridad
- Dashboard consolidado de todas las pacientes
- Alertas de cambios significativos
- Filtros por categoría de riesgo

---

## 🚀 Quick Start

### Instalación

```bash
# Clonar repositorio
git clone https://github.com/epa-bienestar/cardiovascular-risk-bot
cd cardiovascular-risk-bot

# Instalar dependencias
npm install

# Compilar TypeScript
npm run build
```

### Configuración

1. **Configurar Medplum**:
```bash
cp medplum.config.example.json medplum.config.json
# Editar con tus credenciales
```

2. **Configurar AWS**:
```bash
aws configure
# Ingresar Access Key ID y Secret Access Key
```

3. **Verificar dominio en SES**:
```bash
aws ses verify-domain-identity --domain epa-bienestar.com.ar
```

### Deployment

```bash
# Deploy a desarrollo
npm run deploy:dev

# Deploy a producción
npm run deploy:prod
```

Ver documentación completa en [DEPLOYMENT.md](./DEPLOYMENT.md)

---

## 📁 Estructura del Proyecto

```
cardiovascular-risk-bot/
├── src/
│   ├── bot-cardiovascular-risk.ts      # Bot principal
│   ├── PatientCVDRiskDashboard.tsx     # Dashboard pacientes
│   └── MedicalTeamCVDRiskDashboard.tsx # Dashboard médicos
├── questionnaire-risk-factors-women.json # Cuestionario FHIR
├── medplum-bot-config.json             # Configuración del bot
├── package.json                        # Dependencias
├── tsconfig.json                       # Config TypeScript
├── DEPLOYMENT.md                       # Guía de deployment
└── README.md                          # Este archivo
```

---

## 🧪 Testing

### Test Manual del Bot

```bash
# Ejecutar bot localmente (requiere credenciales Medplum)
npm run test:local
```

### Test de Cálculo de Riesgo

```bash
# Crear paciente de prueba y verificar cálculo
npm run test:risk-calculation
```

### Test de Notificaciones

```bash
# Enviar email de prueba
npm run test:notification
```

---

## 📊 Categorías de Riesgo

| Categoría | Riesgo | Color | Acción Recomendada |
|-----------|--------|-------|-------------------|
| **Bajo** | <10% | 🟢 Verde | Estilo de vida saludable |
| **Moderado** | 10-20% | 🟠 Naranja | Intervención intensiva de estilo de vida + considerar medicación |
| **Alto** | 20-30% | 🔴 Rojo | Medicación recomendada + cambios de estilo de vida |
| **Muy Alto** | >30% | 🔴 Rojo Oscuro | Revisión urgente con cardiología |

---

## 🔐 Seguridad y Privacidad

- ✅ **FHIR R4 Compliant**: Estándares de interoperabilidad en salud
- ✅ **HIPAA Compatible**: Datos almacenados en AWS HealthLake via Medplum
- ✅ **Encriptación**: TLS 1.3 en tránsito, AES-256 en reposo
- ✅ **Auditoría**: Logs completos de todas las operaciones
- ✅ **Permisos granulares**: Role-based access control (RBAC)

---

## 📚 Documentación Adicional

- [DEPLOYMENT.md](./DEPLOYMENT.md) - Guía completa de deployment
- [API Reference](https://www.medplum.com/docs/api) - Medplum API
- [FHIR R4](https://hl7.org/fhir/R4/) - Especificación FHIR
- [HEARTS Technical Package](https://www.paho.org/en/hearts-americas) - OPS/WHO

---

## 🤝 Equipo

**Producto**: Alejandro - Product Leader  
**Cardiología**: Dra. Analía Aquieri, Dra. Verónica Crosa, Dra. Marisa Pages, Dra. Viviana Cavenago  
**Coordinación**: Mg. Giovanna Sanguinetti

---

## 📧 Contacto

- **Email**: tech@epa-bienestar.com.ar
- **Slack**: #programa-mujer-grupo-c
- **Soporte**: soporte@epa-bienestar.com.ar

---

## 📝 Licencia

Copyright © 2024 EPA Bienestar IA. Todos los derechos reservados.

Este software es propiedad de EPA Bienestar IA y está protegido por leyes de derechos de autor. 
El uso no autorizado está prohibido.

---

## 🎯 Roadmap

### ✅ v1.0 (Actual)
- [x] Bot automatizado de riesgo cardiovascular
- [x] Cálculo HEARTS Score + modificadores menopausia
- [x] Notificaciones vía SES
- [x] Dashboards paciente y médico
- [x] Questionnaire de factores de riesgo

### 🚧 v1.1 (Q1 2025)
- [ ] Integración con wearables vía Terra API
- [ ] Cálculo de riesgo en tiempo real
- [ ] Predicciones con ML
- [ ] Visualizaciones avanzadas (gráficos de tendencia)

### 🔮 v2.0 (Q2 2025)
- [ ] Digital Twin cardiovascular
- [ ] Simulador de impacto de intervenciones
- [ ] Recomendaciones de ejercicio personalizadas (MoveMicro)
- [ ] Integración con laboratorios (CGM Abbott)

---

**¡Gracias por usar EPA Bienestar IA! 💜**
