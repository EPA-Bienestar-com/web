# 🔄 GUÍA DE INTEGRACIÓN - Sistema de Turnos EPA Bienestar

## 📍 Contexto
Integrar el nuevo sistema de gestión de turnos en:
- URL: https://mujer.epa-bienestar.com.ar/get-care
- Reemplazar: Componente Scheduler básico de Medplum
- Con: Sistema completo con grupos de vida y flujo optimizado

---

## 🎯 PASO 1: Backup del Código Actual

```bash
# Antes de comenzar, hacer backup
cd /path/to/mujer-epa-bienestar
git checkout -b feature/new-appointment-system
git add .
git commit -m "Backup antes de integración sistema turnos"
```

---

## 🎯 PASO 2: Copiar Nuevos Componentes

### 2.1 Estructura de Carpetas

```
src/
├── components/
│   └── appointments/              # NUEVA CARPETA
│       ├── LifeStageFilter.tsx
│       ├── SlotSelector.tsx
│       ├── AppointmentBooking.tsx
│       ├── AppointmentConfirmation.tsx
│       └── MyAppointments.tsx
│
├── pages/
│   └── get-care/
│       ├── GetCare.tsx            # BACKUP COMO GetCare.old.tsx
│       ├── GetCareEnhanced.tsx    # NUEVO ARCHIVO PRINCIPAL
│       └── index.tsx              # ACTUALIZAR
│
├── types/
│   └── appointments.ts            # NUEVO
│
└── utils/
    ├── fhir-helpers.ts            # NUEVO
    └── appointment-utils.ts       # NUEVO
```

### 2.2 Comandos de Copia

```bash
# Desde el directorio raíz del proyecto

# 1. Crear carpetas
mkdir -p src/components/appointments
mkdir -p src/types
mkdir -p src/utils

# 2. Copiar componentes de appointments
cp /outputs/src/components/appointments/* src/components/appointments/

# 3. Copiar GetCareEnhanced
cp /outputs/src/pages/get-care/GetCareEnhanced.tsx src/pages/get-care/

# 4. Backup del GetCare actual
mv src/pages/get-care/GetCare.tsx src/pages/get-care/GetCare.old.tsx
```

---

## 🎯 PASO 3: Actualizar Archivos de Configuración

### 3.1 Actualizar src/pages/get-care/index.tsx

**ANTES:**
```typescript
import { lazy } from 'react';
import { Route, Routes } from 'react-router-dom';
import PageLayout from '../../components/PageLayout';

const GetCare = lazy(() => import('./GetCare'));

export default function Messages(): JSX.Element {
  return (
    <PageLayout>
      <Routes>
        <Route path="/" element={<GetCare />} />
      </Routes>
    </PageLayout>
  );
}
```

**DESPUÉS:**
```typescript
import { lazy } from 'react';
import { Route, Routes } from 'react-router-dom';
import PageLayout from '../../components/PageLayout';

const GetCareEnhanced = lazy(() => import('./GetCareEnhanced'));
const MyAppointments = lazy(() => import('../../components/appointments/MyAppointments'));

export default function GetCareRoutes(): JSX.Element {
  return (
    <PageLayout>
      <Routes>
        <Route path="/" element={<GetCareEnhanced />} />
        <Route path="/my-appointments" element={<MyAppointments />} />
      </Routes>
    </PageLayout>
  );
}
```

### 3.2 Actualizar Navegación Principal

Agregar enlace a "Mis Turnos" en el menú principal.

**Ubicación**: `src/components/Navigation.tsx` (o similar)

```typescript
// Agregar al menú
<NavLink to="/get-care/my-appointments">
  Mis Turnos
</NavLink>
```

---

## 🎯 PASO 4: Adaptar Estilos al Diseño Actual

### 4.1 Verificar GetCare.css

El archivo `src/pages/get-care/GetCare.css` ya tiene estilos base de Medplum. Los componentes nuevos los usarán.

### 4.2 Colores de Grupos de Vida (Opcional)

Si quieres personalizar los colores de los grupos para que coincidan con tu diseño:

**Editar**: `src/pages/get-care/GetCareEnhanced.tsx`

```typescript
// Línea ~26-55, actualizar colores
const LIFE_STAGE_GROUPS: GroupConfig[] = [
  {
    id: 'A',
    name: 'Grupo A - Jóvenes Profesionales',
    ageRange: '18-30 años',
    description: 'Desarrollo personal, académico y profesional',
    priorityServices: ['cardiology-prevention', 'nutrition', 'stress-management', 'fitness-assessment'],
    color: '#6366f1' // TU COLOR AQUÍ
  },
  {
    id: 'B',
    // ... 
    color: '#ec4899' // TU COLOR AQUÍ
  },
  // ... etc
];
```

---

## 🎯 PASO 5: Configurar Variables de Entorno

### 5.1 Verificar .env

Tu proyecto ya debe tener configuración de Medplum. Verificar que existan:

```env
MEDPLUM_BASE_URL=https://api.epa-bienestar.com.ar
MEDPLUM_CLIENT_ID=tu-client-id
MEDPLUM_CLIENT_SECRET=tu-client-secret
MEDPLUM_PROJECT_ID=tu-project-id
```

---

## 🎯 PASO 6: Ejecutar Setup de Datos Iniciales

### 6.1 Instalar Dependencias Adicionales

```bash
npm install --save-dev ts-node dotenv
```

### 6.2 Copiar Script de Setup

```bash
cp /outputs/scripts/setup-initial-data.ts scripts/
```

### 6.3 Ejecutar Setup

```bash
# Esto creará en Medplum:
# - Organization (EPA Bienestar)
# - 4 Practitioners (Dras. Aquieri, Crosa, Pages, Cavenago)
# - 16 HealthcareServices (servicios por grupo)
# - 4 Schedules
# - ~4,800 Slots (30 días)

npm run setup:initial-data
```

**Output esperado:**
```
🚀 Iniciando setup de EPA Bienestar...

1️⃣  Autenticando con Medplum...
✅ Autenticación exitosa

2️⃣  Creando Organization (EPA Bienestar)...
✅ Organization creada: abc-123-xyz

3️⃣  Creando Practitioners...
   ✅ Dra. Analía Aquieri
   ✅ Dra. Verónica Crosa
   ✅ Dra. Marisa Pages
   ✅ Dra. Viviana Cavenago

4️⃣  Creando HealthcareServices...
   ✅ Prevención Cardiovascular (A)
   ✅ Asesoramiento Nutricional (A)
   ...
   [total 16 servicios]

5️⃣  Creando Schedules...
   ✅ Schedule para Aquieri
   ✅ Schedule para Crosa
   ✅ Schedule para Pages
   ✅ Schedule para Cavenago

6️⃣  Creando Slots (próximos 30 días)...
✅ 4800 slots creados

✨ Setup completado exitosamente!

📊 Resumen:
   - Organization: 1
   - Practitioners: 4
   - HealthcareServices: 16
   - Schedules: 4
   - Slots: 4800

🎉 ¡El sistema está listo para usar!
```

---

## 🎯 PASO 7: Actualizar package.json

Agregar scripts útiles:

```json
{
  "scripts": {
    // ... scripts existentes
    "setup:initial-data": "ts-node scripts/setup-initial-data.ts",
    "test:appointments": "vitest run src/components/appointments",
    "type-check": "tsc --noEmit"
  }
}
```

---

## 🎯 PASO 8: Testing Local

### 8.1 Iniciar Desarrollo

```bash
npm run dev
```

### 8.2 Verificar Rutas

Abrir en navegador:
- ✅ http://localhost:3000/get-care (sistema de reserva)
- ✅ http://localhost:3000/get-care/my-appointments (mis turnos)

### 8.3 Flujo de Testing Manual

1. **Seleccionar Grupo de Vida**
   - Clic en "Grupo A", "Grupo B", "Grupo C", o "Grupo D"
   - Verificar que los servicios se filtren correctamente

2. **Ver Slots Disponibles**
   - Verificar que aparezca calendario con fechas
   - Cambiar entre vista calendario y lista
   - Probar filtros (profesional, servicio)

3. **Reservar Turno**
   - Seleccionar un slot
   - Completar formulario
   - Verificar validación
   - Confirmar turno

4. **Verificar Confirmación**
   - Ver número de confirmación
   - Probar descarga ICS
   - Probar compartir (WhatsApp, Email)
   - Copiar al portapapeles

5. **Gestionar Turnos**
   - Ir a "Mis Turnos"
   - Ver turnos próximos/pasados/cancelados
   - Cancelar un turno (si >24hs)

---

## 🎯 PASO 9: Ajustes de Integración Específicos

### 9.1 Integrar con Sistema de Autenticación Actual

Si ya tienes un sistema de autenticación, asegúrate que `useMedplum()` esté configurado correctamente.

**Verificar en**: `src/App.tsx` o `src/main.tsx`

```typescript
import { MedplumClient } from '@medplum/core';
import { MedplumProvider } from '@medplum/react';

const medplum = new MedplumClient({
  baseUrl: import.meta.env.VITE_MEDPLUM_BASE_URL,
  clientId: import.meta.env.VITE_MEDPLUM_CLIENT_ID,
  // ... otras configs
});

function App() {
  return (
    <MedplumProvider medplum={medplum}>
      {/* ... resto de la app */}
    </MedplumProvider>
  );
}
```

### 9.2 Adaptar Navegación del Header

Integrar con el header actual que muestra:
- Life's Essential 8
- Registros
- Laboratorio
- Mensajes
- Plan
- **Profesional** ← Aquí va Get Care
- Educación

**Sugerencia**: Renombrar "Profesional" a "Turnos" o mantenerlo y que redirija a `/get-care`

---

## 🎯 PASO 10: Optimizaciones de Rendimiento

### 10.1 Lazy Loading

Los componentes ya usan lazy loading en el index.tsx. Verificar que funcione:

```typescript
const GetCareEnhanced = lazy(() => import('./GetCareEnhanced'));
```

### 10.2 Memoización

Los componentes ya usan `useMemo` para optimizar renders. No requiere cambios.

### 10.3 Prefetch de Datos

Opcional: Prefetch de practitioners y services en el layout:

```typescript
// En PageLayout.tsx o similar
useEffect(() => {
  medplum.searchResources('Practitioner', { active: 'true', _count: '10' });
  medplum.searchResources('HealthcareService', { active: 'true', _count: '20' });
}, []);
```

---

## 🎯 PASO 11: Configuración de Notificaciones (Opcional)

### 11.1 Email (SendGrid)

```bash
npm install @sendgrid/mail
```

```typescript
// src/utils/notifications.ts
import sgMail from '@sendgrid/mail';

sgMail.setApiKey(process.env.SENDGRID_API_KEY!);

export async function sendAppointmentConfirmation(
  email: string,
  appointment: Appointment
) {
  const msg = {
    to: email,
    from: 'turnos@epa-bienestar.com.ar',
    subject: 'Confirmación de Turno - EPA Bienestar',
    html: `
      <h1>Turno Confirmado</h1>
      <p>Su turno ha sido confirmado para el ${appointment.start}</p>
      <!-- más detalles -->
    `
  };
  
  await sgMail.send(msg);
}
```

### 11.2 SMS (Twilio)

```bash
npm install twilio
```

```typescript
// src/utils/notifications.ts
import twilio from 'twilio';

const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

export async function sendSMSReminder(
  phone: string,
  appointment: Appointment
) {
  await client.messages.create({
    body: `Recordatorio: Turno mañana a las ${formatTime(appointment.start)}`,
    from: process.env.TWILIO_PHONE_NUMBER,
    to: phone
  });
}
```

---

## 🎯 PASO 12: Deploy a Producción

### 12.1 Build

```bash
npm run build
```

### 12.2 Deploy (según tu infraestructura)

**Si usas AWS S3 + CloudFront:**
```bash
aws s3 sync dist/ s3://mujer-epa-bienestar --delete
aws cloudfront create-invalidation --distribution-id YOUR_ID --paths "/*"
```

**Si usas Vercel:**
```bash
vercel --prod
```

**Si usas otro servicio:**
Seguir documentación específica.

---

## 🎯 PASO 13: Monitoreo Post-Deploy

### 13.1 Verificar en Producción

- ✅ https://mujer.epa-bienestar.com.ar/get-care
- ✅ https://mujer.epa-bienestar.com.ar/get-care/my-appointments

### 13.2 Métricas a Monitorear

1. **Uso de Slots**
   - Slots reservados vs disponibles
   - Tasa de ocupación por practitioner

2. **Comportamiento Usuario**
   - Tiempo promedio para reservar
   - Tasa de abandono en cada paso
   - Grupos de vida más activos

3. **Cancelaciones**
   - Tasa de cancelación
   - Tiempo promedio antes de cita
   - No-shows

### 13.3 Consultas FHIR para Analytics

```typescript
// Turnos por estado
const stats = await medplum.searchResources('Appointment', {
  _summary: 'count',
  status: 'booked'
});

// Slots ocupados hoy
const today = new Date().toISOString().split('T')[0];
const busySlots = await medplum.searchResources('Slot', {
  status: 'busy',
  start: `ge${today}`,
  _count: '1000'
});
```

---

## 🎯 PASO 14: Capacitación del Equipo

### 14.1 Admin Panel

Crear documentación para:
- Cómo crear nuevos slots
- Cómo gestionar schedules
- Cómo ver reportes de turnos

### 14.2 Equipo Médico

- Cómo ver turnos del día
- Cómo marcar llegada del paciente
- Cómo cancelar/reprogramar

### 14.3 Usuarios Finales

- Video tutorial de cómo reservar turno
- FAQ sobre cancelaciones
- Contacto para soporte

---

## ✅ CHECKLIST FINAL DE INTEGRACIÓN

```
□ Código copiado a carpetas correctas
□ GetCare.tsx respaldado
□ index.tsx actualizado con rutas
□ Variables de entorno configuradas
□ Setup inicial ejecutado exitosamente
□ Testing local completado
□ Estilos adaptados al diseño
□ Navegación integrada
□ Build de producción exitoso
□ Deploy a producción completado
□ Verificación en producción OK
□ Documentación actualizada
□ Equipo capacitado
□ Monitoreo activo
```

---

## 🆘 TROUBLESHOOTING

### Problema: "Module not found: @medplum/react"
**Solución:**
```bash
npm install @medplum/core @medplum/fhirtypes @medplum/react
```

### Problema: "No slots found"
**Solución:**
1. Verificar que el setup inicial se ejecutó
2. Verificar fechas de los slots creados
3. Revisar filtros activos en SlotSelector

### Problema: "Authentication failed"
**Solución:**
1. Verificar credenciales en .env
2. Verificar que el proyecto de Medplum esté activo
3. Revisar permisos de API

### Problema: Estilos rotos
**Solución:**
1. Verificar que GetCare.css esté importado
2. Verificar que TailwindCSS esté configurado
3. Revisar conflictos de clases CSS

---

## 📞 Soporte

**Preguntas técnicas:**
- Email: tech@epa-bienestar.com.ar
- GitHub Issues: [repo]/issues

**Documentación:**
- README.md
- DOCUMENTATION.md
- Esta guía (INTEGRACION.md)

---

## 🎉 ¡Éxito!

Una vez completados todos los pasos, tu sistema de turnos estará:

✅ Completamente integrado en mujer.epa-bienestar.com.ar  
✅ Funcionando con FHIR R4  
✅ Adaptado a grupos de vida  
✅ Listo para producción  
✅ Monitoreado y documentado  

**¡Felicitaciones! El sistema está operativo.**
