# ✅ CHECKLIST DE INTEGRACIÓN - Sistema de Turnos EPA Bienestar

## 📋 Antes de Comenzar

- [ ] Acceso al repositorio de código de mujer.epa-bienestar.com.ar
- [ ] Credenciales de Medplum (Client ID, Secret, Project ID)
- [ ] Node.js 18+ instalado
- [ ] Git configurado
- [ ] Editor de código (VS Code recomendado)

---

## 🔧 FASE 1: Preparación (15 minutos)

### 1.1 Backup

- [ ] Crear branch nueva: `git checkout -b feature/new-appointment-system`
- [ ] Commit estado actual: `git commit -am "Backup antes integración"`
- [ ] Backup manual del archivo: `src/pages/get-care/GetCare.tsx`
  - [ ] Copiar a: `src/pages/get-care/GetCare.old.tsx`

### 1.2 Crear Estructura de Carpetas

```bash
cd /path/to/mujer-epa-bienestar
```

- [ ] `mkdir -p src/components/appointments`
- [ ] `mkdir -p src/types`
- [ ] `mkdir -p src/utils`
- [ ] `mkdir -p scripts`

---

## 📁 FASE 2: Copiar Archivos (20 minutos)

### 2.1 Componentes de Appointments

Copiar desde `/outputs/src/components/appointments/` a `src/components/appointments/`:

- [ ] `LifeStageFilter.tsx`
- [ ] `SlotSelector.tsx`
- [ ] `AppointmentBooking.tsx`
- [ ] `AppointmentConfirmation.tsx`
- [ ] `MyAppointments.tsx`

### 2.2 Páginas Get Care

Copiar desde `/outputs/src/pages/get-care/` a `src/pages/get-care/`:

- [ ] `GetCareEnhanced.tsx`
- [ ] `index.tsx` (reemplazar el existente)

### 2.3 Types y Utils

Copiar desde `/outputs/src/types/` a `src/types/`:
- [ ] `appointments.ts`

Copiar desde `/outputs/src/utils/` a `src/utils/`:
- [ ] `date-utils.ts`
- [ ] `fhir-helpers.ts`

### 2.4 Scripts

Copiar desde `/outputs/scripts/` a `scripts/`:
- [ ] `setup-initial-data.ts`

### 2.5 Configuración

Copiar desde `/outputs/`:
- [ ] `.env.example` (revisar, no sobreescribir .env existente)
- [ ] Comparar `package.json` y agregar scripts nuevos

---

## ⚙️ FASE 3: Configuración (15 minutos)

### 3.1 Actualizar package.json

Agregar estos scripts si no existen:

```json
{
  "scripts": {
    "setup:initial-data": "ts-node scripts/setup-initial-data.ts"
  }
}
```

- [ ] Scripts agregados a package.json

### 3.2 Instalar Dependencias

```bash
npm install
```

- [ ] Sin errores en instalación
- [ ] `@medplum/core` instalado
- [ ] `@medplum/react` instalado
- [ ] `@medplum/fhirtypes` instalado

### 3.3 Verificar Variables de Entorno

Archivo `.env` debe contener:

```env
MEDPLUM_BASE_URL=https://api.epa-bienestar.com.ar
MEDPLUM_CLIENT_ID=...
MEDPLUM_CLIENT_SECRET=...
MEDPLUM_PROJECT_ID=...
```

- [ ] Variables verificadas
- [ ] Valores correctos

---

## 🗄️ FASE 4: Setup de Datos en Medplum (30 minutos)

### 4.1 Ejecutar Script de Setup

```bash
npm run setup:initial-data
```

Verificar output:
- [ ] ✅ Autenticación exitosa
- [ ] ✅ Organization creada (1)
- [ ] ✅ Practitioners creados (4)
- [ ] ✅ HealthcareServices creados (16)
- [ ] ✅ Schedules creados (4)
- [ ] ✅ Slots creados (~4,800)

### 4.2 Verificar en Medplum App

Ir a: https://app.medplum.com (o tu instancia)

- [ ] Organization "EPA Bienestar" existe
- [ ] 4 Practitioners visibles:
  - [ ] Dra. Analía Aquieri
  - [ ] Dra. Verónica Crosa
  - [ ] Dra. Marisa Pages
  - [ ] Dra. Viviana Cavenago
- [ ] 16 HealthcareServices visibles
- [ ] Schedules con fechas correctas
- [ ] Slots con status "free" visibles

---

## 💻 FASE 5: Testing Local (30 minutos)

### 5.1 Iniciar Desarrollo

```bash
npm run dev
```

- [ ] Server inicia sin errores
- [ ] Puerto disponible (típicamente 3000)
- [ ] No hay errores de compilación TypeScript

### 5.2 Navegación Básica

Abrir navegador en `http://localhost:3000`

- [ ] Login funciona (si aplica)
- [ ] Header visible
- [ ] Menú de navegación funcional

### 5.3 Get Care - Vista Principal

Navegar a: `/get-care`

- [ ] Página carga sin errores
- [ ] Se muestra "Gestión de Turnos - EPA Bienestar"
- [ ] Filtro de grupos de vida visible:
  - [ ] Grupo A visible
  - [ ] Grupo B visible
  - [ ] Grupo C visible
  - [ ] Grupo D visible
  - [ ] "Ver Todos" visible

### 5.4 Selección de Grupo

- [ ] Click en "Grupo A" - servicios se filtran
- [ ] Click en "Grupo B" - servicios se filtran
- [ ] Click en "Grupo C" - servicios se filtran
- [ ] Click en "Grupo D" - servicios se filtran
- [ ] Click en "Ver Todos" - muestra todos los slots

### 5.5 SlotSelector

- [ ] Calendario visible
- [ ] Fechas con turnos disponibles destacadas
- [ ] Click en fecha - muestra horarios
- [ ] Horarios muestran:
  - [ ] Hora (ej: 10:00)
  - [ ] Duración
  - [ ] Nombre del profesional
  - [ ] Servicio
  - [ ] Botón "Reservar Turno"

### 5.6 Vista Lista vs Calendario

- [ ] Botón "Calendario" funcional
- [ ] Botón "Lista" funcional
- [ ] Cambio entre vistas sin errores
- [ ] Datos se mantienen al cambiar vista

### 5.7 Filtros

- [ ] Búsqueda por texto funciona
- [ ] Filtro por profesional funciona
- [ ] Filtro por servicio funciona
- [ ] Botón "Actualizar" recarga slots
- [ ] Contador "Mostrando X de Y turnos" correcto

### 5.8 Reserva de Turno

Click en "Reservar Turno" en un slot:

- [ ] Navega a pantalla de reserva
- [ ] Resumen del turno visible:
  - [ ] Fecha y hora
  - [ ] Profesional
  - [ ] Servicio
  - [ ] Paciente
- [ ] Formulario visible:
  - [ ] Campo "Motivo de consulta"
  - [ ] Campo "Notas adicionales"
  - [ ] Opciones de contacto
  - [ ] Opciones de recordatorio
  - [ ] Checkbox términos y condiciones

### 5.9 Validación de Formulario

- [ ] Click "Confirmar" sin llenar motivo - muestra error
- [ ] Escribir menos de 10 caracteres - muestra error
- [ ] Llenar correctamente - no muestra errores

### 5.10 Confirmar Turno

Completar formulario y click "Confirmar Turno":

- [ ] Loading indicator visible
- [ ] Navega a pantalla de confirmación
- [ ] Mensaje "¡Turno Confirmado!" visible
- [ ] Número de confirmación generado
- [ ] Detalles del turno correctos
- [ ] Botones de acción visibles:
  - [ ] Agregar a Calendario (ICS)
  - [ ] Copiar Detalles
  - [ ] Compartir WhatsApp
  - [ ] Enviar por Email

### 5.11 Acciones Post-Confirmación

- [ ] Click "Agregar a Calendario" - descarga .ics
- [ ] Click "Copiar Detalles" - copia al portapapeles
- [ ] Click "Compartir WhatsApp" - abre WhatsApp Web
- [ ] Click "Enviar por Email" - abre cliente email
- [ ] Botón "Ver Mis Turnos" funcional
- [ ] Botón "Reservar Otro Turno" funcional

### 5.12 My Appointments

Navegar a: `/get-care/my-appointments`

- [ ] Página carga sin errores
- [ ] Título "Mis Turnos" visible
- [ ] Stats cards visibles:
  - [ ] Próximos Turnos
  - [ ] Turnos Pasados
  - [ ] Cancelados
  - [ ] Total
- [ ] Números correctos

### 5.13 Filtros en My Appointments

- [ ] Click "Próximos" - filtra correctamente
- [ ] Click "Pasados" - filtra correctamente
- [ ] Click "Cancelados" - filtra correctamente
- [ ] Click "Todos" - muestra todos

### 5.14 Lista de Turnos

- [ ] Turnos se muestran en tarjetas
- [ ] Cada turno muestra:
  - [ ] Profesional
  - [ ] Servicio
  - [ ] Fecha y hora
  - [ ] Duración
  - [ ] Estado
  - [ ] Motivo
- [ ] Botones de acción visibles

### 5.15 Cancelación de Turno

Seleccionar un turno próximo (>24hs):

- [ ] Botón "Cancelar Turno" habilitado
- [ ] Click - muestra confirmación
- [ ] Confirmar - turno se cancela
- [ ] Estado actualiza a "Cancelado"
- [ ] Slot vuelve a estar disponible

Seleccionar un turno próximo (<24hs):

- [ ] Botón "Cancelar Turno" deshabilitado
- [ ] Mensaje explicativo visible

---

## 🎨 FASE 6: Ajustes de Diseño (15 minutos)

### 6.1 Verificar Estilos

- [ ] Colores coherentes con diseño EPA
- [ ] Tipografía correcta
- [ ] Espaciados apropiados
- [ ] Botones con estilo consistente

### 6.2 Responsive

Testing en diferentes tamaños:

**Desktop (>1024px):**
- [ ] Layout correcto
- [ ] Todos los elementos visibles
- [ ] Sin scroll horizontal

**Tablet (768-1024px):**
- [ ] Layout se adapta
- [ ] Grid de slots ajustado (2 columnas)
- [ ] Navegación funcional

**Mobile (<768px):**
- [ ] Layout mobile-first
- [ ] Grupos en scroll horizontal
- [ ] Slots en lista (1 columna)
- [ ] Botones accesibles
- [ ] Sin elementos cortados

### 6.3 Colores de Grupos (Opcional)

Si quieres personalizar colores, editar en:
`src/pages/get-care/GetCareEnhanced.tsx`

- [ ] Color Grupo A ajustado
- [ ] Color Grupo B ajustado
- [ ] Color Grupo C ajustado
- [ ] Color Grupo D ajustado

---

## 🔗 FASE 7: Integración con Navegación (10 minutos)

### 7.1 Actualizar Header/Menu

Editar archivo de navegación (ej: `src/components/Navigation.tsx`):

- [ ] Link "Profesional" redirige a `/get-care`
- [ ] O agregar nuevo link "Turnos"
- [ ] Link "Mis Turnos" agregado (opcional)

### 7.2 Verificar Rutas

- [ ] `/get-care` funciona
- [ ] `/get-care/my-appointments` funciona
- [ ] Navegación entre páginas fluida
- [ ] Botón "Volver" funcional

---

## 🧪 FASE 8: Testing de Integración (20 minutos)

### 8.1 Flujo Completo - Caso de Uso 1

Usuario: Mujer 25 años, profesional

- [ ] Login exitoso
- [ ] Navega a "Profesional"
- [ ] Selecciona "Grupo A"
- [ ] Ve servicios filtrados (Prevención, Nutrición, Estrés, Fitness)
- [ ] Selecciona fecha en calendario
- [ ] Reserva turno "Prevención Cardiovascular"
- [ ] Completa formulario
- [ ] Confirma turno
- [ ] Descarga ICS
- [ ] Turno aparece en "Mis Turnos"

### 8.2 Flujo Completo - Caso de Uso 2

Usuario: Mujer 35 años, embarazada

- [ ] Login exitoso
- [ ] Navega a "Profesional"
- [ ] Selecciona "Grupo B"
- [ ] Ve servicios filtrados (Prenatal, PCOS, Fertilidad)
- [ ] Filtra por "Dra. Crosa"
- [ ] Reserva turno "Cardiología Prenatal"
- [ ] Completa formulario con notas
- [ ] Activa recordatorios (2 horas antes)
- [ ] Confirma turno
- [ ] Comparte por WhatsApp

### 8.3 Flujo Completo - Caso de Uso 3

Usuario: Mujer 55 años, menopausia

- [ ] Login exitoso
- [ ] Va a "Mis Turnos"
- [ ] Ve turno próximo
- [ ] Decide cancelar
- [ ] Confirma cancelación
- [ ] Turno actualiza a "Cancelado"
- [ ] Reserva nuevo turno "Cardiología Menopausia"
- [ ] Grupo C seleccionado automáticamente

### 8.4 Testing de Errores

- [ ] Sin conexión - mensaje apropiado
- [ ] Slot ya reservado - manejo correcto
- [ ] Formulario inválido - errores claros
- [ ] Token expirado - redirect a login

---

## 🚀 FASE 9: Build y Deploy (30 minutos)

### 9.1 Build Local

```bash
npm run build
```

- [ ] Build exitoso
- [ ] Sin warnings críticos
- [ ] Dist generado

### 9.2 Test Build Local

```bash
npm run preview
```

- [ ] Aplicación inicia
- [ ] Todas las funcionalidades operan
- [ ] Performance aceptable

### 9.3 Deploy a Staging (si aplica)

```bash
# Según tu infraestructura
npm run deploy:staging
```

- [ ] Deploy exitoso
- [ ] URL staging accesible
- [ ] Testing en staging OK

### 9.4 Deploy a Producción

```bash
# Según tu infraestructura
npm run deploy:production
# O
aws s3 sync dist/ s3://mujer-epa-bienestar --delete
```

- [ ] Deploy exitoso
- [ ] Cache invalidado (CloudFront, etc)
- [ ] URL producción accesible

---

## ✅ FASE 10: Verificación en Producción (15 minutos)

### 10.1 Smoke Tests

URL: https://mujer.epa-bienestar.com.ar

- [ ] Homepage carga
- [ ] Login funciona
- [ ] Get Care accesible
- [ ] Slots se cargan
- [ ] Reserva funciona
- [ ] Confirmación se genera
- [ ] My Appointments funciona

### 10.2 Cross-Browser

- [ ] Chrome - funcional
- [ ] Firefox - funcional
- [ ] Safari - funcional
- [ ] Edge - funcional
- [ ] Mobile Safari - funcional
- [ ] Mobile Chrome - funcional

### 10.3 Performance

- [ ] Tiempo de carga <3s
- [ ] Interacción fluida
- [ ] Sin memory leaks
- [ ] Console sin errores

---

## 📊 FASE 11: Monitoreo (Continuo)

### 11.1 Métricas a Observar

Primeras 24 horas:
- [ ] Número de reservas
- [ ] Tasa de completación (inicio → confirmación)
- [ ] Errores en console (frontend)
- [ ] Errores en API (backend)

Primera semana:
- [ ] Distribución por grupos
- [ ] Profesionales más solicitados
- [ ] Horarios pico
- [ ] Tasa de cancelación

### 11.2 Análisis FHIR

Usar Medplum Console para:
- [ ] Ver appointments creados
- [ ] Verificar slots ocupados
- [ ] Revisar communications enviadas

---

## 📚 FASE 12: Documentación (20 minutos)

### 12.1 Documentación Interna

- [ ] Actualizar README del proyecto
- [ ] Documentar decisiones técnicas
- [ ] Agregar screenshots

### 12.2 Documentación para Usuarios

- [ ] Crear guía "Cómo reservar un turno"
- [ ] FAQ sobre cancelaciones
- [ ] Video tutorial (opcional)

### 12.3 Documentación para Equipo

- [ ] Admin: cómo crear slots
- [ ] Médicos: cómo ver turnos del día
- [ ] Soporte: cómo ayudar con problemas

---

## 🎓 FASE 13: Capacitación (Variable)

### 13.1 Equipo Administrativo

- [ ] Sesión de capacitación completada
- [ ] Acceso a Medplum configurado
- [ ] Procedimientos documentados

### 13.2 Equipo Médico

- [ ] Demostración del sistema
- [ ] Workflow explicado
- [ ] Q&A session completada

### 13.3 Soporte

- [ ] Troubleshooting guide creado
- [ ] Contactos de escalación definidos
- [ ] Procedimientos de backup documentados

---

## 🔄 FASE 14: Iteración (Continuo)

### 14.1 Recopilar Feedback

Primeras 2 semanas:
- [ ] Encuesta a usuarios enviada
- [ ] Feedback del equipo médico
- [ ] Análisis de métricas

### 14.2 Mejoras Identificadas

- [ ] Lista de bugs priorizada
- [ ] Lista de mejoras priorizadas
- [ ] Roadmap actualizado

### 14.3 Siguientes Sprints

- [ ] Sprint planning con mejoras
- [ ] Desarrollo iterativo
- [ ] Testing continuo

---

## 🎉 FINALIZACIÓN

### Criterios de Éxito

- [✓] Sistema integrado en producción
- [✓] Sin errores críticos
- [✓] Usuarios pueden reservar turnos
- [✓] Equipo capacitado
- [✓] Monitoreo activo
- [✓] Documentación completa

### Celebración

- [ ] Comunicar éxito al equipo
- [ ] Agradecer a colaboradores
- [ ] Planificar próximas features

---

## 📞 Soporte

**Preguntas durante integración:**
- Email: tech@epa-bienestar.com.ar
- Slack: #turnos-sistema

**Documentación:**
- README.md
- DOCUMENTATION.md
- GUIA_INTEGRACION.md (este archivo)
- DIAGRAMA_FLUJO.md

---

## ⏱️ Tiempo Estimado Total

- Preparación: 15 min
- Copiar archivos: 20 min
- Configuración: 15 min
- Setup Medplum: 30 min
- Testing local: 30 min
- Ajustes diseño: 15 min
- Navegación: 10 min
- Testing integración: 20 min
- Build y deploy: 30 min
- Verificación producción: 15 min
- Documentación: 20 min

**Total: ~3.5 horas** (trabajo técnico)

Más capacitación y monitoreo según necesidad.

---

**¡Éxito en la integración!** 🚀
