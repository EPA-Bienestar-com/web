# 📊 Diagrama de Flujo - Sistema de Gestión de Turnos EPA Bienestar

## 🎯 Flujo Principal de Reserva

```
┌─────────────────────────────────────────────────────────────────┐
│                    USUARIO INGRESA A /get-care                   │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                  GetCareEnhanced (Componente Principal)          │
│                                                                  │
│  Estado:                                                         │
│  - step: 'selection' | 'booking' | 'confirmation'               │
│  - selectedGroup: LifeStageGroup                                │
│  - selectedSlot: Slot | null                                    │
│  - patient: Patient                                             │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
        ┌────────────────┴────────────────┐
        │                                 │
        ▼                                 ▼
┌──────────────────┐            ┌──────────────────┐
│ step: selection  │            │ Cargar datos     │
│                  │            │ - Schedules      │
│ Mostrar:         │            │ - Slots          │
│ LifeStageFilter  │            │ - Practitioners  │
│ SlotSelector     │            │ - Services       │
└────────┬─────────┘            │ - Patient        │
         │                      └──────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                      PASO 1: Selección de Grupo                  │
│                                                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
│  │ GRUPO A  │  │ GRUPO B  │  │ GRUPO C  │  │ GRUPO D  │       │
│  │ 18-30    │  │ 28-40    │  │ 45-65    │  │ 65+      │       │
│  │          │  │          │  │          │  │          │       │
│  │ • Prev.  │  │ • PCOS   │  │ • Meno.  │  │ • Geri.  │       │
│  │ • Nutri. │  │ • Pren.  │  │ • Oste.  │  │ • Cuida. │       │
│  │ • Estrés │  │ • Fert.  │  │ • Horm.  │  │ • Movil. │       │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘       │
│       └─────────────┴──────────────┴─────────────┘             │
│                              │                                  │
│                   Filtrar slots por grupo                       │
└──────────────────────────────┬──────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                      PASO 2: Selección de Slot                   │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                   SlotSelector Component                  │  │
│  │                                                            │  │
│  │  Filtros:                                                  │  │
│  │  ┌────────────┐ ┌────────────┐ ┌────────────┐           │  │
│  │  │ Búsqueda   │ │Profesional │ │ Servicio   │           │  │
│  │  └────────────┘ └────────────┘ └────────────┘           │  │
│  │                                                            │  │
│  │  Vistas:                                                   │  │
│  │  [ Calendario ]  [ Lista ]                                │  │
│  │                                                            │  │
│  │  ┌──────────────────────────────────────────────────┐    │  │
│  │  │          Vista Calendario (por defecto)          │    │  │
│  │  │                                                    │    │  │
│  │  │  LUN  MAR  MIE  JUE  VIE  SAB  DOM               │    │  │
│  │  │   5    6    7    8    9   10   11                │    │  │
│  │  │        [12] [13] [14] 15   16  <-- Día selec.    │    │  │
│  │  │                                                    │    │  │
│  │  │  Horarios para 13 Enero:                         │    │  │
│  │  │  ┌────────┐ ┌────────┐ ┌────────┐               │    │  │
│  │  │  │ 10:00  │ │ 10:30  │ │ 11:00  │               │    │  │
│  │  │  │ Dra.   │ │ Dra.   │ │ Dra.   │               │    │  │
│  │  │  │ Aquieri│ │ Crosa  │ │ Pages  │               │    │  │
│  │  │  │30 min  │ │45 min  │ │30 min  │               │    │  │
│  │  │  │[Reser.] │ │[Reser.]│ │[Reser.]│              │    │  │
│  │  │  └────────┘ └────────┘ └────────┘               │    │  │
│  │  └──────────────────────────────────────────────────┘    │  │
│  └────────────────────────────────┬───────────────────────────┘│
└───────────────────────────────────┼────────────────────────────┘
                                    │
                    Usuario hace clic en "Reservar"
                                    │
                                    ▼
                        step = 'booking'
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────┐
│                      PASO 3: Formulario de Reserva               │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │           AppointmentBooking Component                    │  │
│  │                                                            │  │
│  │  ┌──────────────────────────────────────────────────┐    │  │
│  │  │ Resumen del Turno        │ Formulario            │    │  │
│  │  │                           │                       │    │  │
│  │  │ 📅 Fecha: 13 Enero       │ Motivo de Consulta *  │    │  │
│  │  │ ⏰ Hora: 10:00           │ [________________]    │    │  │
│  │  │ ⏱️  Duración: 30 min     │                       │    │  │
│  │  │                           │ Notas Adicionales     │    │  │
│  │  │ 👤 Dra. Analía Aquieri   │ [________________]    │    │  │
│  │  │    Cardiología SAC        │                       │    │  │
│  │  │                           │ Preferencia Contacto: │    │  │
│  │  │ 🏥 Prevención CV         │ ○ Email               │    │  │
│  │  │    Grupo A                │ ○ Teléfono            │    │  │
│  │  │                           │ ○ SMS                 │    │  │
│  │  │ 🧑 María García          │                       │    │  │
│  │  │    maria@email.com        │ Recordatorios:        │    │  │
│  │  │                           │ ☑ Activar             │    │  │
│  │  └───────────────────────────│ ○ 24 horas antes     │    │  │
│  │                               │ ○ 2 horas antes      │    │  │
│  │                               │ ○ 30 minutos antes   │    │  │
│  │                               │                       │    │  │
│  │                               │ ☑ Acepto términos    │    │  │
│  │                               │                       │    │  │
│  │                               │ [Cancelar][Confirmar]│    │  │
│  │                               └───────────────────────┘    │  │
│  └────────────────────────────────┬───────────────────────────┘│
└───────────────────────────────────┼────────────────────────────┘
                                    │
                    Usuario hace clic en "Confirmar"
                                    │
                                    ▼
                        ┌───────────────────────┐
                        │ Validar formulario    │
                        └───────────┬───────────┘
                                    │
                    ┌───────────────┴───────────────┐
                    │                               │
                   ❌ Error                        ✅ Válido
                    │                               │
                    ▼                               ▼
          Mostrar errores              ┌─────────────────────┐
          Mantener en booking          │ Crear Appointment   │
                                       │ status: 'booked'    │
                                       └──────────┬──────────┘
                                                  │
                                       ┌──────────▼──────────┐
                                       │ Actualizar Slot     │
                                       │ status: 'busy'      │
                                       └──────────┬──────────┘
                                                  │
                                       ┌──────────▼──────────┐
                                       │ Crear Communication │
                                       │ (notificación)      │
                                       └──────────┬──────────┘
                                                  │
                                                  ▼
                                      step = 'confirmation'
                                                  │
                                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                      PASO 4: Confirmación                        │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │         AppointmentConfirmation Component                 │  │
│  │                                                            │  │
│  │                      ✅ TURNO CONFIRMADO                  │  │
│  │                                                            │  │
│  │              Número de Confirmación: #ABC12345            │  │
│  │                                                            │  │
│  │  ┌──────────────────┐  ┌──────────────────┐             │  │
│  │  │ 📅 13 Enero 2026 │  │ 👤 Dra. Aquieri  │             │  │
│  │  │ ⏰ 10:00         │  │ 🏥 Prevención CV  │             │  │
│  │  │ ⏱️  30 min       │  │ 🧑 María García   │             │  │
│  │  └──────────────────┘  └──────────────────┘             │  │
│  │                                                            │  │
│  │  Motivo: Control cardiovascular preventivo                │  │
│  │                                                            │  │
│  │  ⚠️ Recordatorios:                                        │  │
│  │  • Llegue 10 minutos antes                               │  │
│  │  • Traiga documento y orden médica                       │  │
│  │  • Cancelación: mínimo 24hs antes                        │  │
│  │                                                            │  │
│  │  Guardar o Compartir:                                     │  │
│  │  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐                   │  │
│  │  │ 📅   │ │ 📋   │ │ 💬   │ │ 📧   │                   │  │
│  │  │ Cal. │ │ Copy │ │ WA   │ │ Email│                   │  │
│  │  └──────┘ └──────┘ └──────┘ └──────┘                   │  │
│  │                                                            │  │
│  │  [ Ver Mis Turnos ]  [ Reservar Otro Turno ]             │  │
│  └────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

## 🔄 Flujo de Gestión de Turnos

```
┌─────────────────────────────────────────────────────────────────┐
│          USUARIO INGRESA A /get-care/my-appointments             │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                  MyAppointments Component                        │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │                    MIS TURNOS                           │    │
│  │                                                          │    │
│  │  Estadísticas:                                          │    │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ │    │
│  │  │    3     │ │    12    │ │     2    │ │    17    │ │    │
│  │  │ Próximos │ │ Pasados  │ │Cancelados│ │  Total   │ │    │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ │    │
│  │                                                          │    │
│  │  Filtros:                                               │    │
│  │  [ Próximos ] [ Pasados ] [ Cancelados ] [ Todos ]     │    │
│  │                                                          │    │
│  │  Lista de Turnos:                                       │    │
│  │  ┌────────────────────────────────────────────────┐    │    │
│  │  │ Dra. Analía Aquieri                            │    │    │
│  │  │ Prevención Cardiovascular                      │    │    │
│  │  │ 📅 13 Enero 2026  ⏰ 10:00  ⏱️ 30 min         │    │    │
│  │  │ Motivo: Control preventivo                     │    │    │
│  │  │ [✅ Confirmado]                  [Ver][Cancelar]│    │    │
│  │  └────────────────────────────────────────────────┘    │    │
│  │  ┌────────────────────────────────────────────────┐    │    │
│  │  │ Dra. Verónica Crosa                            │    │    │
│  │  │ Cardiología Prenatal                           │    │    │
│  │  │ 📅 20 Enero 2026  ⏰ 15:00  ⏱️ 45 min         │    │    │
│  │  │ Motivo: Control embarazo                       │    │    │
│  │  │ [✅ Confirmado]                  [Ver][Cancelar]│    │    │
│  │  └────────────────────────────────────────────────┘    │    │
│  │                                                          │    │
│  │  [ Reservar Nuevo Turno ]                               │    │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## 🗄️ Flujo de Datos FHIR

```
┌─────────────────────────────────────────────────────────────────┐
│                         CAPA DE DATOS                            │
│                    Medplum FHIR Server API                       │
│              https://api.epa-bienestar.com.ar/fhir/r4           │
└─────────────────────┬───────────────────────────────────────────┘
                      │
         ┌────────────┼────────────┐
         │            │            │
         ▼            ▼            ▼
   ┌─────────┐  ┌─────────┐  ┌─────────┐
   │Schedule │  │  Slot   │  │Appoint. │
   └────┬────┘  └────┬────┘  └────┬────┘
        │            │            │
        │  references│  references│
        ▼            ▼            ▼
   ┌─────────┐  ┌─────────┐  ┌─────────┐
   │Practiti-│  │Service  │  │ Patient │
   │oner     │  │         │  │         │
   └─────────┘  └─────────┘  └─────────┘
        │                         │
        └────────┬────────────────┘
                 │
                 ▼
          ┌──────────────┐
          │Communication │
          │(notificación)│
          └──────────────┘

Flujo de Creación de Appointment:

1. GET /Slot?status=free
   └─> Obtener slots disponibles

2. POST /Appointment
   └─> Crear nuevo turno
       {
         status: "booked",
         participant: [Patient, Practitioner]
       }

3. PUT /Slot/{id}
   └─> Actualizar slot a busy
       {
         status: "busy",
         appointment: { reference: "Appointment/xyz" }
       }

4. POST /Communication
   └─> Crear notificación
       {
         category: "notification",
         about: [{ reference: "Appointment/xyz" }]
       }
```

## 🎨 Integración con UI Actual

```
┌─────────────────────────────────────────────────────────────────┐
│              Header: mujer.epa-bienestar.com.ar                  │
│                                                                  │
│  [🍎] Life's Essential 8 | Registros | Laboratorio | Mensajes  │
│       Plan | Profesional | Educación                [Profile]   │
└────────────────────┬─────────────────────────────────────────────┘
                     │
                     │ Click en "Profesional"
                     │
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│                    /get-care (GetCareEnhanced)                   │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Selecciona tu Grupo de Vida                             │  │
│  │  [ Grupo A ] [ Grupo B ] [ Grupo C ] [ Grupo D ]         │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Turnos Disponibles  [ 📅 Calendario ] [ 📋 Lista ]      │  │
│  │  [Buscar] [Profesional ▼] [Servicio ▼] [🔄 Actualizar]  │  │
│  │                                                            │  │
│  │  [Calendario interactivo con slots]                       │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  [ Mis Turnos ]  ← Navega a /get-care/my-appointments          │
└─────────────────────────────────────────────────────────────────┘
```

## 📱 Flujo Responsive

```
DESKTOP (>1024px):
┌─────────────────────────────────────┐
│ Header                              │
├─────────────────┬───────────────────┤
│                 │                   │
│ Grupos de Vida  │   Calendario      │
│ (vertical)      │   (grande)        │
│                 │                   │
│                 │   Slots           │
│                 │   (grid 3 cols)   │
│                 │                   │
└─────────────────┴───────────────────┘

TABLET (768px-1024px):
┌─────────────────────────────────────┐
│ Header                              │
├─────────────────────────────────────┤
│ Grupos de Vida (horizontal)         │
├─────────────────────────────────────┤
│                                     │
│ Calendario (mediano)                │
│                                     │
│ Slots (grid 2 cols)                 │
│                                     │
└─────────────────────────────────────┘

MOBILE (<768px):
┌───────────────────┐
│ Header (compact)  │
├───────────────────┤
│ Grupos            │
│ (scroll horiz.)   │
├───────────────────┤
│                   │
│ Calendario        │
│ (pequeño)         │
│                   │
│ Slots             │
│ (lista 1 col)     │
│                   │
└───────────────────┘
```

## 🔐 Flujo de Autenticación

```
Usuario no autenticado:
┌──────────────┐
│ Landing Page │
│ (público)    │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   Sign In    │
│              │
│ Email/Pass   │
│ [Ingresar]   │
└──────┬───────┘
       │
       ▼ (autenticado)
┌──────────────┐
│ Medplum      │
│ OAuth Token  │
└──────┬───────┘
       │
       ▼
┌──────────────────────┐
│ App con acceso FHIR  │
│                      │
│ useMedplum() hook    │
│ - Patient ID         │
│ - Access Token       │
└──────────────────────┘
```

## 📊 Estado Global

```
React Context / MedplumProvider:
┌─────────────────────────────────────┐
│ MedplumClient                       │
│ ├─ baseUrl                          │
│ ├─ token                            │
│ └─ patient                          │
│                                     │
│ useMedplum() disponible en:         │
│ ├─ GetCareEnhanced                  │
│ ├─ LifeStageFilter                  │
│ ├─ SlotSelector                     │
│ ├─ AppointmentBooking               │
│ ├─ AppointmentConfirmation          │
│ └─ MyAppointments                   │
└─────────────────────────────────────┘
```
